import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

    const { phone, leadId } = await req.json();
    if (!phone) return Response.json({ error: 'Phone number required' }, { status: 400 });

    // Basic phone validation
    const cleaned = phone.replace(/\D/g, '');
    if (cleaned.length < 10) return Response.json({ error: 'Invalid phone number format' }, { status: 400 });
    if (cleaned.startsWith('555') || cleaned.substring(3, 6) === '555') {
      return Response.json({ error: 'Invalid phone number' }, { status: 400 });
    }

    const accountSid = Deno.env.get('TWILIO_ACCOUNT_SID');
    const authToken = Deno.env.get('TWILIO_AUTH_TOKEN');
    const serviceSid = Deno.env.get('TWILIO_VERIFY_SERVICE_SID');

    if (!accountSid || !authToken || !serviceSid) {
      // Twilio not configured — mark as verified for dev/demo
      console.warn('Twilio not configured, using demo mode');
      if (leadId) {
        await base44.asServiceRole.entities.Lead.update(leadId, {
          is_phone_verified: true,
          verification_status: 'verified',
        });
      }
      return Response.json({ success: true, demo: true, message: 'Demo mode: phone marked verified' });
    }

    const formattedPhone = cleaned.length === 10 ? `+1${cleaned}` : `+${cleaned}`;

    const twilioRes = await fetch(
      `https://verify.twilio.com/v2/Services/${serviceSid}/Verifications`,
      {
        method: 'POST',
        headers: {
          'Authorization': `Basic ${btoa(`${accountSid}:${authToken}`)}`,
          'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: new URLSearchParams({ To: formattedPhone, Channel: 'sms' }),
      }
    );

    const data = await twilioRes.json();
    if (!twilioRes.ok) {
      console.error('Twilio error:', data);
      return Response.json({ error: data.message || 'Failed to send verification code' }, { status: 400 });
    }

    return Response.json({ success: true, sid: data.sid });
  } catch (error) {
    console.error('verifyPhone error:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});