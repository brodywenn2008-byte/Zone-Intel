import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';

function interpolate(template, vars) {
  return template.replace(/\{\{(\w+)\}\}/g, (_, key) => vars[key] || "");
}

Deno.serve(async (req) => {
  try {
    const payload = await req.json();
    const base44 = createClientFromRequest(req);

    // Called from automation: payload has event + data
    const leadData = payload.data || payload.lead;
    const newStatus = leadData?.status;

    if (!leadData || !newStatus) {
      return Response.json({ skipped: true, reason: "no lead data or status" });
    }

    // Only act on stages we care about
    const HANDLED_STAGES = ["follow_up", "appointment_set", "sold", "interested", "knocked"];
    if (!HANDLED_STAGES.includes(newStatus)) {
      return Response.json({ skipped: true, reason: `stage '${newStatus}' not handled` });
    }

    // Find active template for this stage
    const templates = await base44.asServiceRole.entities.AutomationTemplate.filter({
      stage: newStatus,
      is_active: true,
    });

    if (!templates.length) {
      return Response.json({ skipped: true, reason: "no active template for stage" });
    }

    const template = templates[0];

    // Build interpolation vars
    const vars = {
      name: leadData.owner_name || "there",
      address: leadData.address || "",
      phone: leadData.phone || "",
      city: leadData.city || "",
      state: leadData.state || "",
      zip: leadData.zip_code || "",
      rep_email: leadData.assigned_rep || "",
      notes: leadData.notes || "",
    };

    const results = { email: null, sms: null };

    // Send email if enabled and lead has email
    if (template.send_email && template.email_subject && template.email_body && leadData.email) {
      const subject = interpolate(template.email_subject, vars);
      const body = interpolate(template.email_body, vars);
      console.log(`Sending email to ${leadData.email} — subject: ${subject}`);
      await base44.asServiceRole.integrations.Core.SendEmail({
        to: leadData.email,
        subject,
        body,
      });
      results.email = { sent: true, to: leadData.email };
    } else if (template.send_email && !leadData.email) {
      results.email = { sent: false, reason: "lead has no email address" };
    }

    // Send SMS via Twilio if enabled, template body set, and lead has a phone number
    if (template.send_sms && template.sms_body && leadData.phone) {
      const accountSid = Deno.env.get("TWILIO_ACCOUNT_SID");
      const authToken  = Deno.env.get("TWILIO_AUTH_TOKEN");
      const fromNumber = Deno.env.get("TWILIO_FROM_NUMBER");

      if (!accountSid || !authToken || !fromNumber) {
        console.warn("[SMS] Twilio secrets not configured — skipping SMS");
        results.sms = { sent: false, reason: "Twilio secrets not configured" };
      } else {
        const smsText = interpolate(template.sms_body, vars);
        const toNumber = leadData.phone.replace(/[^+\d]/g, "");
        const body = new URLSearchParams({
          To:   toNumber,
          From: fromNumber,
          Body: smsText,
        });
        const credentials = btoa(`${accountSid}:${authToken}`);
        const twilioRes = await fetch(
          `https://api.twilio.com/2010-04-01/Accounts/${accountSid}/Messages.json`,
          {
            method: "POST",
            headers: {
              "Authorization": `Basic ${credentials}`,
              "Content-Type": "application/x-www-form-urlencoded",
            },
            body,
          }
        );
        const twilioData = await twilioRes.json();
        if (twilioRes.ok) {
          console.log(`[SMS] Sent to ${toNumber} — SID: ${twilioData.sid}`);
          results.sms = { sent: true, to: toNumber, sid: twilioData.sid };
        } else {
          console.error(`[SMS] Twilio error:`, JSON.stringify(twilioData));
          results.sms = { sent: false, error: twilioData.message || "Twilio request failed" };
        }
      }
    } else if (template.send_sms && !leadData.phone) {
      results.sms = { sent: false, reason: "lead has no phone number" };
    }

    return Response.json({ success: true, stage: newStatus, results });
  } catch (error) {
    console.error("sendLeadAutomation error:", error.message);
    return Response.json({ error: error.message }, { status: 500 });
  }
});