import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

    const { phone, code, leadId } = await req.json();
    if (!phone || !code) return Response.json({ error: 'Phone and code required' }, { status: 400 });

    const accountSid = Deno.env.get('TWILIO_ACCOUNT_SID');
    const authToken = Deno.env.get('TWILIO_AUTH_TOKEN');
    const serviceSid = Deno.env.get('TWILIO_VERIFY_SERVICE_SID');

    if (!accountSid || !authToken || !serviceSid) {
      // Demo mode: accept code "000000"
      if (code === '000000') {
        if (leadId) {
          await base44.asServiceRole.entities.Lead.update(leadId, {
            is_phone_verified: true,
            verification_status: 'verified',
          });
        }
        return Response.json({ success: true, verified: true, demo: true });
      }
      return Response.json({ success: false, verified: false, error: 'Demo mode: use code 000000' });
    }

    const cleaned = phone.replace(/\D/g, '');
    const formattedPhone = cleaned.length === 10 ? `+1${cleaned}` : `+${cleaned}`;

    const twilioRes = await fetch(
      `https://verify.twilio.com/v2/Services/${serviceSid}/VerificationCheck`,
      {
        method: 'POST',
        headers: {
          'Authorization': `Basic ${btoa(`${accountSid}:${authToken}`)}`,
          'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: new URLSearchParams({ To: formattedPhone, Code: code }),
      }
    );

    const data = await twilioRes.json();
    if (!twilioRes.ok) {
      console.error('Twilio check error:', data);
      return Response.json({ success: false, verified: false, error: data.message }, { status: 400 });
    }

    const verified = data.status === 'approved';

    if (verified && leadId) {
      // Calculate trust score after phone verification
      const lead = await base44.asServiceRole.entities.Lead.get(leadId);
      let trustScore = 40; // base
      if (lead.is_phone_verified) trustScore += 25;
      if (lead.consent_given) trustScore += 10;
      if (lead.address && lead.address.length > 5) trustScore += 10;
      if (lead.owner_name) trustScore += 10;
      if (lead.email) trustScore += 5;

      await base44.asServiceRole.entities.Lead.update(leadId, {
        is_phone_verified: true,
        verification_status: 'verified',
        trust_score: Math.min(trustScore, 100),
      });

      // Update seller stats
      await base44.asServiceRole.entities.User.update(lead.seller_id || lead.created_by_id, {
        phone_verified: true,
        verification_level: 'phone',
      });
    }

    return Response.json({ success: true, verified });
  } catch (error) {
    console.error('checkVerifyCode error:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});