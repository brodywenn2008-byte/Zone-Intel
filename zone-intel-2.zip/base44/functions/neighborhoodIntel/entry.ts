import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

    const { zip } = await req.json();
    if (!zip || zip.length < 5) return Response.json({ error: 'Invalid ZIP' }, { status: 400 });

    console.log(`[neighborhoodIntel] Starting for ZIP: ${zip}`);

    // Step 1: Get ZIP centroid + bounding box from Nominatim
    const nominatimRes = await fetch(
      `https://nominatim.openstreetmap.org/search?postalcode=${zip}&country=US&format=json&limit=1`,
      { headers: { 'User-Agent': 'ZoneIntel/1.0' } }
    );
    const nominatimData = await nominatimRes.json();
    if (!nominatimData.length) return Response.json({ error: 'ZIP not found' }, { status: 404 });

    const { lat: latStr, lon: lonStr, boundingbox, display_name } = nominatimData[0];
    const lat = parseFloat(latStr);
    const lng = parseFloat(lonStr);
    const city = display_name.split(',').slice(0, 2).join(',').trim();
    console.log(`[neighborhoodIntel] ZIP centroid: ${lat}, ${lng} — ${city}`);

    // Step 2: Get Census state + county FIPS from centroid
    const censusGeoRes = await fetch(
      `https://geocoding.geo.census.gov/geocoder/geographies/coordinates?x=${lng}&y=${lat}&benchmark=Public_AR_Current&vintage=Current_Current&layers=Census+Tracts&format=json`
    );
    const censusGeoData = await censusGeoRes.json();
    const geographies = censusGeoData?.result?.geographies;
    const tract = geographies?.['Census Tracts']?.[0];
    const stateFips = tract?.STATE;
    const countyFips = tract?.COUNTY;
    console.log(`[neighborhoodIntel] State FIPS: ${stateFips}, County FIPS: ${countyFips}`);

    // Step 3: Get ALL Census tracts in county with full ACS demographics
    let tractData = [];
    if (stateFips && countyFips) {
      const acsVars = [
        'NAME',
        'B19013_001E', // Median household income
        'B01003_001E', // Total population
        'B25003_001E', // Total tenure (housing units)
        'B25003_002E', // Owner-occupied housing units
        'B01002_001E', // Median age
        'B17001_002E', // Below poverty level
        'B17001_001E', // Total population (poverty universe)
        'B25077_001E', // Median home value
        'B25002_002E', // Occupied housing units
        'B25002_001E', // Total housing units
        'B08303_001E', // Total commuters
        'B15003_022E', // Bachelor's degree
        'B15003_001E', // Total education universe
      ].join(',');

      const acsRes = await fetch(
        `https://api.census.gov/data/2022/acs/acs5?get=${acsVars}&for=tract:*&in=state:${stateFips}%20county:${countyFips}`
      );
      const acsRaw = await acsRes.json();
      console.log(`[neighborhoodIntel] Census returned ${acsRaw.length - 1} tracts`);

      // Parse header row
      const headers = acsRaw[0];
      tractData = acsRaw.slice(1).map(row => {
        const obj = {};
        headers.forEach((h, i) => { obj[h] = row[i]; });
        return {
          tract_name: obj.NAME,
          tract_id: obj.tract,
          state: obj.state,
          county: obj.county,
          median_income: parseInt(obj.B19013_001E) || null,
          total_population: parseInt(obj.B01003_001E) || 0,
          total_tenure: parseInt(obj.B25003_001E) || 0,
          owner_occupied: parseInt(obj.B25003_002E) || 0,
          median_age: parseFloat(obj.B01002_001E) || null,
          below_poverty: parseInt(obj.B17001_002E) || 0,
          poverty_universe: parseInt(obj.B17001_001E) || 1,
          median_home_value: parseInt(obj.B25077_001E) || null,
          total_housing: parseInt(obj.B25002_001E) || 0,
          occupied_housing: parseInt(obj.B25002_002E) || 0,
          bachelors_degree: parseInt(obj.B15003_022E) || 0,
          education_universe: parseInt(obj.B15003_001E) || 1,
        };
      }).filter(t => t.total_population > 100); // filter out tiny/empty tracts
    }

    // Step 4: Get OSM neighborhood names — broad query including subdivisions, hamlets, residential areas
    const south = lat - 0.35;
    const north = lat + 0.35;
    const west = lng - 0.5;
    const east = lng + 0.5;

    const overpassQuery = `[out:json][timeout:40];
(
  node["place"~"^(neighbourhood|suburb|quarter|village|hamlet|borough|city_block|isolated_dwelling|locality|town)$"](${south},${west},${north},${east});
  way["place"~"^(neighbourhood|suburb|quarter|village|hamlet|borough|locality)$"](${south},${west},${north},${east});
  relation["place"~"^(neighbourhood|suburb|quarter|village|hamlet|borough|locality)$"](${south},${west},${north},${east});
  way["landuse"="residential"]["name"](${south},${west},${north},${east});
  relation["landuse"="residential"]["name"](${south},${west},${north},${east});
  relation["boundary"="administrative"]["admin_level"~"^(8|9|10)$"]["name"](${south},${west},${north},${east});
  way["boundary"="administrative"]["admin_level"~"^(8|9|10)$"]["name"](${south},${west},${north},${east});
);
out center tags;`;

    const overpassRes = await fetch('https://overpass-api.de/api/interpreter', {
      method: 'POST',
      body: overpassQuery,
      headers: { 'Content-Type': 'text/plain' }
    });
    const overpassData = await overpassRes.json();
    const osmNeighborhoods = (overpassData.elements || [])
      .map(el => ({
        name: el.tags?.name,
        lat: el.lat || el.center?.lat,
        lng: el.lon || el.center?.lon,
        place_type: el.tags?.place || el.tags?.landuse || el.tags?.boundary,
        admin_level: el.tags?.admin_level,
      }))
      .filter(n => n.name && n.name.length > 1)
      // deduplicate by name
      .filter((n, i, arr) => arr.findIndex(x => x.name === n.name) === i);

    console.log(`[neighborhoodIntel] OSM neighborhoods found: ${osmNeighborhoods.length}`);

    // Step 5: Derive ownership rate and other computed metrics per tract
    const enrichedTracts = tractData.map(t => ({
      ...t,
      ownership_rate: t.total_tenure > 0 ? Math.round((t.owner_occupied / t.total_tenure) * 100) : null,
      poverty_rate: t.poverty_universe > 0 ? Math.round((t.below_poverty / t.poverty_universe) * 100) : null,
      education_rate: t.education_universe > 0 ? Math.round((t.bachelors_degree / t.education_universe) * 100) : null,
      vacancy_rate: t.total_housing > 0 ? Math.round(((t.total_housing - t.occupied_housing) / t.total_housing) * 100) : null,
    }));

    // Step 6: Use LLM to merge OSM neighborhoods + tract data into scored neighborhood list
    const prompt = `You are a door-to-door canvassing intelligence system with access to the internet.

ZIP Code: ${zip}
Area: ${city}

First, search the internet for "${city} neighborhoods" and "${zip} neighborhoods" to find every REAL named neighborhood, subdivision, and community in this specific area. Examples of the kind of names we want: "Bonner Hills", "Riverside Heights", "Oak Park", "Maple Subdivision", etc. — actual named places people use.

OSM data found for this area (${osmNeighborhoods.length} results):
${osmNeighborhoods.map(n => `- ${n.name} (${n.place_type || 'area'})`).join('\n') || 'None found in OSM — rely on internet search'}

Census tract demographic data for ${enrichedTracts.length} tracts in this county:
${enrichedTracts.slice(0, 40).map(t => `Tract ${t.tract_id}: pop=${t.total_population}, med_income=$${t.median_income?.toLocaleString() || 'N/A'}, med_home_value=$${t.median_home_value?.toLocaleString() || 'N/A'}, ownership=${t.ownership_rate}%, med_age=${t.median_age}, poverty_rate=${t.poverty_rate}%`).join('\n')}

Your task: Return EVERY actual named neighborhood, subdivision, and community within or immediately adjacent to ZIP ${zip}. These should be real names that locals use — subdivisions, historic districts, named communities. Do NOT return vague names like "North Area" or "Census Tract 1234". If a neighborhood spans ZIP boundaries, still include it.

For each neighborhood:
1. Use the closest matching census tract for real demographic data
2. Calculate canvassing score 1-10 based on ownership rate, income, home values
3. Assign prospect type: homeowners, seniors, families, high_income, new_construction, renters
4. Add specific canvassing tips based on the demographics

Aim for completeness — include ALL named places you can find.`;

    const llmRes = await base44.asServiceRole.integrations.Core.InvokeLLM({
      prompt,
      model: 'gemini_3_flash',
      add_context_from_internet: true,
      response_json_schema: {
        type: 'object',
        properties: {
          city_summary: { type: 'string' },
          total_neighborhoods: { type: 'number' },
          area_overview: {
            type: 'object',
            properties: {
              median_income: { type: 'number' },
              avg_home_value: { type: 'number' },
              avg_ownership_rate: { type: 'number' },
              total_households: { type: 'number' },
              best_products: { type: 'array', items: { type: 'string' } },
            }
          },
          neighborhoods: {
            type: 'array',
            items: {
              type: 'object',
              properties: {
                name: { type: 'string' },
                score: { type: 'number' },
                primary_type: { type: 'string' },
                why_good: { type: 'string' },
                best_time: { type: 'string' },
                best_products: { type: 'array', items: { type: 'string' } },
                tips: { type: 'array', items: { type: 'string' } },
                estimated_homes: { type: 'number' },
                home_value_range: { type: 'string' },
                median_income: { type: 'number' },
                ownership_rate: { type: 'number' },
                median_age: { type: 'number' },
                poverty_rate: { type: 'number' },
                population: { type: 'number' },
                safety_note: { type: 'string' },
                data_source: { type: 'string' },
              }
            }
          }
        }
      }
    });

    console.log(`[neighborhoodIntel] LLM returned ${llmRes?.neighborhoods?.length} neighborhoods`);

    return Response.json({
      zip,
      city,
      lat,
      lng,
      osm_count: osmNeighborhoods.length,
      tract_count: enrichedTracts.length,
      ...llmRes,
      raw_tracts: enrichedTracts.slice(0, 50), // include for reference
    });

  } catch (error) {
    console.error('[neighborhoodIntel] Error:', error.message);
    return Response.json({ error: error.message }, { status: 500 });
  }
});