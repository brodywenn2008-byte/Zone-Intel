import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';
import Stripe from 'npm:stripe@14.21.0';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

    const { sessionId } = await req.json();
    if (!sessionId) return Response.json({ error: 'sessionId required' }, { status: 400 });

    const stripe = new Stripe(Deno.env.get('STRIPE_SECRET_KEY'));
    const session = await stripe.checkout.sessions.retrieve(sessionId);

    if (session.payment_status !== 'paid') {
      return Response.json({ error: 'Payment not completed' }, { status: 400 });
    }

    const { lead_id: leadId, buyer_id: buyerId, buyer_email: buyerEmail, seller_id: sellerId } = session.metadata;

    if (buyerId !== user.id) return Response.json({ error: 'Unauthorized' }, { status: 403 });

    // Idempotent: return existing transaction if already processed
    const existing = await base44.asServiceRole.entities.Transaction.filter({ stripe_session_id: sessionId });
    if (existing.length > 0) {
      const lead = await base44.asServiceRole.entities.Lead.get(leadId);
      console.log(`verifyLeadPurchase: returning existing transaction for session ${sessionId}`);
      return Response.json({ success: true, lead, transaction: existing[0] });
    }

    const lead = await base44.asServiceRole.entities.Lead.get(leadId);
    if (!lead) return Response.json({ error: 'Lead not found' }, { status: 404 });

    // Calculate fee split
    const totalPaid = session.amount_total / 100;
    const platformFeeCents = parseInt(session.metadata.platform_fee_cents || 0);
    const platformFee = platformFeeCents / 100;
    const sellerPayout = totalPaid - platformFee;

    // Get transfer ID if Connect was used
    let stripeTransferId = null;
    if (session.payment_intent) {
      try {
        const pi = await stripe.paymentIntents.retrieve(session.payment_intent);
        if (pi.transfer_data?.destination) {
          stripeTransferId = pi.latest_charge || null;
        }
      } catch (e) { /* ignore */ }
    }

    // Create transaction record
    const transaction = await base44.asServiceRole.entities.Transaction.create({
      buyer_id: user.id,
      buyer_email: user.email,
      seller_id: sellerId || '',
      lead_id: leadId,
      price: totalPaid,
      category: lead.category || '',
      status: 'completed',
      stripe_session_id: sessionId,
      stripe_transfer_id: stripeTransferId || '',
      platform_fee: platformFee,
      seller_payout: session.metadata.seller_account_id ? sellerPayout : 0,
      lead_snapshot: JSON.stringify(lead),
    });

    // Copy lead into buyer's CRM
    await base44.asServiceRole.entities.Lead.create({
      owner_name: lead.owner_name,
      phone: lead.phone,
      email: lead.email,
      address: lead.address,
      lat: lead.lat,
      lng: lead.lng,
      notes: lead.notes,
      category: lead.category,
      assigned_rep: user.email,
      status: 'not_visited',
      is_for_sale: false,
      listing_description: lead.listing_description,
      tags: ['marketplace_purchase', ...(lead.tags || [])],
    });

    console.log(`verifyLeadPurchase: lead ${leadId} purchased by ${user.email} for $${session.amount_total / 100}`);
    return Response.json({ success: true, lead, transaction });
  } catch (error) {
    console.error('verifyLeadPurchase error:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});