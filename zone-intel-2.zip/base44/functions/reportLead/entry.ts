import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

    const { leadId, reason, details } = await req.json();
    if (!leadId || !reason) return Response.json({ error: 'leadId and reason required' }, { status: 400 });

    const lead = await base44.asServiceRole.entities.Lead.get(leadId);
    if (!lead) return Response.json({ error: 'Lead not found' }, { status: 404 });

    // Create report record
    await base44.asServiceRole.entities.Report.create({
      lead_id: leadId,
      reporter_id: user.id,
      reporter_email: user.email,
      seller_id: lead.seller_id,
      reason,
      details: details || '',
      status: 'pending',
    });

    // Increment report count and flag if too many reports
    const newCount = (lead.report_count || 0) + 1;
    const updateData = { report_count: newCount };
    if (newCount >= 3) updateData.is_flagged = true;

    await base44.asServiceRole.entities.Lead.update(leadId, updateData);

    console.log(`Lead ${leadId} reported by ${user.email} for: ${reason}`);
    return Response.json({ success: true });
  } catch (error) {
    console.error('reportLead error:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});