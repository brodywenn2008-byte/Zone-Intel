import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';
import Stripe from 'npm:stripe@14.21.0';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

    if (!user.stripe_account_id) {
      return Response.json({ connected: false, onboarded: false });
    }

    const stripe = new Stripe(Deno.env.get('STRIPE_SECRET_KEY'));
    const account = await stripe.accounts.retrieve(user.stripe_account_id);

    const onboarded = account.charges_enabled && account.payouts_enabled;

    // Keep user record in sync
    if (onboarded && !user.stripe_onboarded) {
      await base44.auth.updateMe({ stripe_onboarded: true });
    }

    return Response.json({
      connected: true,
      onboarded,
      charges_enabled: account.charges_enabled,
      payouts_enabled: account.payouts_enabled,
      account_id: user.stripe_account_id,
      email: account.email,
      business_name: account.business_profile?.name || account.individual?.first_name || user.email,
    });
  } catch (error) {
    console.error('stripeConnectStatus error:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});