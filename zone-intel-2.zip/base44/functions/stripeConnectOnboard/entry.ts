import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';
import Stripe from 'npm:stripe@14.21.0';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

    const { returnUrl } = await req.json();
    const stripe = new Stripe(Deno.env.get('STRIPE_SECRET_KEY'));

    let accountId = user.stripe_account_id;

    // Create Express account if doesn't exist
    if (!accountId) {
      const account = await stripe.accounts.create({
        type: 'express',
        email: user.email,
        capabilities: {
          card_payments: { requested: true },
          transfers: { requested: true },
        },
        business_type: 'individual',
        metadata: {
          base44_user_id: user.id,
          base44_app_id: Deno.env.get('BASE44_APP_ID'),
        },
      });
      accountId = account.id;

      // Save account ID to user
      await base44.auth.updateMe({ stripe_account_id: accountId, stripe_onboarded: false });
      console.log(`stripeConnectOnboard: created account ${accountId} for ${user.email}`);
    }

    // Check if already fully onboarded
    const account = await stripe.accounts.retrieve(accountId);
    if (account.charges_enabled && account.payouts_enabled) {
      await base44.auth.updateMe({ stripe_onboarded: true });
      return Response.json({ alreadyOnboarded: true });
    }

    // Generate onboarding link
    const baseUrl = returnUrl || 'https://app.base44.app/marketplace';
    const accountLink = await stripe.accountLinks.create({
      account: accountId,
      refresh_url: `${baseUrl}?connect_refresh=true`,
      return_url: `${baseUrl}?connect_return=true`,
      type: 'account_onboarding',
    });

    console.log(`stripeConnectOnboard: onboarding link generated for ${user.email}`);
    return Response.json({ url: accountLink.url });
  } catch (error) {
    console.error('stripeConnectOnboard error:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});