import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';
import Stripe from 'npm:stripe@14.21.0';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

    const { leadId, successUrl, cancelUrl } = await req.json();
    if (!leadId) return Response.json({ error: 'leadId required' }, { status: 400 });

    const lead = await base44.asServiceRole.entities.Lead.get(leadId);
    if (!lead) return Response.json({ error: 'Lead not found' }, { status: 404 });
    if (!lead.is_for_sale) return Response.json({ error: 'Lead is not listed for sale' }, { status: 400 });
    if (lead.seller_id === user.id) return Response.json({ error: 'You cannot buy your own lead' }, { status: 400 });

    // Prevent duplicate purchase
    const existing = await base44.asServiceRole.entities.Transaction.filter({
      buyer_id: user.id,
      lead_id: leadId,
      status: 'completed',
    });
    if (existing.length > 0) return Response.json({ error: 'Already purchased', alreadyOwned: true }, { status: 400 });

    const stripe = new Stripe(Deno.env.get('STRIPE_SECRET_KEY'));
    const priceInCents = Math.round((lead.price || 10) * 100);
    const PLATFORM_FEE_PCT = 0.15; // 15% platform fee
    const platformFeeInCents = Math.round(priceInCents * PLATFORM_FEE_PCT);

    // Look up seller's Stripe Connect account
    let sellerStripeAccountId = null;
    if (lead.seller_id) {
      try {
        const seller = await base44.asServiceRole.entities.User.get(lead.seller_id);
        if (seller?.stripe_onboarded && seller?.stripe_account_id) {
          sellerStripeAccountId = seller.stripe_account_id;
        }
      } catch (e) {
        console.warn('buyLead: could not fetch seller Stripe account:', e.message);
      }
    }

    const CATEGORY_LABELS = {
      life_insurance: 'Life Insurance Lead',
      health_insurance: 'Health Insurance Lead',
      auto_insurance: 'Auto Insurance Lead',
      homeowners_insurance: 'Homeowners Insurance Lead',
      business_insurance: 'Business Insurance Lead',
      medicare: 'Medicare Health Plan Lead',
      real_estate: 'Real Estate Lead',
      mortgage_refinance: 'Mortgage Refinance Lead',
      personal_loans: 'Personal Loans / Credit Repair Lead',
      business_loans: 'Business Loans / MCA Lead',
      legal: 'Legal Lead',
      solar_home_services: 'Solar / Home Services Lead',
      b2b_saas: 'B2B SaaS Lead',
      telecom_utilities: 'Telecom / Utilities Lead',
      education_career: 'Education / Career Lead',
    };
    const productName = CATEGORY_LABELS[lead.category] || 'Lead';
    const city = [lead.city, lead.state, lead.zip_code].filter(Boolean).join(', ') ||
      (lead.address ? lead.address.split(',').slice(-2).join(',').trim() : 'Unknown area');

    const sessionParams = {
      payment_method_types: ['card'],
      mode: 'payment',
      line_items: [{
        price_data: {
          currency: 'usd',
          unit_amount: priceInCents,
          product_data: {
            name: productName,
            description: `${lead.listing_description || 'Qualified lead'} · ${city}`,
          },
        },
        quantity: 1,
      }],
      success_url: `${successUrl}&session_id={CHECKOUT_SESSION_ID}`,
      cancel_url: cancelUrl,
      customer_email: user.email,
      metadata: {
        base44_app_id: Deno.env.get('BASE44_APP_ID'),
        lead_id: leadId,
        buyer_id: user.id,
        buyer_email: user.email,
        seller_id: lead.seller_id || '',
        platform_fee_cents: platformFeeInCents.toString(),
        seller_account_id: sellerStripeAccountId || '',
      },
    };

    // Add Stripe Connect payout if seller is onboarded
    if (sellerStripeAccountId) {
      sessionParams.payment_intent_data = {
        application_fee_amount: platformFeeInCents,
        transfer_data: { destination: sellerStripeAccountId },
      };
      console.log(`buyLead: routing payout to seller ${lead.seller_id} (${sellerStripeAccountId}), fee: $${(platformFeeInCents/100).toFixed(2)}`);
    } else {
      console.log(`buyLead: no seller Stripe account — platform collects full $${lead.price}`);
    }

    const session = await stripe.checkout.sessions.create(sessionParams);

    console.log(`buyLead: user ${user.email} initiating purchase of lead ${leadId} for $${lead.price}`);
    return Response.json({ url: session.url });
  } catch (error) {
    console.error('buyLead error:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});