import { useState } from "react";
import { SlidersHorizontal, ChevronDown, ChevronUp, X } from "lucide-react";
import { Button } from "@/components/ui/button";

const TRENDS = [
  { value: "rising", label: "↑ Rising", color: "#16a34a", bg: "#f0fdf4" },
  { value: "stable", label: "→ Stable", color: "#d97706", bg: "#fffbeb" },
  { value: "declining", label: "↓ Declining", color: "#dc2626", bg: "#fef2f2" },
];

const SERVICES = [
  { value: "solar", label: "☀️ Solar", color: "#d97706", bg: "#fffbeb" },
  { value: "pest_control", label: "🐛 Pest Control", color: "#16a34a", bg: "#f0fdf4" },
  { value: "power_washing", label: "💧 Power Washing", color: "#2563eb", bg: "#eff6ff" },
  { value: "car_detailing", label: "🚗 Car Detailing", color: "#7c3aed", bg: "#f5f3ff" },
  { value: "window_washing", label: "🪟 Window Washing", color: "#0891b2", bg: "#ecfeff" },
];

const DEFAULT_FILTERS = {
  services: [],
};

function hasActiveFilters(filters) {
  return filters.services?.length > 0;
}

export default function FilterPanel({ filters, onChange }) {
  const [open, setOpen] = useState(false);

  const update = (key, val) => onChange({ ...filters, [key]: val });

  const reset = () => onChange(DEFAULT_FILTERS);
  const active = hasActiveFilters(filters);

  return (
    <div className="px-5 mb-4">
      <button
        onClick={() => setOpen((o) => !o)}
        className="w-full flex items-center justify-between px-4 py-2.5 rounded-xl border border-border bg-card shadow-sm text-sm font-semibold text-foreground hover:bg-muted/50 transition-colors"
      >
        <div className="flex items-center gap-2">
          <SlidersHorizontal className="w-4 h-4 text-primary" />
          <span>Filter Map</span>
          {active && (
            <span className="bg-primary text-primary-foreground text-xs font-bold px-2 py-0.5 rounded-full">
              Active
            </span>
          )}
        </div>
        {open ? <ChevronUp className="w-4 h-4 text-muted-foreground" /> : <ChevronDown className="w-4 h-4 text-muted-foreground" />}
      </button>

      {open && (
        <div className="mt-2 bg-card border border-border rounded-xl shadow-sm p-4 space-y-4">
          {/* Service Interest */}
          <div>
            <p className="text-xs font-bold uppercase tracking-wider text-muted-foreground mb-2">Service Interest</p>
            <div className="flex flex-wrap gap-2">
              {SERVICES.map((s) => {
                const selected = (filters.services || []).includes(s.value);
                return (
                  <button
                    key={s.value}
                    onClick={() => {
                      const next = selected
                        ? (filters.services || []).filter((v) => v !== s.value)
                        : [...(filters.services || []), s.value];
                      update("services", next);
                    }}
                    className="text-xs font-semibold px-3 py-1.5 rounded-full border transition-all"
                    style={{
                      color: selected ? "white" : s.color,
                      backgroundColor: selected ? s.color : s.bg,
                      borderColor: s.color,
                    }}
                  >
                    {s.label}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Reset */}
          {active && (
            <Button variant="outline" size="sm" className="w-full gap-1.5" onClick={reset}>
              <X className="w-3.5 h-3.5" /> Clear Filters
            </Button>
          )}
        </div>
      )}
    </div>
  );
}

export { DEFAULT_FILTERS, SERVICES };