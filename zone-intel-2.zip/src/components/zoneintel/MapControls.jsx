import { Navigation, Eye, EyeOff, RefreshCw, Loader2, Star, Flame } from "lucide-react";

export default function MapControls({
  onRecenter,
  showUnvisitedOnly, onToggleUnvisited,
  highlightTop, onToggleHighlight,
  onRefresh, loading,
  showHeatmap, onToggleHeatmap,
}) {
  const btnClass = (active) =>
    `w-10 h-10 rounded-xl border flex items-center justify-center shadow-lg transition-all active:scale-95 ${
      active
        ? "bg-primary border-primary text-white"
        : "bg-gray-900/90 backdrop-blur-sm border-white/10 text-gray-300 hover:text-white"
    }`;

  return (
    <div className="flex flex-col gap-2">
      <button onClick={onRecenter} className={btnClass(false)} title="Re-center on my location">
        <Navigation className="w-4 h-4" />
      </button>

      <button onClick={onToggleHeatmap} className={btnClass(showHeatmap)} title="Heat density map">
        <Flame className="w-4 h-4" />
      </button>

      <button onClick={onToggleUnvisited} className={btnClass(showUnvisitedOnly)} title="Show unvisited only">
        {showUnvisitedOnly ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
      </button>

      <button onClick={onToggleHighlight} className={btnClass(highlightTop)} title="Highlight top neighborhoods">
        <Star className="w-4 h-4" />
      </button>

      <button onClick={onRefresh} disabled={loading} className={btnClass(false)} title="Refresh data">
        {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : <RefreshCw className="w-4 h-4" />}
      </button>
    </div>
  );
}