import { useState } from "react";
import { X, Phone, User, CheckCircle, XCircle, MinusCircle, MapPin } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";

const INTEREST_OPTIONS = [
  { value: "yes", label: "✅ Yes", desc: "Interested", color: "bg-emerald-500 text-white border-emerald-500" },
  { value: "maybe", label: "🤔 Maybe", desc: "Follow up", color: "bg-amber-500 text-white border-amber-500" },
  { value: "no", label: "❌ No", desc: "Not interested", color: "bg-red-500 text-white border-red-500" },
];

export default function ContactSheet({ parcel, contact, onSave, onClose }) {
  const props = parcel?.properties || {};
  const addr = props.address || props.siteaddr || props.ll_address || props.street || "Unknown Address";
  const regridOwner = props.owner || props.ownernme1 || props.ownername || "";
  const regridValue = props.parval || props.improvval || props.landval || props.totalval || null;
  const regridArea = props.ll_gisacre ? `${Number(props.ll_gisacre).toFixed(2)} acres` : props.sqft ? `${Number(props.sqft).toLocaleString()} sq ft` : null;
  const regridYearBuilt = props.yearbuilt || props.year_built || null;
  const regridUse = props.usedesc || props.propclass || props.land_use || null;

  const [name, setName] = useState(contact?.name || regridOwner);
  const [phone, setPhone] = useState(contact?.phone || "");
  const [answered, setAnswered] = useState(contact?.answered ?? null);
  const [interest, setInterest] = useState(contact?.interest || null);
  const [notes, setNotes] = useState(contact?.notes || "");

  const handleSave = () => {
    onSave({ name, phone, answered, interest, notes, addr, savedAt: new Date().toISOString() });
    onClose();
  };

  const hasData = name || phone || answered !== null || interest;

  return (
    <div className="fixed inset-0 z-50 flex items-end" onClick={onClose}>
      <div className="absolute inset-0 bg-black/60 backdrop-blur-sm" />
      <div
        className="relative w-full max-w-lg mx-auto bg-gray-900 rounded-t-3xl shadow-2xl border border-white/10 overflow-hidden"
        style={{ maxHeight: "90vh", overflowY: "auto" }}
        onClick={e => e.stopPropagation()}
      >
        {/* Handle */}
        <div className="flex justify-center pt-3 pb-1">
          <div className="w-10 h-1 rounded-full bg-white/20" />
        </div>

        {/* Header */}
        <div className="flex items-start justify-between px-5 pb-4 pt-2">
          <div className="flex-1 min-w-0">
            <p className="text-xs text-gray-400 font-semibold uppercase tracking-wider mb-0.5">Property</p>
            <p className="text-base font-bold text-white leading-tight flex items-center gap-1.5">
              <MapPin className="w-4 h-4 text-blue-400 flex-shrink-0" />
              <span className="truncate">{addr}</span>
            </p>
          </div>
          <button onClick={onClose} className="w-8 h-8 rounded-full bg-white/10 flex items-center justify-center ml-3 flex-shrink-0">
            <X className="w-4 h-4 text-gray-400" />
          </button>
        </div>

        <div className="px-5 space-y-5 pb-8">
          {/* Answered? */}
          <div>
            <p className="text-xs text-gray-400 font-semibold uppercase tracking-wider mb-2">Did they answer?</p>
            <div className="flex gap-2">
              <button
                onClick={() => setAnswered(true)}
                className={`flex-1 flex items-center justify-center gap-2 py-3 rounded-2xl border font-bold text-sm transition-all ${
                  answered === true ? "bg-emerald-500 border-emerald-500 text-white" : "border-white/15 text-gray-400 bg-white/5 hover:bg-white/10"
                }`}
              >
                <CheckCircle className="w-4 h-4" /> Answered
              </button>
              <button
                onClick={() => setAnswered(false)}
                className={`flex-1 flex items-center justify-center gap-2 py-3 rounded-2xl border font-bold text-sm transition-all ${
                  answered === false ? "bg-red-500 border-red-500 text-white" : "border-white/15 text-gray-400 bg-white/5 hover:bg-white/10"
                }`}
              >
                <XCircle className="w-4 h-4" /> No Answer
              </button>
            </div>
          </div>

          {/* Interest level */}
          <div>
            <p className="text-xs text-gray-400 font-semibold uppercase tracking-wider mb-2">Interest Level</p>
            <div className="flex gap-2">
              {INTEREST_OPTIONS.map(opt => (
                <button
                  key={opt.value}
                  onClick={() => setInterest(interest === opt.value ? null : opt.value)}
                  className={`flex-1 py-2.5 rounded-2xl border font-bold text-xs transition-all ${
                    interest === opt.value ? opt.color : "border-white/15 text-gray-400 bg-white/5 hover:bg-white/10"
                  }`}
                >
                  {opt.label}
                </button>
              ))}
            </div>
          </div>

          {/* Name */}
          <div>
            <label className="text-xs text-gray-400 font-semibold uppercase tracking-wider mb-2 block">
              <User className="w-3 h-3 inline mr-1" />Contact Name
            </label>
            <input
              value={name}
              onChange={e => setName(e.target.value)}
              placeholder="Homeowner name..."
              className="w-full bg-white/5 border border-white/15 rounded-xl px-4 py-3 text-white text-sm placeholder:text-gray-500 focus:outline-none focus:border-blue-500 focus:bg-white/8"
            />
          </div>

          {/* Phone */}
          <div>
            <label className="text-xs text-gray-400 font-semibold uppercase tracking-wider mb-2 block">
              <Phone className="w-3 h-3 inline mr-1" />Phone Number
            </label>
            <input
              value={phone}
              onChange={e => setPhone(e.target.value)}
              placeholder="(555) 000-0000"
              type="tel"
              className="w-full bg-white/5 border border-white/15 rounded-xl px-4 py-3 text-white text-sm placeholder:text-gray-500 focus:outline-none focus:border-blue-500"
            />
            {phone && (
              <a href={`tel:${phone}`} className="mt-1.5 flex items-center gap-1.5 text-xs text-blue-400 font-medium">
                <Phone className="w-3 h-3" /> Call now
              </a>
            )}
          </div>

          {/* Notes */}
          <div>
            <label className="text-xs text-gray-400 font-semibold uppercase tracking-wider mb-2 block">Notes</label>
            <textarea
              value={notes}
              onChange={e => setNotes(e.target.value)}
              placeholder="Quick notes about this visit..."
              rows={2}
              className="w-full bg-white/5 border border-white/15 rounded-xl px-4 py-3 text-white text-sm placeholder:text-gray-500 focus:outline-none focus:border-blue-500 resize-none"
            />
          </div>

          {/* Buttons */}
          <div className="flex gap-2 pt-1">
            {hasData && (
              <button
                onClick={() => { onSave(null); onClose(); }}
                className="px-4 py-3 rounded-2xl border border-white/15 text-gray-400 text-sm font-bold hover:bg-white/10"
              >
                Clear
              </button>
            )}
            <button
              onClick={handleSave}
              className="flex-1 py-3 rounded-2xl bg-blue-600 text-white text-sm font-bold hover:bg-blue-500 transition-colors"
            >
              Save Contact
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}