import { useState } from "react";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { X, UserPlus, Loader2, CheckCircle } from "lucide-react";

export default function QuickAddLeadModal({ onClose, onAdded }) {
  const [form, setForm] = useState({ owner_name: "", phone: "", address: "", notes: "" });
  const [saving, setSaving] = useState(false);
  const [done, setDone] = useState(false);

  const set = (k, v) => setForm(f => ({ ...f, [k]: v }));

  const handleSave = async () => {
    if (!form.address.trim() && !form.phone.trim()) return;
    setSaving(true);
    const user = await base44.auth.me();
    const lead = await base44.entities.Lead.create({
      owner_name: form.owner_name.trim(),
      phone: form.phone.trim(),
      address: form.address.trim() || form.owner_name.trim() || "Unknown",
      notes: form.notes.trim(),
      status: "not_visited",
      assigned_rep: user?.email || "",
    });
    setSaving(false);
    setDone(true);
    setTimeout(() => { onAdded(lead); }, 800);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-end">
      <div className="absolute inset-0 bg-black/60" onClick={onClose} />
      <div className="relative w-full max-w-lg mx-auto bg-card rounded-t-2xl shadow-2xl px-5 pt-5 pb-10">
        <div className="flex items-center gap-2 mb-5">
          <UserPlus className="w-5 h-5 text-primary" />
          <h2 className="font-bold text-foreground text-base flex-1">Quick Add Lead</h2>
          <button onClick={onClose} className="w-8 h-8 rounded-lg bg-muted flex items-center justify-center">
            <X className="w-4 h-4 text-muted-foreground" />
          </button>
        </div>

        <div className="space-y-3">
          <div>
            <label className="text-xs font-bold text-muted-foreground block mb-1">Name</label>
            <Input placeholder="Contact name" value={form.owner_name} onChange={e => set("owner_name", e.target.value)} className="h-10 text-sm" />
          </div>
          <div>
            <label className="text-xs font-bold text-muted-foreground block mb-1">Phone</label>
            <Input type="tel" placeholder="(555) 000-0000" value={form.phone} onChange={e => set("phone", e.target.value)} className="h-10 text-sm" />
          </div>
          <div>
            <label className="text-xs font-bold text-muted-foreground block mb-1">Address *</label>
            <Input placeholder="123 Main St, City, State" value={form.address} onChange={e => set("address", e.target.value)} className="h-10 text-sm" />
          </div>
          <div>
            <label className="text-xs font-bold text-muted-foreground block mb-1">Notes</label>
            <textarea placeholder="Any notes about this lead..." value={form.notes} onChange={e => set("notes", e.target.value)}
              rows={3} className="w-full text-sm border border-border rounded-xl px-3 py-2 bg-background text-foreground resize-none focus:outline-none focus:ring-1 focus:ring-ring placeholder:text-muted-foreground" />
          </div>
        </div>

        <div className="mt-5">
          {done ? (
            <div className="flex items-center justify-center gap-2 h-11 bg-green-50 border border-green-200 rounded-xl">
              <CheckCircle className="w-4 h-4 text-green-600" />
              <span className="text-sm font-bold text-green-700">Lead added!</span>
            </div>
          ) : (
            <Button onClick={handleSave} disabled={saving || (!form.address.trim() && !form.phone.trim())} className="w-full h-11 font-bold">
              {saving ? <Loader2 className="w-4 h-4 animate-spin" /> : "Add Lead"}
            </Button>
          )}
        </div>
      </div>
    </div>
  );
}