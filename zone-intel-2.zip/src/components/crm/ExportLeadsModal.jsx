import { useState, useMemo } from "react";
import { X, Download, Filter, CheckSquare, Square } from "lucide-react";
import { Button } from "@/components/ui/button";

const STATUS_LABELS = {
  not_visited: "Not Visited", knocked: "Knocked", interested: "Interested",
  follow_up: "Follow Up", appointment_set: "Appt Set", sold: "Sold",
  no_answer: "No Answer", not_interested: "Not Interested",
};

const CSV_COLUMNS = [
  { key: "owner_name",     label: "Name" },
  { key: "phone",          label: "Phone" },
  { key: "email",          label: "Email" },
  { key: "address",        label: "Address" },
  { key: "city",           label: "City" },
  { key: "state",          label: "State" },
  { key: "zip_code",       label: "ZIP" },
  { key: "status",         label: "Status",      transform: v => STATUS_LABELS[v] || v },
  { key: "assigned_rep",   label: "Assigned Rep" },
  { key: "notes",          label: "Notes" },
  { key: "home_value",     label: "Home Value" },
  { key: "ai_priority",    label: "AI Priority" },
  { key: "category",       label: "Category" },
  { key: "lead_score",     label: "Lead Score" },
  { key: "created_date",   label: "Created",     transform: v => v ? new Date(v).toLocaleDateString() : "" },
  { key: "updated_date",   label: "Last Updated",transform: v => v ? new Date(v).toLocaleDateString() : "" },
];

function downloadCSV(leads, columns) {
  const headers = columns.map(c => c.label);
  const rows = leads.map(lead =>
    columns.map(c => {
      const raw = lead[c.key] ?? "";
      const val = c.transform ? c.transform(raw) : raw;
      return `"${String(val).replace(/"/g, '""')}"`;
    }).join(",")
  );
  const csv = [headers.join(","), ...rows].join("\n");
  const blob = new Blob([csv], { type: "text/csv" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = `leads-export-${new Date().toISOString().slice(0, 10)}.csv`;
  a.click();
  URL.revokeObjectURL(url);
}

export default function ExportLeadsModal({ leads, onClose }) {
  const [statusFilter, setStatusFilter] = useState([]);
  const [repFilter, setRepFilter] = useState("all");
  const [dateFrom, setDateFrom] = useState("");
  const [dateTo, setDateTo] = useState("");
  const [selectedCols, setSelectedCols] = useState(
    new Set(["owner_name", "phone", "email", "address", "status", "assigned_rep", "notes", "created_date"])
  );

  // Derive unique reps
  const allReps = useMemo(() => {
    const reps = [...new Set(leads.map(l => l.assigned_rep).filter(Boolean))];
    return reps.sort();
  }, [leads]);

  const toggleStatus = (s) =>
    setStatusFilter(prev => prev.includes(s) ? prev.filter(x => x !== s) : [...prev, s]);

  const toggleCol = (key) =>
    setSelectedCols(prev => {
      const next = new Set(prev);
      next.has(key) ? next.delete(key) : next.add(key);
      return next;
    });

  const filtered = useMemo(() => {
    return leads.filter(l => {
      if (statusFilter.length && !statusFilter.includes(l.status)) return false;
      if (repFilter !== "all" && l.assigned_rep !== repFilter) return false;
      if (dateFrom && new Date(l.created_date) < new Date(dateFrom)) return false;
      if (dateTo && new Date(l.created_date) > new Date(dateTo + "T23:59:59")) return false;
      return true;
    });
  }, [leads, statusFilter, repFilter, dateFrom, dateTo]);

  const exportCols = CSV_COLUMNS.filter(c => selectedCols.has(c.key));

  const handleExport = () => {
    downloadCSV(filtered, exportCols);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center">
      <div className="absolute inset-0 bg-black/60" onClick={onClose} />
      <div className="relative w-full max-w-lg bg-card rounded-t-2xl sm:rounded-2xl shadow-2xl overflow-hidden max-h-[90vh] flex flex-col">
        {/* Header */}
        <div className="flex items-center gap-2 px-5 py-4 border-b border-border">
          <Download className="w-4 h-4 text-primary" />
          <h2 className="font-bold text-foreground text-sm flex-1">Export Leads as CSV</h2>
          <button onClick={onClose} className="w-8 h-8 rounded-lg bg-muted flex items-center justify-center">
            <X className="w-4 h-4 text-muted-foreground" />
          </button>
        </div>

        <div className="overflow-y-auto flex-1 px-5 py-4 space-y-5">
          {/* Status filter */}
          <div>
            <p className="text-xs font-bold text-muted-foreground uppercase tracking-wide mb-2">Filter by Status</p>
            <div className="flex flex-wrap gap-1.5">
              {Object.entries(STATUS_LABELS).map(([key, label]) => (
                <button key={key} onClick={() => toggleStatus(key)}
                  className={`text-xs font-semibold px-3 py-1.5 rounded-full border transition-colors ${
                    statusFilter.includes(key)
                      ? "bg-primary text-white border-primary"
                      : "bg-muted text-muted-foreground border-border hover:border-primary"
                  }`}>
                  {label}
                </button>
              ))}
            </div>
            {statusFilter.length > 0 && (
              <button onClick={() => setStatusFilter([])} className="mt-1.5 text-xs text-primary font-bold">
                Clear filter
              </button>
            )}
          </div>

          {/* Rep filter */}
          {allReps.length > 0 && (
            <div>
              <p className="text-xs font-bold text-muted-foreground uppercase tracking-wide mb-2">Filter by Rep</p>
              <select value={repFilter} onChange={e => setRepFilter(e.target.value)}
                className="w-full h-9 text-sm border border-border rounded-lg px-3 bg-background text-foreground focus:outline-none focus:ring-1 focus:ring-ring">
                <option value="all">All Reps</option>
                {allReps.map(r => <option key={r} value={r}>{r}</option>)}
              </select>
            </div>
          )}

          {/* Date range */}
          <div>
            <p className="text-xs font-bold text-muted-foreground uppercase tracking-wide mb-2">Filter by Created Date</p>
            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className="text-xs text-muted-foreground mb-1 block">From</label>
                <input type="date" value={dateFrom} onChange={e => setDateFrom(e.target.value)}
                  className="w-full h-9 text-sm border border-border rounded-lg px-3 bg-background text-foreground focus:outline-none focus:ring-1 focus:ring-ring" />
              </div>
              <div>
                <label className="text-xs text-muted-foreground mb-1 block">To</label>
                <input type="date" value={dateTo} onChange={e => setDateTo(e.target.value)}
                  className="w-full h-9 text-sm border border-border rounded-lg px-3 bg-background text-foreground focus:outline-none focus:ring-1 focus:ring-ring" />
              </div>
            </div>
          </div>

          {/* Column picker */}
          <div>
            <p className="text-xs font-bold text-muted-foreground uppercase tracking-wide mb-2">Columns to Include</p>
            <div className="grid grid-cols-2 gap-1.5">
              {CSV_COLUMNS.map(col => {
                const on = selectedCols.has(col.key);
                return (
                  <button key={col.key} onClick={() => toggleCol(col.key)}
                    className={`flex items-center gap-2 px-3 py-2 rounded-lg border text-xs font-medium transition-colors text-left ${
                      on ? "bg-primary/10 border-primary/40 text-primary" : "bg-muted border-border text-muted-foreground"
                    }`}>
                    {on ? <CheckSquare className="w-3.5 h-3.5 flex-shrink-0" /> : <Square className="w-3.5 h-3.5 flex-shrink-0" />}
                    {col.label}
                  </button>
                );
              })}
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="px-5 py-4 border-t border-border bg-muted/30 flex items-center justify-between gap-3">
          <p className="text-xs text-muted-foreground">
            <span className="font-bold text-foreground">{filtered.length}</span> lead{filtered.length !== 1 ? "s" : ""} · {exportCols.length} columns
          </p>
          <Button onClick={handleExport} disabled={filtered.length === 0 || exportCols.length === 0} className="gap-2 h-9 text-sm font-bold">
            <Download className="w-4 h-4" /> Download CSV
          </Button>
        </div>
      </div>
    </div>
  );
}