import { useMemo } from "react";
import { Trophy, Medal, Star, Target } from "lucide-react";

const DAILY_GOALS = { knocked: 50, interested: 10, appointment_set: 3, sold: 1 };
const GOAL_KEYS = ["knocked", "interested", "appointment_set", "sold"];

const RANK_CONFIG = [
  { rank: 1, icon: "🥇", trophy: Trophy,  color: "text-yellow-500", bg: "bg-yellow-50 border-yellow-200",  badge: "Top Performer" },
  { rank: 2, icon: "🥈", trophy: Medal,   color: "text-slate-400",  bg: "bg-slate-50 border-slate-200",    badge: "2nd Place" },
  { rank: 3, icon: "🥉", trophy: Medal,   color: "text-amber-600",  bg: "bg-amber-50 border-amber-200",    badge: "3rd Place" },
];

export default function TeamLeaderboard({ leads }) {
  const todayStart = useMemo(() => {
    const d = new Date(); d.setHours(0, 0, 0, 0); return d;
  }, []);

  // Group leads by assigned_rep, count today's statuses
  const reps = useMemo(() => {
    const map = {};
    for (const lead of leads) {
      const rep = lead.assigned_rep || "Unassigned";
      if (!map[rep]) map[rep] = { rep, sold: 0, todayCounts: {} };
      if (lead.status === "sold") map[rep].sold++;
      if (new Date(lead.updated_date) >= todayStart) {
        map[rep].todayCounts[lead.status] = (map[rep].todayCounts[lead.status] || 0) + 1;
      }
    }

    return Object.values(map)
      .map(r => {
        // Load per-rep goals from localStorage or use defaults
        let goals;
        try { goals = JSON.parse(localStorage.getItem("crm_daily_goals")) || DAILY_GOALS; }
        catch { goals = DAILY_GOALS; }

        const totalGoalPct = GOAL_KEYS.reduce((sum, key) => {
          const pct = Math.min(100, ((r.todayCounts[key] || 0) / (goals[key] || 1)) * 100);
          return sum + pct;
        }, 0) / GOAL_KEYS.length;

        return { ...r, goalPct: Math.round(totalGoalPct) };
      })
      .sort((a, b) => b.sold !== a.sold ? b.sold - a.sold : b.goalPct - a.goalPct)
      .slice(0, 10);
  }, [leads, todayStart]);

  if (reps.length === 0) return null;

  const topGoalPct = Math.max(...reps.map(r => r.goalPct));

  return (
    <div className="bg-card border border-border rounded-2xl overflow-hidden">
      {/* Header */}
      <div className="flex items-center gap-2 px-4 py-3 border-b border-border bg-gradient-to-r from-yellow-50 to-card">
        <Trophy className="w-4 h-4 text-yellow-500" />
        <p className="text-sm font-bold text-foreground flex-1">Team Leaderboard</p>
        <span className="text-xs text-muted-foreground bg-muted px-2 py-0.5 rounded-full">
          {reps.length} reps
        </span>
      </div>

      <div className="divide-y divide-border">
        {reps.map((rep, idx) => {
          const rankCfg = RANK_CONFIG[idx] || null;
          const isTop = idx === 0;
          const nameParts = rep.rep.includes("@") ? rep.rep.split("@")[0] : rep.rep;
          const displayName = nameParts.split(".").map(w => w.charAt(0).toUpperCase() + w.slice(1)).join(" ");
          const initials = displayName.split(" ").map(w => w[0]).join("").slice(0, 2).toUpperCase();

          return (
            <div key={rep.rep}
              className={`px-4 py-3 flex items-center gap-3 ${isTop ? "bg-yellow-50/40" : ""}`}>
              {/* Rank */}
              <div className="w-7 text-center flex-shrink-0">
                {rankCfg ? (
                  <span className="text-lg">{rankCfg.icon}</span>
                ) : (
                  <span className="text-xs font-bold text-muted-foreground">#{idx + 1}</span>
                )}
              </div>

              {/* Avatar */}
              <div className={`w-9 h-9 rounded-full flex items-center justify-center text-xs font-black flex-shrink-0 border-2 ${
                isTop ? "bg-yellow-100 border-yellow-300 text-yellow-800" : "bg-muted border-border text-muted-foreground"
              }`}>
                {initials}
              </div>

              {/* Info */}
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 flex-wrap">
                  <p className="text-sm font-bold text-foreground truncate">{displayName}</p>
                  {isTop && (
                    <span className="flex items-center gap-1 text-xs font-bold text-yellow-700 bg-yellow-100 border border-yellow-300 px-2 py-0.5 rounded-full flex-shrink-0">
                      <Star className="w-2.5 h-2.5 fill-yellow-500 text-yellow-500" /> Top Performer
                    </span>
                  )}
                </div>
                {/* Goal progress bar */}
                <div className="flex items-center gap-2 mt-1">
                  <div className="flex-1 h-1.5 bg-muted rounded-full overflow-hidden">
                    <div
                      className={`h-full rounded-full transition-all ${isTop ? "bg-yellow-400" : "bg-primary/60"}`}
                      style={{ width: `${rep.goalPct}%` }}
                    />
                  </div>
                  <span className="text-xs text-muted-foreground flex-shrink-0">{rep.goalPct}% goal</span>
                </div>
              </div>

              {/* Sold count */}
              <div className="text-right flex-shrink-0">
                <div className="flex items-center gap-1 justify-end">
                  <Trophy className={`w-3.5 h-3.5 ${isTop ? "text-yellow-500" : "text-muted-foreground"}`} />
                  <span className={`text-base font-black ${isTop ? "text-yellow-600" : "text-foreground"}`}>
                    {rep.sold}
                  </span>
                </div>
                <p className="text-xs text-muted-foreground">closed</p>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}