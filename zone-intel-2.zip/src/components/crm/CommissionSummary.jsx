import { useMemo } from "react";
import { DollarSign, TrendingUp, Trophy } from "lucide-react";

const CATEGORIES = {
  life_insurance:       { emoji: "❤️",  label: "Life Ins." },
  health_insurance:     { emoji: "🏥",  label: "Health Ins." },
  auto_insurance:       { emoji: "🚗",  label: "Auto Ins." },
  homeowners_insurance: { emoji: "🏠",  label: "Homeowners" },
  business_insurance:   { emoji: "🏢",  label: "Business Ins." },
  medicare:             { emoji: "💊",  label: "Medicare" },
  real_estate:          { emoji: "🏡",  label: "Real Estate" },
  mortgage_refinance:   { emoji: "🏦",  label: "Mortgage" },
  personal_loans:       { emoji: "💳",  label: "Personal Loans" },
  business_loans:       { emoji: "💼",  label: "Biz Loans" },
  legal:                { emoji: "⚖️",  label: "Legal" },
  solar_home_services:  { emoji: "☀️",  label: "Solar" },
  b2b_saas:             { emoji: "💻",  label: "B2B" },
  telecom_utilities:    { emoji: "📡",  label: "Telecom" },
  education_career:     { emoji: "🎓",  label: "Education" },
};

function calcCommission(lead, commissionMap) {
  const setting = commissionMap[lead.category] || commissionMap["default"];
  if (!setting) return 100; // fallback $100
  if (setting.commission_type === "percent") {
    return ((lead.price || 0) * setting.amount) / 100;
  }
  return setting.amount || 0;
}

export default function CommissionSummary({ leads, commissionSettings }) {
  // Build a map of category -> setting
  const commissionMap = useMemo(() => {
    const map = {};
    commissionSettings.forEach(s => { map[s.category] = s; });
    return map;
  }, [commissionSettings]);

  const soldLeads = useMemo(() => leads.filter(l => l.status === "sold"), [leads]);

  // Per-rep aggregation
  const repSummaries = useMemo(() => {
    const map = {};
    for (const lead of soldLeads) {
      const rep = lead.assigned_rep || "Unassigned";
      if (!map[rep]) map[rep] = { rep, total: 0, count: 0, breakdown: {} };
      const comm = calcCommission(lead, commissionMap);
      map[rep].total += comm;
      map[rep].count++;
      const cat = lead.category || "default";
      map[rep].breakdown[cat] = (map[rep].breakdown[cat] || 0) + 1;
    }
    return Object.values(map).sort((a, b) => b.total - a.total);
  }, [soldLeads, commissionMap]);

  const grandTotal = repSummaries.reduce((s, r) => s + r.total, 0);

  const fmt = (n) => new Intl.NumberFormat("en-US", { style: "currency", currency: "USD", maximumFractionDigits: 0 }).format(n);

  if (repSummaries.length === 0) return (
    <div className="bg-card border border-border rounded-2xl px-4 py-12 text-center">
      <p className="text-3xl mb-2">💰</p>
      <p className="font-bold text-foreground">No closed leads yet</p>
      <p className="text-sm text-muted-foreground mt-1">Commissions will appear here once reps start closing deals.</p>
    </div>
  );

  return (
    <div className="space-y-3">
      {/* Grand total banner */}
      <div className="bg-gradient-to-br from-emerald-600 to-emerald-500 rounded-2xl p-5 text-white">
        <div className="flex items-center gap-2 mb-1">
          <TrendingUp className="w-4 h-4 text-emerald-200" />
          <span className="text-xs font-bold text-emerald-100 uppercase tracking-wide">Team Projected Earnings</span>
        </div>
        <p className="text-4xl font-black mt-2">{fmt(grandTotal)}</p>
        <p className="text-sm text-emerald-100 mt-1">{soldLeads.length} closed lead{soldLeads.length !== 1 ? "s" : ""} · {repSummaries.length} rep{repSummaries.length !== 1 ? "s" : ""}</p>
      </div>

      {/* Per-rep cards */}
      {repSummaries.map((r, idx) => {
        const nameParts = r.rep.includes("@") ? r.rep.split("@")[0] : r.rep;
        const displayName = nameParts.split(".").map(w => w.charAt(0).toUpperCase() + w.slice(1)).join(" ");
        const initials = displayName.split(" ").map(w => w[0]).join("").slice(0, 2).toUpperCase();
        const isTop = idx === 0;
        const pct = grandTotal > 0 ? Math.round((r.total / grandTotal) * 100) : 0;

        return (
          <div key={r.rep} className={`bg-card border rounded-2xl overflow-hidden ${isTop ? "border-emerald-300" : "border-border"}`}>
            <div className={`px-4 py-3 flex items-center gap-3 ${isTop ? "bg-emerald-50" : ""}`}>
              {/* Rank + avatar */}
              <div className={`w-9 h-9 rounded-full flex items-center justify-center text-xs font-black flex-shrink-0 border-2 ${
                isTop ? "bg-emerald-100 border-emerald-300 text-emerald-800" : "bg-muted border-border text-muted-foreground"
              }`}>
                {initials}
              </div>

              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2">
                  <p className="text-sm font-bold text-foreground truncate">{displayName}</p>
                  {isTop && (
                    <span className="text-xs font-bold text-emerald-700 bg-emerald-100 border border-emerald-300 px-2 py-0.5 rounded-full flex-shrink-0 flex items-center gap-1">
                      <Trophy className="w-2.5 h-2.5" /> Top Earner
                    </span>
                  )}
                </div>
                <p className="text-xs text-muted-foreground">{r.count} deal{r.count !== 1 ? "s" : ""} closed · {pct}% of team</p>
              </div>

              <div className="text-right flex-shrink-0">
                <p className={`text-base font-black ${isTop ? "text-emerald-600" : "text-foreground"}`}>{fmt(r.total)}</p>
                <div className="flex items-center gap-1 justify-end mt-0.5">
                  <DollarSign className="w-3 h-3 text-muted-foreground" />
                  <span className="text-xs text-muted-foreground">{fmt(r.total / r.count)} / deal</span>
                </div>
              </div>
            </div>

            {/* Category breakdown */}
            {Object.keys(r.breakdown).length > 0 && (
              <div className="px-4 pb-3 flex flex-wrap gap-1.5 border-t border-border pt-2">
                {Object.entries(r.breakdown).map(([cat, cnt]) => {
                  const meta = CATEGORIES[cat];
                  return (
                    <span key={cat} className="text-xs bg-muted rounded-full px-2.5 py-1 text-muted-foreground font-medium">
                      {meta ? `${meta.emoji} ${meta.label}` : cat} ×{cnt}
                    </span>
                  );
                })}
              </div>
            )}
          </div>
        );
      })}
    </div>
  );
}