import { useState, useRef } from "react";
import { base44 } from "@/api/base44Client";
import { Phone, MapPin, DollarSign } from "lucide-react";

const STAGES = [
  { id: "knocked",         label: "Contacted",   color: "blue",   emoji: "📞" },
  { id: "follow_up",       label: "Follow Up",   color: "yellow", emoji: "🔁" },
  { id: "appointment_set", label: "Appt Set",    color: "purple", emoji: "📅" },
  { id: "sold",            label: "Sold",        color: "emerald",emoji: "✅" },
];

const STAGE_COLORS = {
  blue:    { header: "bg-blue-50 border-blue-200",    dot: "bg-blue-400",    count: "bg-blue-100 text-blue-700"    },
  yellow:  { header: "bg-yellow-50 border-yellow-200",dot: "bg-yellow-400",  count: "bg-yellow-100 text-yellow-700"},
  purple:  { header: "bg-purple-50 border-purple-200",dot: "bg-purple-400",  count: "bg-purple-100 text-purple-700"},
  emerald: { header: "bg-emerald-50 border-emerald-200",dot:"bg-emerald-400",count: "bg-emerald-100 text-emerald-700"},
};

function LeadCard({ lead, onDragStart }) {
  return (
    <div
      draggable
      onDragStart={(e) => onDragStart(e, lead)}
      className="bg-card border border-border rounded-xl p-3 cursor-grab active:cursor-grabbing hover:shadow-md transition-shadow select-none"
    >
      <p className="text-sm font-semibold text-foreground truncate mb-1">
        {lead.owner_name || <span className="text-muted-foreground italic font-normal">Unknown</span>}
      </p>
      {lead.phone && (
        <div className="flex items-center gap-1 mb-1">
          <Phone className="w-3 h-3 text-muted-foreground flex-shrink-0" />
          <a href={`tel:${lead.phone}`} onClick={e => e.stopPropagation()}
            className="text-xs text-primary font-medium truncate">{lead.phone}</a>
        </div>
      )}
      {lead.address && (
        <div className="flex items-center gap-1 mb-1">
          <MapPin className="w-3 h-3 text-muted-foreground flex-shrink-0" />
          <p className="text-xs text-muted-foreground truncate">{lead.address}</p>
        </div>
      )}
      <div className="flex items-center justify-between mt-2">
        {lead.home_value ? (
          <span className="flex items-center gap-0.5 text-xs text-muted-foreground">
            <DollarSign className="w-3 h-3" />{lead.home_value.toLocaleString()}
          </span>
        ) : <span />}
        {lead.tags?.includes("marketplace_purchase") && (
          <span className="text-xs font-bold text-emerald-600 bg-emerald-50 px-1.5 py-0.5 rounded-md">Purchased</span>
        )}
      </div>
    </div>
  );
}

function KanbanColumn({ stage, leads, onDrop, onDragOver, onDragLeave, isDragOver }) {
  const colors = STAGE_COLORS[stage.color];
  return (
    <div className="flex flex-col min-w-[220px] w-[220px] flex-shrink-0">
      {/* Column header */}
      <div className={`flex items-center gap-2 px-3 py-2 rounded-xl border mb-2 ${colors.header}`}>
        <span className="text-base">{stage.emoji}</span>
        <span className="text-sm font-bold text-foreground flex-1">{stage.label}</span>
        <span className={`text-xs font-bold px-1.5 py-0.5 rounded-full ${colors.count}`}>{leads.length}</span>
      </div>

      {/* Drop zone */}
      <div
        onDragOver={onDragOver}
        onDrop={onDrop}
        onDragLeave={onDragLeave}
        className={`flex-1 min-h-[400px] rounded-xl p-2 space-y-2 transition-colors ${
          isDragOver ? "bg-primary/5 border-2 border-dashed border-primary" : "bg-muted/30 border-2 border-transparent"
        }`}
      >
        {leads.length === 0 && (
          <div className="flex items-center justify-center h-20 text-xs text-muted-foreground">
            Drop leads here
          </div>
        )}
        {leads.map(lead => (
          <LeadCard key={lead.id} lead={lead} onDragStart={onDragStart => onDragStart(null, lead)} />
        ))}
      </div>
    </div>
  );
}

export default function KanbanPipeline({ leads, onLeadUpdated }) {
  const [dragLead, setDragLead] = useState(null);
  const [dragOverStage, setDragOverStage] = useState(null);
  const [updating, setUpdating] = useState(null);

  // Group leads by stage
  const grouped = {};
  STAGES.forEach(s => { grouped[s.id] = []; });
  leads.forEach(l => {
    if (grouped[l.status] !== undefined) grouped[l.status].push(l);
  });

  const handleDragStart = (e, lead) => {
    setDragLead(lead);
    if (e) e.dataTransfer.effectAllowed = "move";
  };

  const handleDragOver = (e, stageId) => {
    e.preventDefault();
    e.dataTransfer.dropEffect = "move";
    setDragOverStage(stageId);
  };

  const handleDrop = async (e, stageId) => {
    e.preventDefault();
    setDragOverStage(null);
    if (!dragLead || dragLead.status === stageId) { setDragLead(null); return; }

    setUpdating(dragLead.id);
    const updated = { ...dragLead, status: stageId };
    onLeadUpdated(updated); // optimistic
    await base44.entities.Lead.update(dragLead.id, { status: stageId });
    setUpdating(null);
    setDragLead(null);
  };

  return (
    <div className="flex gap-3 overflow-x-auto pb-4 px-4 pt-2" style={{ minHeight: "calc(100vh - 200px)" }}>
      {STAGES.map(stage => {
        const stageLeads = grouped[stage.id] || [];
        return (
          <div key={stage.id} className="flex flex-col min-w-[220px] w-[220px] flex-shrink-0">
            {/* Column header */}
            <div className={`flex items-center gap-2 px-3 py-2 rounded-xl border mb-2 ${STAGE_COLORS[stage.color].header}`}>
              <span className="text-base">{stage.emoji}</span>
              <span className="text-sm font-bold text-foreground flex-1">{stage.label}</span>
              <span className={`text-xs font-bold px-1.5 py-0.5 rounded-full ${STAGE_COLORS[stage.color].count}`}>
                {stageLeads.length}
              </span>
            </div>

            {/* Drop zone */}
            <div
              onDragOver={e => handleDragOver(e, stage.id)}
              onDrop={e => handleDrop(e, stage.id)}
              onDragLeave={() => setDragOverStage(null)}
              className={`flex-1 min-h-[400px] rounded-xl p-2 space-y-2 transition-all ${
                dragOverStage === stage.id
                  ? "bg-primary/5 border-2 border-dashed border-primary scale-[1.01]"
                  : "bg-muted/30 border-2 border-transparent"
              }`}
            >
              {stageLeads.length === 0 && (
                <div className="flex items-center justify-center h-20 text-xs text-muted-foreground italic">
                  Drop leads here
                </div>
              )}
              {stageLeads.map(lead => (
                <div
                  key={lead.id}
                  draggable
                  onDragStart={e => handleDragStart(e, lead)}
                  className={`bg-card border border-border rounded-xl p-3 cursor-grab active:cursor-grabbing hover:shadow-md transition-all select-none ${
                    updating === lead.id ? "opacity-50 pointer-events-none" : ""
                  }`}
                >
                  <p className="text-sm font-semibold text-foreground truncate mb-1.5">
                    {lead.owner_name || <span className="text-muted-foreground italic font-normal text-xs">Unknown</span>}
                  </p>
                  {lead.phone && (
                    <div className="flex items-center gap-1 mb-1">
                      <Phone className="w-3 h-3 text-muted-foreground flex-shrink-0" />
                      <a href={`tel:${lead.phone}`} onClick={e => e.stopPropagation()}
                        className="text-xs text-primary font-medium truncate">{lead.phone}</a>
                    </div>
                  )}
                  {lead.address && (
                    <div className="flex items-center gap-1">
                      <MapPin className="w-3 h-3 text-muted-foreground flex-shrink-0" />
                      <p className="text-xs text-muted-foreground truncate">{lead.address}</p>
                    </div>
                  )}
                  {(lead.home_value || lead.tags?.includes("marketplace_purchase")) && (
                    <div className="flex items-center justify-between mt-2">
                      {lead.home_value ? (
                        <span className="text-xs text-muted-foreground">
                          ${lead.home_value.toLocaleString()}
                        </span>
                      ) : <span />}
                      {lead.tags?.includes("marketplace_purchase") && (
                        <span className="text-xs font-bold text-emerald-600 bg-emerald-50 px-1.5 py-0.5 rounded-md">Purchased</span>
                      )}
                    </div>
                  )}
                </div>
              ))}
            </div>
          </div>
        );
      })}
    </div>
  );
}