import { useState, useEffect } from "react";
import { Target, ChevronDown, ChevronUp, Pencil, Check } from "lucide-react";

const GOAL_KEYS = [
  { key: "knocked",         label: "Doors Knocked",  color: "bg-blue-500" },
  { key: "interested",      label: "Interested",     color: "bg-green-500" },
  { key: "appointment_set", label: "Appts Set",      color: "bg-purple-500" },
  { key: "sold",            label: "Closed",         color: "bg-emerald-500" },
];

const DEFAULT_GOALS = { knocked: 50, interested: 10, appointment_set: 3, sold: 1 };
const STORAGE_KEY = "crm_daily_goals";

export default function DailyGoals({ leads, todayLeads }) {
  const [goals, setGoals] = useState(() => {
    try { return JSON.parse(localStorage.getItem(STORAGE_KEY)) || DEFAULT_GOALS; }
    catch { return DEFAULT_GOALS; }
  });
  const [editing, setEditing] = useState(false);
  const [draft, setDraft] = useState(goals);
  const [expanded, setExpanded] = useState(true);

  const saveGoals = () => {
    setGoals(draft);
    localStorage.setItem(STORAGE_KEY, JSON.stringify(draft));
    setEditing(false);
  };

  const todayCounts = todayLeads.reduce((acc, l) => {
    acc[l.status] = (acc[l.status] || 0) + 1;
    return acc;
  }, {});

  return (
    <div className="bg-card border border-border rounded-2xl overflow-hidden">
      <div className="flex items-center gap-2 px-4 py-3 cursor-pointer" onClick={() => setExpanded(e => !e)}>
        <Target className="w-4 h-4 text-primary" />
        <p className="text-sm font-bold text-foreground flex-1">Daily Goals</p>
        {!editing && (
          <button onClick={e => { e.stopPropagation(); setDraft(goals); setEditing(true); setExpanded(true); }}
            className="p-1.5 rounded-lg hover:bg-muted">
            <Pencil className="w-3.5 h-3.5 text-muted-foreground" />
          </button>
        )}
        {editing && (
          <button onClick={e => { e.stopPropagation(); saveGoals(); }}
            className="p-1.5 rounded-lg bg-primary text-white">
            <Check className="w-3.5 h-3.5" />
          </button>
        )}
        {expanded ? <ChevronUp className="w-4 h-4 text-muted-foreground" /> : <ChevronDown className="w-4 h-4 text-muted-foreground" />}
      </div>

      {expanded && (
        <div className="px-4 pb-4 space-y-3 border-t border-border pt-3">
          {GOAL_KEYS.map(({ key, label, color }) => {
            const current = todayCounts[key] || 0;
            const goal = goals[key] || 1;
            const pct = Math.min(100, Math.round((current / goal) * 100));
            return (
              <div key={key}>
                <div className="flex items-center justify-between mb-1">
                  <span className="text-xs font-semibold text-foreground">{label}</span>
                  <div className="flex items-center gap-2">
                    <span className={`text-xs font-black ${pct >= 100 ? "text-emerald-600" : "text-foreground"}`}>
                      {current}
                    </span>
                    <span className="text-xs text-muted-foreground">/</span>
                    {editing ? (
                      <input type="number" min="1" value={draft[key] || ""} onChange={e => setDraft(d => ({ ...d, [key]: parseInt(e.target.value) || 1 }))}
                        className="w-12 h-6 text-xs text-center border border-border rounded-lg bg-background text-foreground focus:outline-none focus:ring-1 focus:ring-ring" />
                    ) : (
                      <span className="text-xs text-muted-foreground">{goal}</span>
                    )}
                    <span className={`text-xs font-bold ml-1 ${pct >= 100 ? "text-emerald-600" : "text-muted-foreground"}`}>
                      {pct >= 100 ? "✅" : `${pct}%`}
                    </span>
                  </div>
                </div>
                <div className="h-2 bg-muted rounded-full overflow-hidden">
                  <div className={`h-full ${color} rounded-full transition-all duration-500`} style={{ width: `${pct}%` }} />
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}