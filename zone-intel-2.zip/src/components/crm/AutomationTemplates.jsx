import { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Zap, Plus, Save, Trash2, ToggleLeft, ToggleRight, Mail, MessageSquare,
  ChevronDown, ChevronUp, Loader2, CheckCircle, Info
} from "lucide-react";

const STAGES = [
  { id: "follow_up",        label: "Follow Up",        color: "text-yellow-600 bg-yellow-50 border-yellow-200",  emoji: "🔁" },
  { id: "interested",       label: "Interested",        color: "text-green-600 bg-green-50 border-green-200",     emoji: "✅" },
  { id: "knocked",          label: "Knocked",           color: "text-blue-600 bg-blue-50 border-blue-200",        emoji: "🚪" },
  { id: "appointment_set",  label: "Appointment Set",   color: "text-purple-600 bg-purple-50 border-purple-200",  emoji: "📅" },
  { id: "sold",             label: "Sold",              color: "text-emerald-700 bg-emerald-50 border-emerald-200", emoji: "🏆" },
];

const VARIABLES = ["{{name}}", "{{address}}", "{{city}}", "{{state}}", "{{phone}}", "{{rep_email}}", "{{notes}}"];

const DEFAULTS = {
  follow_up: {
    email_subject: "Quick follow-up — {{name}}",
    email_body: "Hi {{name}},\n\nI wanted to follow up on our recent conversation. I'd love to help you find the best coverage for your needs.\n\nPlease feel free to reply or call me anytime.\n\nBest,\n{{rep_email}}",
    sms_body: "Hi {{name}}, just following up from our chat! Let me know if you have questions. - {{rep_email}}",
  },
  appointment_set: {
    email_subject: "Your appointment is confirmed, {{name}}!",
    email_body: "Hi {{name}},\n\nYour appointment is confirmed! Looking forward to meeting with you.\n\nAddress: {{address}}\n\nSee you soon!\n{{rep_email}}",
    sms_body: "Hi {{name}}! Your appt is confirmed. See you soon at {{address}}. Questions? Reply anytime.",
  },
  sold: {
    email_subject: "Welcome aboard, {{name}}! 🎉",
    email_body: "Hi {{name}},\n\nWelcome! We're thrilled to have you as a client. Your coverage is now active.\n\nIf you ever have questions, don't hesitate to reach out.\n\nThank you for your trust,\n{{rep_email}}",
    sms_body: "Welcome, {{name}}! 🎉 Your coverage is confirmed. Thank you for choosing us!",
  },
};

function TemplateCard({ stage, template, onSave, onDelete, onToggle }) {
  const [expanded, setExpanded] = useState(false);
  const [form, setForm] = useState(template || {
    stage: stage.id,
    is_active: true,
    send_email: true,
    send_sms: false,
    email_subject: DEFAULTS[stage.id]?.email_subject || "",
    email_body: DEFAULTS[stage.id]?.email_body || "",
    sms_body: DEFAULTS[stage.id]?.sms_body || "",
    delay_minutes: 0,
  });
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);

  useEffect(() => {
    if (template) setForm(template);
  }, [template]);

  const set = (key, val) => setForm(f => ({ ...f, [key]: val }));

  const handleSave = async () => {
    setSaving(true);
    await onSave({ ...form, stage: stage.id });
    setSaving(false);
    setSaved(true);
    setTimeout(() => setSaved(false), 2000);
  };

  const insertVar = (field, v) => set(field, (form[field] || "") + v);

  return (
    <div className={`rounded-2xl border bg-card overflow-hidden ${form.is_active ? "border-border" : "border-border opacity-60"}`}>
      {/* Header */}
      <div className="flex items-center gap-3 px-4 py-3 cursor-pointer" onClick={() => setExpanded(e => !e)}>
        <span className="text-xl">{stage.emoji}</span>
        <div className="flex-1 min-w-0">
          <p className="text-sm font-bold text-foreground">{stage.label}</p>
          <p className="text-xs text-muted-foreground truncate">
            {form.send_email ? "📧 Email" : ""}
            {form.send_email && form.send_sms ? " + " : ""}
            {form.send_sms ? "💬 SMS" : ""}
            {!form.send_email && !form.send_sms ? "No sends configured" : ""}
            {form.delay_minutes > 0 ? ` · ${form.delay_minutes}min delay` : " · Instant"}
          </p>
        </div>
        <div className="flex items-center gap-2 flex-shrink-0">
          <button onClick={e => { e.stopPropagation(); onToggle(!form.is_active); set("is_active", !form.is_active); }}
            className="p-1">
            {form.is_active
              ? <ToggleRight className="w-5 h-5 text-emerald-500" />
              : <ToggleLeft className="w-5 h-5 text-muted-foreground" />}
          </button>
          {expanded ? <ChevronUp className="w-4 h-4 text-muted-foreground" /> : <ChevronDown className="w-4 h-4 text-muted-foreground" />}
        </div>
      </div>

      {expanded && (
        <div className="px-4 pb-4 border-t border-border space-y-4 pt-4">
          {/* Toggles */}
          <div className="flex gap-2">
            <button onClick={() => set("send_email", !form.send_email)}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg border text-xs font-semibold transition-colors ${form.send_email ? "bg-primary/10 border-primary text-primary" : "bg-muted border-border text-muted-foreground"}`}>
              <Mail className="w-3.5 h-3.5" /> Email
            </button>
            <button onClick={() => set("send_sms", !form.send_sms)}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg border text-xs font-semibold transition-colors ${form.send_sms ? "bg-purple-100 border-purple-300 text-purple-700" : "bg-muted border-border text-muted-foreground"}`}>
              <MessageSquare className="w-3.5 h-3.5" /> SMS
            </button>
            <div className="flex items-center gap-1.5 ml-auto">
              <span className="text-xs text-muted-foreground">Delay (min)</span>
              <input type="number" min="0" value={form.delay_minutes || 0}
                onChange={e => set("delay_minutes", parseInt(e.target.value) || 0)}
                className="w-16 h-7 text-xs text-center border border-border rounded-lg bg-background text-foreground focus:outline-none focus:ring-1 focus:ring-ring" />
            </div>
          </div>

          {/* Variable chips */}
          <div>
            <p className="text-xs font-bold text-muted-foreground mb-1.5">Insert variable:</p>
            <div className="flex flex-wrap gap-1">
              {VARIABLES.map(v => (
                <button key={v} onClick={() => insertVar("email_body", v)}
                  className="text-xs bg-primary/10 text-primary px-2 py-0.5 rounded font-mono hover:bg-primary/20 transition-colors">
                  {v}
                </button>
              ))}
            </div>
          </div>

          {/* Email fields */}
          {form.send_email && (
            <div className="space-y-2">
              <div>
                <label className="text-xs font-bold text-muted-foreground block mb-1">Email Subject</label>
                <Input value={form.email_subject || ""} onChange={e => set("email_subject", e.target.value)}
                  placeholder="Subject line..." className="text-sm h-9" />
              </div>
              <div>
                <label className="text-xs font-bold text-muted-foreground block mb-1">Email Body</label>
                <textarea value={form.email_body || ""} onChange={e => set("email_body", e.target.value)}
                  rows={6} placeholder="Write your email body here. Use {{name}}, {{address}}, etc."
                  className="w-full text-sm border border-border rounded-xl px-3 py-2 bg-background text-foreground resize-none focus:outline-none focus:ring-1 focus:ring-ring placeholder:text-muted-foreground font-mono" />
              </div>
            </div>
          )}

          {/* SMS field */}
          {form.send_sms && (
            <div>
              <label className="text-xs font-bold text-muted-foreground block mb-1">SMS Body</label>
              <textarea value={form.sms_body || ""} onChange={e => set("sms_body", e.target.value)}
                rows={3} placeholder="Short SMS message... (160 chars recommended)"
                className="w-full text-sm border border-border rounded-xl px-3 py-2 bg-background text-foreground resize-none focus:outline-none focus:ring-1 focus:ring-ring placeholder:text-muted-foreground" />
              <div className="mt-1.5 flex items-center gap-1.5 p-2 bg-amber-50 border border-amber-200 rounded-lg">
                <Info className="w-3.5 h-3.5 text-amber-600 flex-shrink-0" />
                <p className="text-xs text-amber-700">SMS sending requires Twilio integration. Templates are saved and ready — contact support to enable SMS.</p>
              </div>
            </div>
          )}

          {/* Actions */}
          <div className="flex gap-2 pt-1">
            <Button onClick={handleSave} disabled={saving} size="sm" className="flex-1 gap-1.5 h-9 text-xs font-bold">
              {saving ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : saved ? <CheckCircle className="w-3.5 h-3.5" /> : <Save className="w-3.5 h-3.5" />}
              {saved ? "Saved!" : "Save Template"}
            </Button>
            {template?.id && (
              <Button onClick={onDelete} variant="outline" size="sm" className="h-9 w-9 p-0 text-destructive border-destructive/30 hover:bg-destructive/10">
                <Trash2 className="w-3.5 h-3.5" />
              </Button>
            )}
          </div>
        </div>
      )}
    </div>
  );
}

export default function AutomationTemplates() {
  const [templates, setTemplates] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    base44.entities.AutomationTemplate.list()
      .then(setTemplates)
      .finally(() => setLoading(false));
  }, []);

  const getTemplate = (stageId) => templates.find(t => t.stage === stageId);

  const handleSave = async (data) => {
    const existing = getTemplate(data.stage);
    let updated;
    if (existing) {
      updated = await base44.entities.AutomationTemplate.update(existing.id, data);
      setTemplates(prev => prev.map(t => t.id === existing.id ? updated : t));
    } else {
      updated = await base44.entities.AutomationTemplate.create(data);
      setTemplates(prev => [...prev, updated]);
    }
  };

  const handleDelete = async (stageId) => {
    const existing = getTemplate(stageId);
    if (!existing) return;
    await base44.entities.AutomationTemplate.delete(existing.id);
    setTemplates(prev => prev.filter(t => t.id !== existing.id));
  };

  const handleToggle = async (stageId, isActive) => {
    const existing = getTemplate(stageId);
    if (!existing) return;
    const updated = await base44.entities.AutomationTemplate.update(existing.id, { is_active: isActive });
    setTemplates(prev => prev.map(t => t.id === existing.id ? updated : t));
  };

  if (loading) return (
    <div className="flex items-center justify-center py-20">
      <Loader2 className="w-6 h-6 animate-spin text-primary" />
    </div>
  );

  return (
    <div className="px-4 py-4 space-y-4 pb-20">
      {/* Info banner */}
      <div className="flex items-start gap-3 p-4 bg-primary/5 border border-primary/20 rounded-2xl">
        <Zap className="w-5 h-5 text-primary mt-0.5 flex-shrink-0" />
        <div>
          <p className="text-sm font-bold text-foreground">Pipeline Automations</p>
          <p className="text-xs text-muted-foreground mt-0.5 leading-relaxed">
            Automatically send personalized emails (and SMS when enabled) when a lead moves to a new Kanban stage.
            Use <span className="font-mono text-primary text-xs">{"{{name}}"}</span>, <span className="font-mono text-primary text-xs">{"{{address}}"}</span>, etc. to personalize messages.
          </p>
        </div>
      </div>

      {/* One card per stage */}
      {STAGES.map(stage => (
        <TemplateCard
          key={stage.id}
          stage={stage}
          template={getTemplate(stage.id)}
          onSave={handleSave}
          onDelete={() => handleDelete(stage.id)}
          onToggle={(val) => handleToggle(stage.id, val)}
        />
      ))}
    </div>
  );
}