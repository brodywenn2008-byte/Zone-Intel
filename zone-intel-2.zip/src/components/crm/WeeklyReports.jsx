import { useState, useMemo } from "react";
import { FileText, Download, TrendingUp, ChevronLeft, ChevronRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import { jsPDF } from "jspdf";

const STATUS_LABELS = {
  knocked: "Knocked", interested: "Interested", follow_up: "Follow Up",
  appointment_set: "Appt Set", sold: "Sold", no_answer: "No Answer",
  not_interested: "Not Interested", not_visited: "Not Visited",
};

function getWeekRange(offset = 0) {
  const now = new Date();
  const day = now.getDay();
  const monday = new Date(now);
  monday.setDate(now.getDate() - ((day + 6) % 7) + offset * 7);
  monday.setHours(0, 0, 0, 0);
  const sunday = new Date(monday);
  sunday.setDate(monday.getDate() + 6);
  sunday.setHours(23, 59, 59, 999);
  return { start: monday, end: sunday };
}

function fmt(d) {
  return d.toLocaleDateString("en-US", { month: "short", day: "numeric" });
}

function calcRepStats(leads, start, end) {
  const repMap = {};
  leads.forEach(l => {
    const d = new Date(l.updated_date || l.created_date);
    if (d < start || d > end) return;
    const rep = l.assigned_rep || l.created_by_id || "Unassigned";
    if (!repMap[rep]) {
      repMap[rep] = { rep, knocked: 0, interested: 0, appointments: 0, sold: 0, follow_up: 0, total: 0 };
    }
    repMap[rep].total++;
    if (l.status === "knocked"          || l.status === "no_answer")   repMap[rep].knocked++;
    if (l.status === "interested")                                      repMap[rep].interested++;
    if (l.status === "appointment_set")                                 repMap[rep].appointments++;
    if (l.status === "sold")                                            repMap[rep].sold++;
    if (l.status === "follow_up")                                       repMap[rep].follow_up++;
  });
  return Object.values(repMap).sort((a, b) => b.sold - a.sold);
}

function convRate(rep) {
  return rep.knocked > 0 ? ((rep.sold / rep.knocked) * 100).toFixed(1) : "0.0";
}

function StatBar({ value, max, color }) {
  const pct = max > 0 ? Math.min((value / max) * 100, 100) : 0;
  return (
    <div className="w-full bg-muted rounded-full h-1.5">
      <div className={`${color} h-1.5 rounded-full transition-all`} style={{ width: `${pct}%` }} />
    </div>
  );
}

function generatePDF(repStats, weekLabel, allLeads, weekStart, weekEnd) {
  const doc = new jsPDF();
  const pageW = doc.internal.pageSize.getWidth();

  // Header
  doc.setFillColor(37, 99, 235);
  doc.rect(0, 0, pageW, 30, "F");
  doc.setTextColor(255, 255, 255);
  doc.setFontSize(18);
  doc.setFont("helvetica", "bold");
  doc.text("Weekly Sales Report", 14, 13);
  doc.setFontSize(10);
  doc.setFont("helvetica", "normal");
  doc.text(weekLabel, 14, 22);
  doc.text(`Generated ${new Date().toLocaleDateString()}`, pageW - 14, 22, { align: "right" });

  // Team summary
  const total = repStats.reduce((s, r) => s + r.total, 0);
  const totalSold = repStats.reduce((s, r) => s + r.sold, 0);
  const totalKnocked = repStats.reduce((s, r) => s + r.knocked, 0);
  const totalAppts = repStats.reduce((s, r) => s + r.appointments, 0);
  const teamConv = totalKnocked > 0 ? ((totalSold / totalKnocked) * 100).toFixed(1) : "0.0";

  doc.setTextColor(30, 41, 59);
  doc.setFontSize(13);
  doc.setFont("helvetica", "bold");
  doc.text("Team Summary", 14, 42);

  const summaryData = [
    ["Total Leads Touched", String(total)],
    ["Doors Knocked",        String(totalKnocked)],
    ["Appointments Set",     String(totalAppts)],
    ["Sales Closed",         String(totalSold)],
    ["Team Conversion Rate", `${teamConv}%`],
  ];

  let y = 50;
  doc.setFontSize(10);
  summaryData.forEach(([label, val]) => {
    doc.setFont("helvetica", "normal");
    doc.setTextColor(100, 116, 139);
    doc.text(label, 14, y);
    doc.setFont("helvetica", "bold");
    doc.setTextColor(30, 41, 59);
    doc.text(val, 90, y);
    y += 8;
  });

  // Rep breakdown table
  y += 6;
  doc.setFontSize(13);
  doc.setFont("helvetica", "bold");
  doc.setTextColor(30, 41, 59);
  doc.text("Rep Productivity Breakdown", 14, y);
  y += 8;

  // Table header
  doc.setFillColor(241, 245, 249);
  doc.rect(14, y - 5, pageW - 28, 8, "F");
  doc.setFontSize(9);
  doc.setFont("helvetica", "bold");
  doc.setTextColor(100, 116, 139);
  const cols = [14, 75, 100, 120, 140, 160, 180];
  ["Rep", "Knocked", "Interested", "Appts", "Sold", "Conv%", "Leads"].forEach((h, i) => {
    doc.text(h, cols[i], y);
  });
  y += 8;

  doc.setFont("helvetica", "normal");
  doc.setTextColor(30, 41, 59);
  repStats.forEach((r, idx) => {
    if (idx % 2 === 0) {
      doc.setFillColor(248, 250, 252);
      doc.rect(14, y - 5, pageW - 28, 8, "F");
    }
    doc.setFontSize(9);
    const repLabel = r.rep.length > 22 ? r.rep.slice(0, 20) + "…" : r.rep;
    doc.text(repLabel,         cols[0], y);
    doc.text(String(r.knocked),  cols[1], y);
    doc.text(String(r.interested), cols[2], y);
    doc.text(String(r.appointments), cols[3], y);
    doc.setFont("helvetica", "bold");
    doc.setTextColor(r.sold > 0 ? 5 : 30, r.sold > 0 ? 150 : 41, r.sold > 0 ? 105 : 59);
    doc.text(String(r.sold), cols[4], y);
    doc.setFont("helvetica", "normal");
    doc.setTextColor(30, 41, 59);
    doc.text(`${convRate(r)}%`, cols[5], y);
    doc.text(String(r.total), cols[6], y);
    y += 8;
    if (y > 270) { doc.addPage(); y = 20; }
  });

  doc.save(`sales-report-${weekLabel.replace(/\s/g, "-")}.pdf`);
}

export default function WeeklyReports({ leads }) {
  const [weekOffset, setWeekOffset] = useState(0);

  const { start, end } = useMemo(() => getWeekRange(weekOffset), [weekOffset]);
  const repStats = useMemo(() => calcRepStats(leads, start, end), [leads, start, end]);

  const weekLabel = `${fmt(start)} – ${fmt(end)}`;
  const maxKnocked = Math.max(...repStats.map(r => r.knocked), 1);
  const maxSold    = Math.max(...repStats.map(r => r.sold), 1);

  const totalSold    = repStats.reduce((s, r) => s + r.sold, 0);
  const totalKnocked = repStats.reduce((s, r) => s + r.knocked, 0);
  const totalAppts   = repStats.reduce((s, r) => s + r.appointments, 0);
  const teamConv     = totalKnocked > 0 ? ((totalSold / totalKnocked) * 100).toFixed(1) : "0.0";

  return (
    <div className="space-y-4">
      {/* Week navigator */}
      <div className="flex items-center justify-between bg-card border border-border rounded-2xl px-4 py-3">
        <button onClick={() => setWeekOffset(o => o - 1)}
          className="w-8 h-8 rounded-lg hover:bg-muted flex items-center justify-center">
          <ChevronLeft className="w-4 h-4 text-muted-foreground" />
        </button>
        <div className="text-center">
          <p className="text-sm font-bold text-foreground">{weekLabel}</p>
          <p className="text-xs text-muted-foreground">{weekOffset === 0 ? "This week" : weekOffset === -1 ? "Last week" : `${Math.abs(weekOffset)} weeks ago`}</p>
        </div>
        <button onClick={() => setWeekOffset(o => Math.min(o + 1, 0))} disabled={weekOffset === 0}
          className="w-8 h-8 rounded-lg hover:bg-muted flex items-center justify-center disabled:opacity-30">
          <ChevronRight className="w-4 h-4 text-muted-foreground" />
        </button>
      </div>

      {/* Team KPIs */}
      <div className="grid grid-cols-2 gap-2">
        {[
          { label: "Doors Knocked",   val: totalKnocked, color: "text-blue-600",   bg: "bg-blue-50" },
          { label: "Sales Closed",    val: totalSold,    color: "text-emerald-600", bg: "bg-emerald-50" },
          { label: "Appointments",    val: totalAppts,   color: "text-purple-600",  bg: "bg-purple-50" },
          { label: "Conv. Rate",      val: `${teamConv}%`, color: "text-amber-600", bg: "bg-amber-50" },
        ].map(s => (
          <div key={s.label} className={`${s.bg} rounded-2xl p-4 border border-border`}>
            <p className={`text-2xl font-black leading-none ${s.color}`}>{s.val}</p>
            <p className="text-xs text-muted-foreground mt-1">{s.label}</p>
          </div>
        ))}
      </div>

      {/* Rep table */}
      <div className="bg-card border border-border rounded-2xl overflow-hidden">
        <div className="flex items-center justify-between px-4 py-3 border-b border-border">
          <div className="flex items-center gap-2">
            <TrendingUp className="w-4 h-4 text-primary" />
            <p className="text-sm font-bold text-foreground">Rep Breakdown</p>
            <span className="text-xs bg-muted text-muted-foreground px-2 py-0.5 rounded-full">{repStats.length} reps</span>
          </div>
          <Button size="sm" onClick={() => generatePDF(repStats, weekLabel, leads, start, end)}
            disabled={repStats.length === 0}
            className="gap-1.5 h-8 px-3 text-xs font-bold">
            <Download className="w-3.5 h-3.5" /> Export PDF
          </Button>
        </div>

        {repStats.length === 0 ? (
          <div className="py-12 text-center">
            <FileText className="w-8 h-8 text-muted-foreground mx-auto mb-2" />
            <p className="text-sm font-semibold text-foreground">No activity this week</p>
            <p className="text-xs text-muted-foreground mt-1">Try navigating to a previous week</p>
          </div>
        ) : (
          <div className="divide-y divide-border">
            {repStats.map((r, i) => (
              <div key={r.rep} className="px-4 py-3">
                <div className="flex items-center gap-2 mb-2">
                  <span className={`w-5 h-5 rounded-full flex items-center justify-center text-xs font-black flex-shrink-0 ${
                    i === 0 ? "bg-amber-100 text-amber-700" : "bg-muted text-muted-foreground"
                  }`}>{i + 1}</span>
                  <p className="text-sm font-semibold text-foreground truncate flex-1">{r.rep}</p>
                  <span className="text-xs font-bold text-emerald-600 bg-emerald-50 px-2 py-0.5 rounded-full flex-shrink-0">
                    {r.sold} closed
                  </span>
                </div>

                <div className="grid grid-cols-3 gap-3 mb-2 text-center">
                  {[
                    { label: "Knocked", val: r.knocked },
                    { label: "Appts",   val: r.appointments },
                    { label: "Conv%",   val: `${convRate(r)}%` },
                  ].map(s => (
                    <div key={s.label}>
                      <p className="text-sm font-black text-foreground leading-none">{s.val}</p>
                      <p className="text-xs text-muted-foreground">{s.label}</p>
                    </div>
                  ))}
                </div>

                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <span className="text-xs text-muted-foreground w-14">Knocked</span>
                    <div className="flex-1"><StatBar value={r.knocked} max={maxKnocked} color="bg-blue-400" /></div>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="text-xs text-muted-foreground w-14">Sold</span>
                    <div className="flex-1"><StatBar value={r.sold} max={maxSold} color="bg-emerald-500" /></div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}