import { useState, useEffect, useCallback } from "react";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Clock, LogIn, LogOut, FileText, ChevronDown, ChevronUp, Users } from "lucide-react";

function formatDuration(minutes) {
  if (!minutes) return "0m";
  const h = Math.floor(minutes / 60);
  const m = Math.round(minutes % 60);
  return h > 0 ? `${h}h ${m}m` : `${m}m`;
}

function LiveTimer({ clockIn }) {
  const [, setTick] = useState(0);
  useEffect(() => {
    const id = setInterval(() => setTick(t => t + 1), 60000);
    return () => clearInterval(id);
  }, []);
  const diff = (Date.now() - new Date(clockIn)) / 60000;
  return <>{formatDuration(diff)}</>;
}

function ShiftCard({ shift, isOwn, onClockOut }) {
  const [expanded, setExpanded] = useState(false);
  const active = shift.status === "active";

  return (
    <div className={`bg-card border rounded-2xl overflow-hidden ${active ? "border-primary/40 shadow-sm" : "border-border"}`}>
      <div className="p-4">
        <div className="flex items-start justify-between gap-2">
          <div className="flex items-center gap-2.5 min-w-0">
            <div className={`w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 text-sm font-bold ${active ? "bg-green-100 text-green-700" : "bg-muted text-muted-foreground"}`}>
              {(shift.rep_name || shift.rep_email || "?")[0].toUpperCase()}
            </div>
            <div className="min-w-0">
              <p className="text-sm font-bold text-foreground truncate">{shift.rep_name || shift.rep_email}</p>
              <p className="text-xs text-muted-foreground">
                {new Date(shift.clock_in).toLocaleDateString()} &middot; In {new Date(shift.clock_in).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}
                {shift.clock_out && ` \u2192 Out ${new Date(shift.clock_out).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}`}
              </p>
            </div>
          </div>
          <div className="flex items-center gap-2 flex-shrink-0">
            {active && (
              <span className="text-xs font-bold px-2 py-0.5 rounded-full bg-green-100 text-green-700 flex items-center gap-1">
                <span className="w-1.5 h-1.5 bg-green-500 rounded-full animate-pulse inline-block" />
                Active
              </span>
            )}
            <span className="text-sm font-black text-foreground">
              {active ? <LiveTimer clockIn={shift.clock_in} /> : formatDuration(shift.duration_minutes)}
            </span>
          </div>
        </div>

        {(shift.doors_knocked > 0 || shift.leads_added > 0 || shift.sales_closed > 0) && (
          <div className="flex gap-4 mt-3 pt-3 border-t border-border">
            {[
              { label: "Doors", val: shift.doors_knocked },
              { label: "Leads", val: shift.leads_added },
              { label: "Closed", val: shift.sales_closed },
            ].filter(s => s.val > 0).map(s => (
              <div key={s.label} className="text-center">
                <p className="text-base font-black text-foreground leading-none">{s.val}</p>
                <p className="text-xs text-muted-foreground">{s.label}</p>
              </div>
            ))}
          </div>
        )}

        <div className="flex items-center gap-2 mt-3">
          {(shift.territory_notes || shift.results_notes) && (
            <button onClick={() => setExpanded(v => !v)}
              className="flex items-center gap-1 text-xs text-muted-foreground font-semibold hover:text-foreground transition-colors">
              <FileText className="w-3.5 h-3.5" /> Notes
              {expanded ? <ChevronUp className="w-3 h-3" /> : <ChevronDown className="w-3 h-3" />}
            </button>
          )}
          {isOwn && active && (
            <Button size="sm" variant="outline" onClick={() => onClockOut(shift)}
              className="ml-auto h-7 px-3 text-xs font-bold gap-1.5 border-destructive/40 text-destructive hover:bg-destructive/10">
              <LogOut className="w-3.5 h-3.5" /> Clock Out
            </Button>
          )}
        </div>
      </div>

      {expanded && (
        <div className="px-4 pb-4 space-y-2 border-t border-border pt-3 bg-muted/20">
          {shift.territory_notes && (
            <div>
              <p className="text-xs font-bold text-muted-foreground uppercase tracking-wide mb-1">Territory Coverage</p>
              <p className="text-xs text-foreground leading-relaxed">{shift.territory_notes}</p>
            </div>
          )}
          {shift.results_notes && (
            <div>
              <p className="text-xs font-bold text-muted-foreground uppercase tracking-wide mb-1">Results</p>
              <p className="text-xs text-foreground leading-relaxed">{shift.results_notes}</p>
            </div>
          )}
        </div>
      )}
    </div>
  );
}

function ClockOutModal({ shift, onSave, onClose }) {
  const [form, setForm] = useState({
    territory_notes: shift.territory_notes || "",
    results_notes:   shift.results_notes   || "",
    doors_knocked:   shift.doors_knocked   || "",
    leads_added:     shift.leads_added     || "",
    sales_closed:    shift.sales_closed    || "",
  });
  const [saving, setSaving] = useState(false);

  const handleSave = async () => {
    setSaving(true);
    const clockOut = new Date().toISOString();
    const durationMinutes = (Date.now() - new Date(shift.clock_in)) / 60000;
    await base44.entities.ShiftLog.update(shift.id, {
      clock_out: clockOut,
      duration_minutes: Math.round(durationMinutes),
      status: "completed",
      territory_notes: form.territory_notes,
      results_notes:   form.results_notes,
      doors_knocked:   Number(form.doors_knocked) || 0,
      leads_added:     Number(form.leads_added)   || 0,
      sales_closed:    Number(form.sales_closed)  || 0,
    });
    onSave();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center">
      <div className="absolute inset-0 bg-black/60" onClick={onClose} />
      <div className="relative w-full max-w-md bg-card rounded-t-2xl sm:rounded-2xl shadow-2xl overflow-hidden">
        <div className="flex items-center gap-2 px-5 py-4 border-b border-border">
          <LogOut className="w-4 h-4 text-destructive" />
          <h2 className="font-bold text-foreground text-sm flex-1">Clock Out</h2>
          <p className="text-xs text-muted-foreground">
            Started {new Date(shift.clock_in).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}
          </p>
        </div>
        <div className="px-5 py-4 space-y-4 max-h-[70vh] overflow-y-auto">
          <div className="grid grid-cols-3 gap-2">
            {[
              { key: "doors_knocked", label: "Doors Knocked" },
              { key: "leads_added",   label: "Leads Added" },
              { key: "sales_closed",  label: "Sales Closed" },
            ].map(f => (
              <div key={f.key}>
                <label className="text-xs text-muted-foreground mb-1 block">{f.label}</label>
                <input type="number" min="0" value={form[f.key]}
                  onChange={e => setForm(p => ({ ...p, [f.key]: e.target.value }))}
                  className="w-full h-9 text-sm border border-border rounded-lg px-3 bg-background text-foreground focus:outline-none focus:ring-1 focus:ring-ring text-center font-bold" />
              </div>
            ))}
          </div>
          <div>
            <label className="text-xs font-bold text-muted-foreground uppercase tracking-wide mb-1.5 block">Territory Coverage</label>
            <textarea rows={3} value={form.territory_notes}
              onChange={e => setForm(p => ({ ...p, territory_notes: e.target.value }))}
              placeholder="Which streets/blocks did you cover today?"
              className="w-full text-sm border border-border rounded-lg px-3 py-2 bg-background text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-1 focus:ring-ring resize-none" />
          </div>
          <div>
            <label className="text-xs font-bold text-muted-foreground uppercase tracking-wide mb-1.5 block">Results &amp; Outcomes</label>
            <textarea rows={3} value={form.results_notes}
              onChange={e => setForm(p => ({ ...p, results_notes: e.target.value }))}
              placeholder="Notable conversations, follow-ups scheduled, deals closed..."
              className="w-full text-sm border border-border rounded-lg px-3 py-2 bg-background text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-1 focus:ring-ring resize-none" />
          </div>
        </div>
        <div className="px-5 py-4 border-t border-border flex gap-2">
          <Button variant="outline" onClick={onClose} className="flex-1 h-9 text-sm">Cancel</Button>
          <Button onClick={handleSave} disabled={saving}
            className="flex-1 h-9 text-sm font-bold gap-1.5 bg-destructive hover:bg-destructive/90">
            <LogOut className="w-4 h-4" /> {saving ? "Saving..." : "Clock Out"}
          </Button>
        </div>
      </div>
    </div>
  );
}

export default function ShiftLogPanel({ user }) {
  const [shifts, setShifts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [clockingIn, setClockingIn] = useState(false);
  const [clockOutTarget, setClockOutTarget] = useState(null);
  const [viewAll, setViewAll] = useState(false);

  const load = useCallback(async () => {
    const all = await base44.entities.ShiftLog.list("-clock_in", 100);
    setShifts(all);
    setLoading(false);
  }, []);

  useEffect(() => { load(); }, [load]);

  const myActive = shifts.find(s => s.rep_email === user?.email && s.status === "active");

  const handleClockIn = async () => {
    if (!user) return;
    setClockingIn(true);
    await base44.entities.ShiftLog.create({
      rep_email: user.email,
      rep_name:  user.full_name || user.email,
      clock_in:  new Date().toISOString(),
      status:    "active",
    });
    await load();
    setClockingIn(false);
  };

  const todayStart = new Date();
  todayStart.setHours(0, 0, 0, 0);
  const todayShifts = shifts.filter(s => new Date(s.clock_in) >= todayStart);
  const displayed = viewAll ? shifts : todayShifts;

  const totalHoursToday = todayShifts
    .filter(s => s.status === "completed")
    .reduce((sum, s) => sum + (s.duration_minutes || 0), 0);

  return (
    <div className="space-y-4">
      {/* Clock In Banner */}
      <div className={`rounded-2xl p-5 ${myActive ? "bg-green-50 border border-green-200" : "bg-gradient-to-br from-primary to-primary/80"}`}>
        {myActive ? (
          <div className="flex items-center justify-between">
            <div>
              <div className="flex items-center gap-2 mb-1">
                <span className="w-2 h-2 bg-green-500 rounded-full animate-pulse" />
                <span className="text-xs font-bold text-green-700 uppercase tracking-wide">Shift Active</span>
              </div>
              <p className="text-2xl font-black text-green-800 leading-none">
                <LiveTimer clockIn={myActive.clock_in} />
              </p>
              <p className="text-xs text-green-600 mt-0.5">
                Since {new Date(myActive.clock_in).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}
              </p>
            </div>
            <Button onClick={() => setClockOutTarget(myActive)}
              className="gap-2 bg-green-700 hover:bg-green-800 text-white font-bold h-10 px-4">
              <LogOut className="w-4 h-4" /> Clock Out
            </Button>
          </div>
        ) : (
          <div className="flex items-center justify-between">
            <div>
              <p className="text-xs font-bold text-white/80 uppercase tracking-wide mb-1 flex items-center gap-1.5">
                <Clock className="w-3.5 h-3.5" /> Ready to Start?
              </p>
              <p className="text-sm text-white/90">Log your shift and track daily results</p>
            </div>
            <Button onClick={handleClockIn} disabled={clockingIn}
              className="gap-2 bg-white text-primary hover:bg-white/90 font-bold h-10 px-4">
              <LogIn className="w-4 h-4" /> {clockingIn ? "..." : "Clock In"}
            </Button>
          </div>
        )}
      </div>

      {/* Today summary */}
      {todayShifts.length > 0 && (
        <div className="grid grid-cols-3 gap-2">
          {[
            { label: "Shifts Today", val: todayShifts.length },
            { label: "Total Hours",  val: formatDuration(totalHoursToday) },
            { label: "Active Now",   val: todayShifts.filter(s => s.status === "active").length },
          ].map(s => (
            <div key={s.label} className="bg-card border border-border rounded-xl p-3 text-center">
              <p className="text-lg font-black text-foreground leading-none">{s.val}</p>
              <p className="text-xs text-muted-foreground mt-0.5">{s.label}</p>
            </div>
          ))}
        </div>
      )}

      {/* List header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Users className="w-4 h-4 text-muted-foreground" />
          <p className="text-sm font-bold text-foreground">{viewAll ? "All Shifts" : "Today's Shifts"}</p>
          <span className="text-xs text-muted-foreground bg-muted px-2 py-0.5 rounded-full">{displayed.length}</span>
        </div>
        <button onClick={() => setViewAll(v => !v)} className="text-xs font-bold text-primary">
          {viewAll ? "Today only" : "View all"}
        </button>
      </div>

      {loading ? (
        <div className="flex items-center justify-center h-24">
          <div className="w-5 h-5 border-4 border-primary/30 border-t-primary rounded-full animate-spin" />
        </div>
      ) : displayed.length === 0 ? (
        <div className="bg-card border border-dashed border-border rounded-2xl p-8 text-center">
          <Clock className="w-8 h-8 text-muted-foreground mx-auto mb-2" />
          <p className="text-sm font-semibold text-foreground">No shifts logged today</p>
          <p className="text-xs text-muted-foreground mt-1">Clock in to start tracking your shift</p>
        </div>
      ) : (
        <div className="space-y-3">
          {displayed.map(s => (
            <ShiftCard key={s.id} shift={s} isOwn={s.rep_email === user?.email}
              onClockOut={setClockOutTarget} />
          ))}
        </div>
      )}

      {clockOutTarget && (
        <ClockOutModal shift={clockOutTarget} onClose={() => setClockOutTarget(null)}
          onSave={async () => { setClockOutTarget(null); await load(); }} />
      )}
    </div>
  );
}