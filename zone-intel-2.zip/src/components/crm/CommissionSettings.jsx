import { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { DollarSign, Percent, Save, Loader2, Check } from "lucide-react";

const CATEGORIES = [
  { id: "default",               emoji: "📋", label: "Default (all categories)" },
  { id: "life_insurance",        emoji: "❤️",  label: "Life Insurance" },
  { id: "health_insurance",      emoji: "🏥",  label: "Health Insurance" },
  { id: "auto_insurance",        emoji: "🚗",  label: "Auto Insurance" },
  { id: "homeowners_insurance",  emoji: "🏠",  label: "Homeowners Insurance" },
  { id: "business_insurance",    emoji: "🏢",  label: "Business Insurance" },
  { id: "medicare",              emoji: "💊",  label: "Medicare Plans" },
  { id: "real_estate",           emoji: "🏡",  label: "Real Estate" },
  { id: "mortgage_refinance",    emoji: "🏦",  label: "Mortgage Refinance" },
  { id: "personal_loans",        emoji: "💳",  label: "Personal Loans" },
  { id: "business_loans",        emoji: "💼",  label: "Business Loans / MCA" },
  { id: "legal",                 emoji: "⚖️",  label: "Legal Leads" },
  { id: "solar_home_services",   emoji: "☀️",  label: "Solar / Home Services" },
  { id: "b2b_saas",              emoji: "💻",  label: "B2B Services" },
  { id: "telecom_utilities",     emoji: "📡",  label: "Telecom / Utilities" },
  { id: "education_career",      emoji: "🎓",  label: "Education / Career" },
];

export default function CommissionSettings() {
  const [settings, setSettings] = useState({});   // { category: {id, commission_type, amount} }
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(null);
  const [saved, setSaved] = useState(null);

  useEffect(() => {
    base44.entities.CommissionSetting.list().then(rows => {
      const map = {};
      rows.forEach(r => { map[r.category] = r; });
      setSettings(map);
      setLoading(false);
    });
  }, []);

  const getSetting = (cat) => settings[cat] || { commission_type: "flat", amount: 100 };

  const handleSave = async (cat) => {
    const cur = getSetting(cat);
    setSaving(cat);
    if (cur.id) {
      const updated = await base44.entities.CommissionSetting.update(cur.id, {
        commission_type: cur.commission_type,
        amount: cur.amount,
      });
      setSettings(prev => ({ ...prev, [cat]: updated }));
    } else {
      const created = await base44.entities.CommissionSetting.create({
        category: cat,
        commission_type: cur.commission_type,
        amount: cur.amount,
      });
      setSettings(prev => ({ ...prev, [cat]: created }));
    }
    setSaving(null);
    setSaved(cat);
    setTimeout(() => setSaved(null), 1500);
  };

  const update = (cat, field, val) => {
    setSettings(prev => ({
      ...prev,
      [cat]: { ...getSetting(cat), ...(prev[cat] || {}), [field]: val },
    }));
  };

  if (loading) return (
    <div className="flex items-center justify-center py-12">
      <Loader2 className="w-5 h-5 text-primary animate-spin" />
    </div>
  );

  return (
    <div className="space-y-2">
      <div className="bg-blue-50 border border-blue-200 rounded-xl px-4 py-3 mb-4">
        <p className="text-xs font-bold text-blue-800 mb-0.5">How commissions work</p>
        <p className="text-xs text-blue-700">
          Set a <strong>flat $</strong> amount per closed lead, or a <strong>%</strong> of the lead's marketplace price.
          Use the "Default" row as a fallback for uncategorized leads.
        </p>
      </div>

      {CATEGORIES.map(({ id, emoji, label }) => {
        const s = getSetting(id);
        const isSaving = saving === id;
        const isSaved = saved === id;

        return (
          <div key={id} className="bg-card border border-border rounded-xl px-4 py-3 flex items-center gap-3">
            <span className="text-lg flex-shrink-0">{emoji}</span>
            <p className="text-sm font-semibold text-foreground flex-1 truncate">{label}</p>

            {/* Type toggle */}
            <div className="flex border border-border rounded-lg overflow-hidden flex-shrink-0">
              <button
                onClick={() => update(id, "commission_type", "flat")}
                className={`h-8 px-2.5 text-xs font-bold flex items-center gap-1 transition-colors ${
                  s.commission_type === "flat" ? "bg-primary text-white" : "bg-card text-muted-foreground hover:bg-muted"
                }`}>
                <DollarSign className="w-3 h-3" /> Flat
              </button>
              <button
                onClick={() => update(id, "commission_type", "percent")}
                className={`h-8 px-2.5 text-xs font-bold flex items-center gap-1 border-l border-border transition-colors ${
                  s.commission_type === "percent" ? "bg-primary text-white" : "bg-card text-muted-foreground hover:bg-muted"
                }`}>
                <Percent className="w-3 h-3" /> %
              </button>
            </div>

            {/* Amount input */}
            <div className="relative flex-shrink-0 w-20">
              <span className="absolute left-2.5 top-1/2 -translate-y-1/2 text-xs text-muted-foreground font-bold">
                {s.commission_type === "flat" ? "$" : ""}
              </span>
              <input
                type="number"
                min="0"
                value={s.amount ?? 100}
                onChange={e => update(id, "amount", parseFloat(e.target.value) || 0)}
                className={`w-full h-8 text-xs font-bold border border-border rounded-lg bg-background text-foreground text-center focus:outline-none focus:ring-1 focus:ring-ring ${
                  s.commission_type === "flat" ? "pl-5" : ""
                }`}
              />
              {s.commission_type === "percent" && (
                <span className="absolute right-2 top-1/2 -translate-y-1/2 text-xs text-muted-foreground">%</span>
              )}
            </div>

            {/* Save button */}
            <button
              onClick={() => handleSave(id)}
              disabled={isSaving}
              className={`h-8 w-8 rounded-lg flex items-center justify-center flex-shrink-0 transition-colors ${
                isSaved ? "bg-emerald-500 text-white" : "bg-primary text-white hover:bg-primary/90"
              }`}>
              {isSaving ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> :
               isSaved  ? <Check className="w-3.5 h-3.5" /> :
                          <Save className="w-3.5 h-3.5" />}
            </button>
          </div>
        );
      })}
    </div>
  );
}