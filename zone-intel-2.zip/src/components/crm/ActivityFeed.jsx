import { useMemo } from "react";
import { Clock, MapPin, User } from "lucide-react";
import { formatDistanceToNow } from "date-fns";

const STATUS_CONFIG = {
  sold:             { label: "Closed 🏆",        bg: "bg-emerald-50 border-emerald-200", dot: "bg-emerald-500",  text: "text-emerald-700" },
  appointment_set:  { label: "Appt Set 📅",      bg: "bg-purple-50 border-purple-200",   dot: "bg-purple-500",   text: "text-purple-700" },
  interested:       { label: "Interested ✅",    bg: "bg-green-50 border-green-200",     dot: "bg-green-500",    text: "text-green-700" },
  follow_up:        { label: "Follow Up 🔁",     bg: "bg-amber-50 border-amber-200",     dot: "bg-amber-500",    text: "text-amber-700" },
  knocked:          { label: "Knocked 🚪",        bg: "bg-blue-50 border-blue-200",       dot: "bg-blue-400",     text: "text-blue-700" },
  not_interested:   { label: "Not Interested",   bg: "bg-red-50 border-red-100",         dot: "bg-red-400",      text: "text-red-600" },
  no_answer:        { label: "No Answer",        bg: "bg-gray-50 border-gray-200",       dot: "bg-gray-400",     text: "text-gray-500" },
};

export default function ActivityFeed({ leads, loading }) {
  const recentActivity = useMemo(() => {
    return [...leads]
      .filter(l => l.updated_date && l.status && l.status !== "not_visited")
      .sort((a, b) => new Date(b.updated_date) - new Date(a.updated_date))
      .slice(0, 30);
  }, [leads]);

  if (loading) return (
    <div className="bg-card border border-border rounded-2xl p-6 flex items-center justify-center">
      <div className="w-5 h-5 border-2 border-primary/30 border-t-primary rounded-full animate-spin" />
    </div>
  );

  return (
    <div className="bg-card border border-border rounded-2xl overflow-hidden">
      <div className="flex items-center gap-2 px-4 py-3 border-b border-border">
        <Clock className="w-4 h-4 text-primary" />
        <p className="text-sm font-bold text-foreground">Team Activity Feed</p>
        <span className="ml-auto text-xs text-muted-foreground bg-muted px-2 py-0.5 rounded-full">
          {recentActivity.length} updates
        </span>
      </div>

      {recentActivity.length === 0 ? (
        <div className="px-4 py-10 text-center">
          <p className="text-2xl mb-2">📭</p>
          <p className="text-sm font-semibold text-foreground">No activity yet</p>
          <p className="text-xs text-muted-foreground mt-1">Status updates will appear here in real-time.</p>
        </div>
      ) : (
        <div className="divide-y divide-border">
          {recentActivity.map((lead) => {
            const cfg = STATUS_CONFIG[lead.status] || { label: lead.status, bg: "bg-muted border-border", dot: "bg-gray-400", text: "text-foreground" };
            return (
              <div key={lead.id} className="px-4 py-3 flex items-start gap-3">
                {/* Dot */}
                <div className="flex flex-col items-center pt-1 flex-shrink-0">
                  <div className={`w-2.5 h-2.5 rounded-full ${cfg.dot}`} />
                  <div className="w-px flex-1 bg-border mt-1" />
                </div>

                <div className="flex-1 min-w-0 pb-1">
                  <div className="flex items-center gap-2 flex-wrap mb-0.5">
                    <span className={`text-xs font-bold px-2 py-0.5 rounded-full border ${cfg.bg} ${cfg.text}`}>
                      {cfg.label}
                    </span>
                    <span className="text-xs text-muted-foreground">
                      {lead.updated_date ? formatDistanceToNow(new Date(lead.updated_date), { addSuffix: true }) : ""}
                    </span>
                  </div>
                  {lead.owner_name && (
                    <div className="flex items-center gap-1 text-xs text-foreground font-semibold truncate">
                      <User className="w-3 h-3 text-muted-foreground flex-shrink-0" />
                      {lead.owner_name}
                    </div>
                  )}
                  {lead.address && (
                    <div className="flex items-center gap-1 text-xs text-muted-foreground truncate mt-0.5">
                      <MapPin className="w-3 h-3 flex-shrink-0" />
                      {lead.address}
                    </div>
                  )}
                  {lead.assigned_rep && (
                    <p className="text-xs text-muted-foreground mt-0.5">by {lead.assigned_rep}</p>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}