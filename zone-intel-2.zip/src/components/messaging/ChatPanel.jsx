import { useState, useEffect, useRef, useCallback } from "react";
import { base44 } from "@/api/base44Client";
import { X, Send, Loader2, MessageCircle } from "lucide-react";

export default function ChatPanel({ lead, currentUser, onClose }) {
  const [conversation, setConversation] = useState(null);
  const [messages, setMessages] = useState([]);
  const [text, setText] = useState("");
  const [sending, setSending] = useState(false);
  const [loading, setLoading] = useState(true);
  const bottomRef = useRef(null);
  const inputRef = useRef(null);
  const unsubRef = useRef(null);

  const isSeller = currentUser?.id === lead?.seller_id;
  const otherName = isSeller ? "Buyer" : "Seller";

  // ── Load or create conversation ──────────────────────────
  const initConversation = useCallback(async () => {
    if (!lead || !currentUser) return;

    // Look for existing conversation for this lead involving current user
    const all = await base44.entities.Conversation.filter({ lead_id: lead.id });
    let conv = all.find(c =>
      c.buyer_id === currentUser.id || c.seller_id === currentUser.id
    );

    if (!conv) {
      // Buyer initiates — seller_id comes from lead
      conv = await base44.entities.Conversation.create({
        lead_id: lead.id,
        buyer_id: currentUser.id,
        buyer_email: currentUser.email,
        seller_id: lead.seller_id,
        lead_title: lead.address || lead.owner_name || "Lead",
        buyer_unread: 0,
        seller_unread: 0,
      });
    }

    setConversation(conv);
    // Load existing messages
    const msgs = await base44.entities.Message.filter({ conversation_id: conv.id });
    msgs.sort((a, b) => new Date(a.created_date) - new Date(b.created_date));
    setMessages(msgs);
    setLoading(false);

    // Mark as read
    if (isSeller && conv.seller_unread > 0) {
      base44.entities.Conversation.update(conv.id, { seller_unread: 0 });
    } else if (!isSeller && conv.buyer_unread > 0) {
      base44.entities.Conversation.update(conv.id, { buyer_unread: 0 });
    }

    // Subscribe to real-time new messages
    if (unsubRef.current) unsubRef.current();
    unsubRef.current = base44.entities.Message.subscribe((event) => {
      if (event.data?.conversation_id !== conv.id) return;
      if (event.type === "create") {
        setMessages(prev => {
          if (prev.find(m => m.id === event.id)) return prev;
          return [...prev, event.data];
        });
      }
    });

    return conv;
  }, [lead, currentUser, isSeller]);

  useEffect(() => {
    initConversation();
    return () => { if (unsubRef.current) unsubRef.current(); };
  }, [initConversation]);

  // Auto-scroll to bottom
  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  const sendMessage = async () => {
    if (!text.trim() || !conversation || sending) return;
    setSending(true);
    const msg = text.trim();
    setText("");
    const receiverId = isSeller ? conversation.buyer_id : conversation.seller_id;

    await base44.entities.Message.create({
      conversation_id: conversation.id,
      lead_id: lead.id,
      sender_id: currentUser.id,
      sender_email: currentUser.email,
      sender_name: currentUser.full_name || currentUser.email,
      receiver_id: receiverId,
      message_text: msg,
    });

    // Update conversation last message + unread count
    const unreadField = isSeller ? "buyer_unread" : "seller_unread";
    const currentUnread = isSeller ? (conversation.buyer_unread || 0) : (conversation.seller_unread || 0);
    await base44.entities.Conversation.update(conversation.id, {
      last_message: msg,
      last_message_at: new Date().toISOString(),
      [unreadField]: currentUnread + 1,
    });

    setSending(false);
    inputRef.current?.focus();
  };

  const handleKey = (e) => {
    if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); sendMessage(); }
  };

  const cat = lead?.category?.replace(/_/g, " ");

  return (
    <div className="fixed inset-0 z-50 flex items-end">
      <div className="absolute inset-0 bg-black/50" onClick={onClose} />
      <div className="relative w-full max-w-lg mx-auto bg-card rounded-t-2xl shadow-2xl flex flex-col"
        style={{ height: "80vh" }}>

        {/* Header */}
        <div className="flex items-center gap-3 px-4 pt-4 pb-3 border-b border-border flex-shrink-0">
          <div className="w-9 h-9 rounded-xl bg-primary/10 flex items-center justify-center flex-shrink-0">
            <MessageCircle className="w-4 h-4 text-primary" />
          </div>
          <div className="flex-1 min-w-0">
            <p className="text-sm font-bold text-foreground truncate">
              {lead?.address || lead?.owner_name || "Lead Chat"}
            </p>
            <p className="text-xs text-muted-foreground capitalize">{otherName} · {cat}</p>
          </div>
          <button onClick={onClose} className="w-8 h-8 rounded-lg bg-muted flex items-center justify-center hover:bg-muted/80">
            <X className="w-4 h-4 text-muted-foreground" />
          </button>
        </div>

        {/* Messages */}
        <div className="flex-1 overflow-y-auto px-4 py-3 space-y-2">
          {loading ? (
            <div className="flex items-center justify-center h-full">
              <Loader2 className="w-5 h-5 text-primary animate-spin" />
            </div>
          ) : messages.length === 0 ? (
            <div className="flex flex-col items-center justify-center h-full text-center">
              <p className="text-2xl mb-2">💬</p>
              <p className="text-sm font-semibold text-foreground">Start the conversation</p>
              <p className="text-xs text-muted-foreground mt-1">Ask questions about this lead before buying.</p>
            </div>
          ) : (
            messages.map(m => {
              const isMe = m.sender_id === currentUser?.id;
              return (
                <div key={m.id} className={`flex ${isMe ? "justify-end" : "justify-start"}`}>
                  <div className={`max-w-[78%] px-3 py-2 rounded-2xl text-sm leading-relaxed ${
                    isMe ? "bg-primary text-white rounded-br-sm" : "bg-muted text-foreground rounded-bl-sm"
                  }`}>
                    <p>{m.message_text}</p>
                    <p className={`text-xs mt-0.5 ${isMe ? "text-white/60" : "text-muted-foreground"}`}>
                      {new Date(m.created_date).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}
                    </p>
                  </div>
                </div>
              );
            })
          )}
          <div ref={bottomRef} />
        </div>

        {/* Input */}
        <div className="px-4 pb-6 pt-2 border-t border-border flex gap-2 flex-shrink-0">
          <input
            ref={inputRef}
            value={text}
            onChange={e => setText(e.target.value)}
            onKeyDown={handleKey}
            placeholder="Type a message…"
            className="flex-1 h-11 px-4 rounded-xl border border-border bg-muted/40 text-sm text-foreground focus:outline-none focus:ring-1 focus:ring-ring placeholder:text-muted-foreground"
          />
          <button onClick={sendMessage} disabled={!text.trim() || sending}
            className="w-11 h-11 rounded-xl bg-primary flex items-center justify-center disabled:opacity-40 active:scale-95 transition-all">
            {sending ? <Loader2 className="w-4 h-4 text-white animate-spin" /> : <Send className="w-4 h-4 text-white" />}
          </button>
        </div>
      </div>
    </div>
  );
}