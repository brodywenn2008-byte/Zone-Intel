import { useEffect, useRef } from "react";
import { base44 } from "@/api/base44Client";
import { toast } from "sonner";

const STATUS_LABELS = {
  not_visited: "Not Visited", knocked: "Knocked", interested: "Interested",
  follow_up: "Follow Up", appointment_set: "Appt Set", sold: "Sold",
  no_answer: "No Answer", not_interested: "Not Interested",
};

const STATUS_ICONS = {
  sold: "🎉", appointment_set: "📅", interested: "✅",
  follow_up: "🔔", knocked: "🚪", not_interested: "❌",
  no_answer: "📵", not_visited: "📍",
};

// Request browser notification permission once
function requestPermission() {
  if ("Notification" in window && Notification.permission === "default") {
    Notification.requestPermission();
  }
}

function pushBrowserNotification(title, body) {
  if ("Notification" in window && Notification.permission === "granted") {
    try { new Notification(title, { body, icon: "/favicon.ico" }); } catch (_) {}
  }
}

export default function LeadNotificationListener({ currentUserEmail }) {
  // Track leads we've seen so we can diff status changes
  const knownLeads = useRef({});
  const initialized = useRef(false);

  useEffect(() => {
    requestPermission();

    // Seed known leads silently on first load
    base44.entities.Lead.list("-updated_date", 200).then(leads => {
      leads.forEach(l => { knownLeads.current[l.id] = l.status; });
      initialized.current = true;
    });

    const unsubscribe = base44.entities.Lead.subscribe((event) => {
      if (!initialized.current) return;

      if (event.type === "create") {
        const lead = event.data;
        const name = lead.owner_name || lead.address || "New lead";
        const msg = `${name} was just added`;
        toast("📍 New Lead Added", {
          description: msg,
          duration: 5000,
        });
        pushBrowserNotification("New Lead Added", msg);
        knownLeads.current[event.id] = lead.status;
      }

      if (event.type === "update") {
        const lead = event.data;
        const prevStatus = knownLeads.current[event.id];
        const newStatus = lead.status;

        if (prevStatus && newStatus && prevStatus !== newStatus) {
          const icon = STATUS_ICONS[newStatus] || "🔄";
          const label = STATUS_LABELS[newStatus] || newStatus;
          const name = lead.owner_name || lead.address || "A lead";
          const msg = `${name} → ${label}`;

          const isHighValue = ["sold", "appointment_set", "interested"].includes(newStatus);

          toast(`${icon} Status Updated`, {
            description: msg,
            duration: isHighValue ? 7000 : 4000,
            style: isHighValue ? { borderLeft: "4px solid #10b981" } : undefined,
          });
          pushBrowserNotification(`${icon} Lead Status: ${label}`, msg);
        }

        knownLeads.current[event.id] = newStatus;
      }

      if (event.type === "delete") {
        delete knownLeads.current[event.id];
      }
    });

    return unsubscribe;
  }, []);

  return null;
}