import { useEffect, useState, useMemo } from "react";
import { MapContainer, TileLayer, Marker, Polygon, Popup, Circle, useMap } from "react-leaflet";
import L from "leaflet";
import "leaflet/dist/leaflet.css";

// Value color scale
function getColor(value) {
  if (value >= 800000) return "#2563eb";
  if (value >= 650000) return "#7c3aed";
  if (value >= 500000) return "#059669";
  if (value >= 400000) return "#d97706";
  return "#dc2626";
}

function formatValue(v) {
  if (!v) return "—";
  if (v >= 1000000) return `$${(v / 1000000).toFixed(1)}M`;
  return `$${(v / 1000).toFixed(0)}k`;
}

const ICON_CACHE = {};
function createHouseIcon(color, status) {
  const key = `${color}-${status}`;
  if (ICON_CACHE[key]) return ICON_CACHE[key];
  const dot = status
    ? `<circle cx="12" cy="10" r="4" fill="white" opacity="0.95"/>`
    : `<circle cx="12" cy="10" r="3" fill="white" opacity="0.7"/>`;
  const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="24" height="32" viewBox="0 0 24 32">
    <path d="M12 0 C5.373 0 0 5.373 0 12 C0 20 12 32 12 32 C12 32 24 20 24 12 C24 5.373 18.627 0 12 0 Z" fill="${color}" stroke="white" stroke-width="1.5"/>
    ${dot}
  </svg>`;
  const icon = L.divIcon({ html: svg, className: "", iconSize: [24, 32], iconAnchor: [12, 32], popupAnchor: [0, -36] });
  ICON_CACHE[key] = icon;
  return icon;
}

const SERVICE_LABELS = {
  solar: "☀️ Solar",
  pest_control: "🐛 Pest",
  power_washing: "💧 Power Wash",
  car_detailing: "🚗 Detailing",
  window_washing: "🪟 Windows",
};
const STATUS_COLORS = { yes: "#16a34a", maybe: "#d97706", no: "#dc2626" };
const LIKELIHOOD_COLORS = { high: "#16a34a", medium: "#d97706", low: "#dc2626" };
const LIKELIHOOD_LABELS = { high: "🔥 High", medium: "≈ Medium", low: "↓ Low" };
const STATUS_LABELS = { yes: "✓ Pitched", maybe: "≈ Callback", no: "✗ Not Home" };

const LEGEND_ITEMS = [
  { label: "$800k+", color: "#2563eb" },
  { label: "$650k–800k", color: "#7c3aed" },
  { label: "$500k–650k", color: "#059669" },
  { label: "$400k–500k", color: "#d97706" },
  { label: "< $400k", color: "#dc2626" },
];

const USER_ICON = L.divIcon({
  html: `<div style="width:18px;height:18px;border-radius:50%;background:#3b82f6;border:3px solid white;box-shadow:0 0 0 3px rgba(59,130,246,0.4),0 2px 6px rgba(0,0,0,0.3);"></div>`,
  className: "",
  iconSize: [18, 18],
  iconAnchor: [9, 9],
});

function FlyToUser({ userLocation }) {
  const map = useMap();
  const [done, setDone] = useState(false);
  useEffect(() => {
    if (userLocation && !done) {
      map.setView(userLocation, 14);
      setDone(true);
    }
  }, [userLocation]);
  return null;
}

function FitBounds({ neighborhoods, houses, searchKey }) {
  const map = useMap();
  useEffect(() => {
    if (!searchKey) return;
    const points = [
      ...neighborhoods.filter((n) => n.lat && n.lng).map((n) => [n.lat, n.lng]),
      ...(houses || []).filter((h) => h.lat && h.lng).map((h) => [h.lat, h.lng]),
    ];
    if (points.length === 0) return;
    if (points.length === 1) { map.setView(points[0], 14); return; }
    const lats = points.map((p) => p[0]);
    const lngs = points.map((p) => p[1]);
    map.fitBounds(
      [[Math.min(...lats) - 0.01, Math.min(...lngs) - 0.01], [Math.max(...lats) + 0.01, Math.max(...lngs) + 0.01]],
      { padding: [24, 24] }
    );
  }, [searchKey]);
  return null;
}

function NeighborhoodPopup({ n }) {
  const color = getColor(n.estimated_value);
  return (
    <div style={{ minWidth: 160, fontFamily: "system-ui, sans-serif", padding: "2px 0" }}>
      <p style={{ fontWeight: 700, fontSize: 13, color: "#0f172a", margin: "0 0 4px" }}>{n.name}</p>
      <p style={{ fontWeight: 800, fontSize: 22, color, margin: "0 0 4px", lineHeight: 1 }}>{formatValue(n.estimated_value)}</p>
      <div style={{ display: "flex", gap: 5, fontSize: 11, color: "#64748b", flexWrap: "wrap", marginBottom: 4 }}>
        <span>#{n.rank}</span>
        <span style={{ color: "#cbd5e1" }}>·</span>
        <span style={{ textTransform: "capitalize" }}>{n.market_trend}</span>
        {n.ownership_rate && (
          <>
            <span style={{ color: "#cbd5e1" }}>·</span>
            <span style={{ color: "#2563eb", fontWeight: 600 }}>{n.ownership_rate}% own</span>
          </>
        )}
      </div>
      {n.popular_services?.length > 0 && (
        <div style={{ display: "flex", flexWrap: "wrap", gap: 3 }}>
          {n.popular_services.map((s) => (
            <span key={s} style={{ fontSize: 10, fontWeight: 600, padding: "2px 5px", borderRadius: 4, background: "#f1f5f9", color: "#475569" }}>
              {SERVICE_LABELS[s] || s}
            </span>
          ))}
        </div>
      )}
    </div>
  );
}

function HousePopup({ h, i, status, onHouseStatus }) {
  return (
    <div style={{ minWidth: 200, fontFamily: "system-ui, sans-serif" }}>
      <div style={{ borderBottom: "1px solid #e2e8f0", paddingBottom: 8, marginBottom: 8 }}>
        <p style={{ fontWeight: 700, fontSize: 13, color: "#0f172a", margin: "0 0 2px" }}>{h.address}</p>
        {h.owner_name && <p style={{ fontSize: 11, color: "#2563eb", fontWeight: 600, margin: 0 }}>{h.owner_name}</p>}
      </div>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 6 }}>
        <span style={{ fontWeight: 800, fontSize: 15, color: getColor(h.estimated_value) }}>{formatValue(h.estimated_value)}</span>
        <span style={{
          fontSize: 10, fontWeight: 700, padding: "2px 7px", borderRadius: 99,
          background: h.is_homeowner ? "#f0fdf4" : "#fef2f2",
          color: h.is_homeowner ? "#16a34a" : "#dc2626",
          border: `1px solid ${h.is_homeowner ? "#bbf7d0" : "#fecaca"}`,
        }}>
          {h.is_homeowner ? "Owner" : "Renter"}
        </span>
      </div>
      {h.contact_likelihood && (
        <div style={{ display: "flex", alignItems: "center", gap: 5, marginBottom: 8 }}>
          <div style={{ width: 7, height: 7, borderRadius: "50%", background: LIKELIHOOD_COLORS[h.contact_likelihood] }} />
          <span style={{ fontSize: 11, color: LIKELIHOOD_COLORS[h.contact_likelihood], fontWeight: 600 }}>
            {LIKELIHOOD_LABELS[h.contact_likelihood]} Likelihood
          </span>
        </div>
      )}
      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: 4 }}>
        {["yes", "maybe", "no"].map((s) => (
          <button
            key={s}
            onClick={() => onHouseStatus?.(i, status === s ? null : s)}
            style={{
              padding: "5px 0",
              fontSize: 10,
              fontWeight: 700,
              borderRadius: 6,
              border: `1.5px solid ${STATUS_COLORS[s]}`,
              background: status === s ? STATUS_COLORS[s] : "white",
              color: status === s ? "white" : STATUS_COLORS[s],
              cursor: "pointer",
            }}
          >
            {STATUS_LABELS[s]}
          </button>
        ))}
      </div>
    </div>
  );
}

export default function NeighborhoodMap({ neighborhoods, houses, houseStatuses, onHouseStatus, searchKey }) {
  const [userLocation, setUserLocation] = useState(null);

  useEffect(() => {
    if (!navigator.geolocation) return;
    const id = navigator.geolocation.watchPosition(
      (pos) => setUserLocation([pos.coords.latitude, pos.coords.longitude]),
      () => {},
      { enableHighAccuracy: false, maximumAge: 10000 }
    );
    return () => navigator.geolocation.clearWatch(id);
  }, []);

  const valid = useMemo(() => neighborhoods.filter((n) => n.lat && n.lng), [neighborhoods]);
  const defaultCenter = valid.length > 0 ? [valid[0].lat, valid[0].lng] : [33.8, -118.3];

  // Fast, clean CartoDB tiles — no API key needed
  const tileUrl = "https://{s}.basemaps.cartocdn.com/rastertiles/voyager/{z}/{x}/{y}{r}.png";

  return (
    <div className="px-5 mb-5">
      <div
        className="rounded-2xl overflow-hidden border border-border shadow-lg"
        style={{ height: 420, isolation: "isolate", position: "relative", zIndex: 0 }}
      >
        <MapContainer
          center={defaultCenter}
          zoom={13}
          style={{ height: "100%", width: "100%" }}
          scrollWheelZoom={true}
          zoomControl={true}
          attributionControl={false}
          preferCanvas={true}
        >
          <FlyToUser userLocation={userLocation} />
          <FitBounds neighborhoods={valid} houses={houses} searchKey={searchKey} />
          <TileLayer url={tileUrl} maxZoom={20} subdomains="abcd" />

          {/* Neighborhood territories */}
          {valid.map((n) => {
            const color = getColor(n.estimated_value);
            const popup = <Popup closeButton={false}><NeighborhoodPopup n={n} /></Popup>;
            return n.polygon && n.polygon.length > 2 ? (
              <Polygon key={n.name} positions={n.polygon} pathOptions={{ color, weight: 2, fillColor: color, fillOpacity: 0.18 }}>
                {popup}
              </Polygon>
            ) : (
              <Circle key={n.name} center={[n.lat, n.lng]} radius={700} pathOptions={{ color, weight: 2, fillColor: color, fillOpacity: 0.18 }}>
                {popup}
              </Circle>
            );
          })}

          {/* House markers */}
          {(houses || []).filter((h) => h.lat && h.lng).map((h, i) => {
            const status = houseStatuses?.[i];
            const color = status ? STATUS_COLORS[status] : (LIKELIHOOD_COLORS[h.contact_likelihood] || "#64748b");
            return (
              <Marker key={`house-${i}`} position={[h.lat, h.lng]} icon={createHouseIcon(color, status)}>
                <Popup closeButton={false}>
                  <HousePopup h={h} i={i} status={status} onHouseStatus={onHouseStatus} />
                </Popup>
              </Marker>
            );
          })}

          {/* User location */}
          {userLocation && (
            <Marker position={userLocation} icon={USER_ICON}>
              <Popup closeButton={false}>
                <div style={{ fontWeight: 700, fontSize: 12, color: "#1e293b" }}>📍 You are here</div>
              </Popup>
            </Marker>
          )}
        </MapContainer>
      </div>

      {/* Legend — Average Home Cost */}
      <div className="mt-3 px-1">
        <p className="text-xs font-semibold text-muted-foreground mb-2 text-center tracking-wide uppercase">Avg. Home Value</p>
        <div className="flex flex-wrap gap-x-4 gap-y-1.5 justify-center">
          {LEGEND_ITEMS.map((item) => (
            <div key={item.label} className="flex items-center gap-1.5">
              <div className="w-3 h-3 rounded-sm flex-shrink-0" style={{ backgroundColor: item.color }} />
              <span className="text-xs text-muted-foreground font-medium">{item.label}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}