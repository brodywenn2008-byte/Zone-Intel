import { useState } from "react";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { X, Upload, CheckCircle, AlertCircle, Download } from "lucide-react";

const CATEGORIES = [
  { id: "life_insurance", label: "Life Insurance" },
  { id: "health_insurance", label: "Health Insurance" },
  { id: "auto_insurance", label: "Auto Insurance" },
  { id: "homeowners_insurance", label: "Homeowners Insurance" },
  { id: "business_insurance", label: "Business Insurance" },
  { id: "medicare", label: "Medicare Health Plans" },
  { id: "real_estate", label: "Real Estate" },
  { id: "mortgage_refinance", label: "Mortgage Refinance" },
  { id: "personal_loans", label: "Personal Loans / Debt / Credit" },
  { id: "business_loans", label: "Business Loans / MCA" },
  { id: "legal", label: "Legal Leads" },
  { id: "solar_home_services", label: "Solar / Home Services" },
  { id: "b2b_saas", label: "B2B SaaS / Services" },
  { id: "telecom_utilities", label: "Telecom / Utilities" },
  { id: "education_career", label: "Education / Career Programs" },
];

export default function CSVUploadModal({ onClose, onUploaded }) {
  const [file, setFile] = useState(null);
  const [category, setCategory] = useState("");
  const [price, setPrice] = useState("25");
  const [listForSale, setListForSale] = useState(true);
  const [uploading, setUploading] = useState(false);
  const [result, setResult] = useState(null);

  const parseCSV = (text) => {
    const lines = text.trim().split("\n");
    if (lines.length < 2) return [];
    const headers = lines[0].split(",").map(h => h.trim().replace(/^"|"$/g, "").toLowerCase());
    return lines.slice(1).map(line => {
      const vals = line.split(",").map(v => v.trim().replace(/^"|"$/g, ""));
      const obj = {};
      headers.forEach((h, i) => { obj[h] = vals[i] || ""; });
      return obj;
    }).filter(r => r.address || r.phone || r.name);
  };

  const handleUpload = async () => {
    if (!file || !category) return;
    setUploading(true);
    setResult(null);

    const text = await file.text();
    const rows = parseCSV(text);
    const user = await base44.auth.me();

    let success = 0;
    let failed = 0;

    for (const row of rows) {
      const address = row.address || row["street address"] || row.street || "";
      if (!address && !row.phone && !row.name) { failed++; continue; }
      const lead = {
        owner_name: row.name || row["full name"] || row["first name"] ? `${row["first name"] || ""} ${row["last name"] || ""}`.trim() : "",
        phone: row.phone || row["phone number"] || "",
        email: row.email || "",
        address: address || `${row.city || ""}, ${row.state || ""}`.trim().replace(/^,\s*/, ""),
        city: row.city || "",
        state: row.state || "",
        zip_code: row.zip || row["zip code"] || row.postal || "",
        notes: row.notes || row.description || "",
        category,
        assigned_rep: user?.email,
        status: "not_visited",
        is_for_sale: listForSale,
        price: listForSale ? parseFloat(price) || 25 : undefined,
        seller_id: listForSale ? user?.id : undefined,
        consent_given: row.consent?.toLowerCase() === "yes" || row.consent?.toLowerCase() === "true",
        quality_score: row["quality score"] ? parseInt(row["quality score"]) : undefined,
        tags: ["csv_import"],
      };
      const created = await base44.entities.Lead.create(lead);
      if (created?.id) success++; else failed++;
    }

    setResult({ success, failed, total: rows.length });
    setUploading(false);
    if (success > 0) onUploaded?.();
  };

  const downloadTemplate = () => {
    const csv = `name,phone,email,address,city,state,zip,notes,quality score,consent\nJohn Smith,(555) 000-0000,john@email.com,123 Main St,Detroit,MI,48201,Interested in coverage,8,yes\nJane Doe,(555) 111-2222,jane@email.com,456 Oak Ave,Chicago,IL,60601,Called twice no answer,6,no`;
    const blob = new Blob([csv], { type: "text/csv" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url; a.download = "lead_template.csv"; a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-end">
      <div className="absolute inset-0 bg-black/50" onClick={onClose} />
      <div className="relative w-full max-w-lg mx-auto bg-card rounded-t-2xl shadow-2xl max-h-[90vh] overflow-y-auto">
        <div className="flex items-center justify-between px-5 pt-5 pb-4 border-b border-border">
          <div className="flex items-center gap-2">
            <Upload className="w-5 h-5 text-primary" />
            <h2 className="font-bold text-foreground text-base">Bulk Upload Leads (CSV)</h2>
          </div>
          <button onClick={onClose} className="min-w-[44px] min-h-[44px] rounded-xl bg-muted flex items-center justify-center">
            <X className="w-4 h-4 text-muted-foreground" />
          </button>
        </div>

        <div className="px-5 py-4 space-y-4">
          <button onClick={downloadTemplate} className="w-full flex items-center justify-center gap-2 py-2.5 rounded-xl border border-dashed border-primary/40 bg-primary/5 text-primary text-sm font-semibold hover:bg-primary/10 transition-colors">
            <Download className="w-4 h-4" /> Download CSV Template
          </button>

          <div>
            <label className="text-xs font-bold text-muted-foreground mb-1.5 block">Upload CSV File *</label>
            <label className={`flex flex-col items-center justify-center w-full h-24 border-2 border-dashed rounded-xl cursor-pointer transition-colors ${file ? "border-primary bg-primary/5" : "border-border hover:bg-muted/40"}`}>
              <input type="file" accept=".csv" className="hidden" onChange={e => setFile(e.target.files[0])} />
              <Upload className={`w-5 h-5 mb-1 ${file ? "text-primary" : "text-muted-foreground"}`} />
              <p className={`text-xs font-semibold ${file ? "text-primary" : "text-muted-foreground"}`}>
                {file ? file.name : "Tap to select CSV file"}
              </p>
            </label>
          </div>

          <div>
            <label className="text-xs font-bold text-muted-foreground mb-1.5 block">Category *</label>
            <div className="grid grid-cols-2 gap-1.5 max-h-40 overflow-y-auto">
              {CATEGORIES.map(c => (
                <button key={c.id} onClick={() => setCategory(c.id)}
                  className={`text-xs py-2 px-2.5 rounded-lg border-2 font-semibold text-left transition-all ${category === c.id ? "border-primary bg-primary/10 text-primary" : "border-border bg-muted/30 text-muted-foreground"}`}>
                  {c.label}
                </button>
              ))}
            </div>
          </div>

          <div className="flex items-center justify-between p-3 bg-muted/40 rounded-xl">
            <div>
              <p className="text-sm font-semibold text-foreground">List for Sale on Marketplace</p>
              <p className="text-xs text-muted-foreground">Publish all uploaded leads immediately</p>
            </div>
            <button onClick={() => setListForSale(v => !v)}
              className={`w-12 h-6 rounded-full transition-colors ${listForSale ? "bg-primary" : "bg-muted-foreground/30"}`}>
              <div className={`w-5 h-5 rounded-full bg-white shadow transition-transform mx-0.5 ${listForSale ? "translate-x-6" : "translate-x-0"}`} />
            </button>
          </div>

          {listForSale && (
            <div>
              <label className="text-xs font-bold text-muted-foreground mb-1.5 block">Price per Lead ($)</label>
              <input type="number" min="1" value={price} onChange={e => setPrice(e.target.value)}
                className="w-full h-10 text-sm border border-border rounded-xl px-3 bg-background text-foreground focus:outline-none focus:ring-1 focus:ring-ring" />
            </div>
          )}

          {result && (
            <div className={`rounded-xl p-3 ${result.failed === 0 ? "bg-green-50 border border-green-200" : "bg-amber-50 border border-amber-200"}`}>
              <div className="flex items-center gap-2 mb-1">
                {result.failed === 0 ? <CheckCircle className="w-4 h-4 text-green-600" /> : <AlertCircle className="w-4 h-4 text-amber-600" />}
                <p className={`text-sm font-bold ${result.failed === 0 ? "text-green-700" : "text-amber-700"}`}>Upload Complete</p>
              </div>
              <p className="text-xs text-muted-foreground">✅ {result.success} leads imported · ❌ {result.failed} skipped</p>
            </div>
          )}

          <Button onClick={handleUpload} disabled={uploading || !file || !category} className="w-full h-11 font-bold text-sm">
            {uploading ? "Uploading..." : `Upload${listForSale ? " & List for Sale" : ""}`}
          </Button>
        </div>
      </div>
    </div>
  );
}