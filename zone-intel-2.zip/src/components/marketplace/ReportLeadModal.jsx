import { useState } from "react";
import { base44 } from "@/api/base44Client";
import { X, Flag, Loader2, CheckCircle } from "lucide-react";
import { Button } from "@/components/ui/button";

const REASONS = [
  { id: "fake_number", label: "📵 Fake or invalid phone number" },
  { id: "wrong_info", label: "❌ Wrong or inaccurate information" },
  { id: "duplicate", label: "🔁 Duplicate lead" },
  { id: "no_consent", label: "🚫 No consent given" },
  { id: "spam", label: "⚠️ Spam / low quality" },
  { id: "other", label: "🔍 Other" },
];

export default function ReportLeadModal({ lead, onClose }) {
  const [reason, setReason] = useState("");
  const [details, setDetails] = useState("");
  const [loading, setLoading] = useState(false);
  const [done, setDone] = useState(false);

  const submit = async () => {
    if (!reason) return;
    setLoading(true);
    await base44.functions.invoke("reportLead", { leadId: lead.id, reason, details });
    setLoading(false);
    setDone(true);
    setTimeout(onClose, 1500);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-end">
      <div className="absolute inset-0 bg-black/50" onClick={onClose} />
      <div className="relative w-full max-w-lg mx-auto bg-card rounded-t-2xl shadow-2xl p-5 pb-10">
        <button onClick={onClose} className="absolute top-4 right-4 w-8 h-8 rounded-lg bg-muted flex items-center justify-center">
          <X className="w-4 h-4 text-muted-foreground" />
        </button>

        {done ? (
          <div className="flex flex-col items-center gap-3 py-6">
            <CheckCircle className="w-10 h-10 text-green-500" />
            <p className="font-bold text-foreground">Report Submitted</p>
            <p className="text-xs text-muted-foreground text-center">Our team will review this lead. Thank you for keeping the marketplace safe.</p>
          </div>
        ) : (
          <>
            <div className="flex items-center gap-3 mb-4">
              <div className="w-9 h-9 rounded-xl bg-destructive/10 flex items-center justify-center">
                <Flag className="w-4 h-4 text-destructive" />
              </div>
              <div>
                <p className="font-bold text-foreground text-sm">Report This Lead</p>
                <p className="text-xs text-muted-foreground">Help keep the marketplace clean</p>
              </div>
            </div>

            <div className="space-y-2 mb-4">
              {REASONS.map(r => (
                <button key={r.id} onClick={() => setReason(r.id)}
                  className={`w-full text-left px-3 py-2.5 rounded-xl border text-sm transition-colors ${
                    reason === r.id
                      ? "border-destructive bg-destructive/5 text-destructive font-semibold"
                      : "border-border text-foreground hover:bg-muted"
                  }`}>
                  {r.label}
                </button>
              ))}
            </div>

            {reason === "other" && (
              <textarea
                value={details}
                onChange={e => setDetails(e.target.value)}
                placeholder="Please describe the issue..."
                rows={3}
                className="w-full mb-4 px-3 py-2 rounded-xl border border-border bg-muted/40 text-sm text-foreground resize-none focus:outline-none focus:ring-1 focus:ring-ring placeholder:text-muted-foreground"
              />
            )}

            <Button onClick={submit} disabled={!reason || loading} variant="destructive" className="w-full h-11">
              {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : "Submit Report"}
            </Button>
          </>
        )}
      </div>
    </div>
  );
}