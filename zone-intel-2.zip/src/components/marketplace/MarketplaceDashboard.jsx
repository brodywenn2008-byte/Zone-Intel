import { useMemo } from "react";
import { TrendingUp, ShoppingCart, Star, DollarSign, BarChart2, Award } from "lucide-react";

const CATEGORIES = [
  { id: "life_insurance",       emoji: "❤️",  label: "Life Insurance" },
  { id: "health_insurance",     emoji: "🏥",  label: "Health Insurance" },
  { id: "auto_insurance",       emoji: "🚗",  label: "Auto Insurance" },
  { id: "homeowners_insurance", emoji: "🏠",  label: "Homeowners" },
  { id: "business_insurance",   emoji: "🏢",  label: "Business Insurance" },
  { id: "medicare",             emoji: "💊",  label: "Medicare" },
  { id: "real_estate",          emoji: "🏡",  label: "Real Estate" },
  { id: "mortgage_refinance",   emoji: "🏦",  label: "Mortgage" },
  { id: "personal_loans",       emoji: "💳",  label: "Personal Loans" },
  { id: "business_loans",       emoji: "💼",  label: "Business Loans" },
  { id: "legal",                emoji: "⚖️",  label: "Legal" },
  { id: "solar_home_services",  emoji: "☀️",  label: "Solar" },
  { id: "b2b_saas",             emoji: "💻",  label: "B2B Services" },
  { id: "telecom_utilities",    emoji: "📡",  label: "Telecom" },
  { id: "education_career",     emoji: "🎓",  label: "Education" },
];

function StatCard({ icon: Icon, label, value, sub, color = "text-primary" }) {
  return (
    <div className="bg-card border border-border rounded-2xl p-4 flex items-center gap-3">
      <div className={`w-10 h-10 rounded-xl bg-muted flex items-center justify-center flex-shrink-0`}>
        <Icon className={`w-5 h-5 ${color}`} />
      </div>
      <div className="min-w-0">
        <p className="text-xs text-muted-foreground font-semibold">{label}</p>
        <p className="text-xl font-black text-foreground leading-tight">{value}</p>
        {sub && <p className="text-xs text-muted-foreground">{sub}</p>}
      </div>
    </div>
  );
}

export default function MarketplaceDashboard({ leads, transactions, user }) {
  const stats = useMemo(() => {
    const completed = transactions.filter(t => t.status === "completed");
    const totalListed = leads.length;
    const convRate = totalListed > 0 ? Math.round((completed.length / Math.max(totalListed, 1)) * 100) : 0;
    const totalRevenue = completed.reduce((s, t) => s + (t.price || 0), 0);
    const avgPrice = completed.length > 0 ? (totalRevenue / completed.length).toFixed(0) : 0;

    // Average price by category
    const byCategory = {};
    leads.forEach(l => {
      if (!l.category) return;
      if (!byCategory[l.category]) byCategory[l.category] = { total: 0, count: 0, sold: 0 };
      byCategory[l.category].total += l.price || 0;
      byCategory[l.category].count++;
    });
    completed.forEach(t => {
      const lead = leads.find(l => l.id === t.lead_id);
      if (lead?.category) {
        if (!byCategory[lead.category]) byCategory[lead.category] = { total: 0, count: 0, sold: 0 };
        byCategory[lead.category].sold++;
      }
    });
    const categoryStats = Object.entries(byCategory)
      .map(([id, v]) => ({
        id,
        avg: v.count > 0 ? Math.round(v.total / v.count) : 0,
        count: v.count,
        sold: v.sold,
        convRate: v.count > 0 ? Math.round((v.sold / v.count) * 100) : 0,
      }))
      .sort((a, b) => b.count - a.count)
      .slice(0, 8);

    // Seller reputation: ratio of completed sales, weighted by volume
    const sellerMap = {};
    transactions.forEach(t => {
      if (!t.seller_id) return;
      if (!sellerMap[t.seller_id]) sellerMap[t.seller_id] = { completed: 0, total: 0, revenue: 0 };
      sellerMap[t.seller_id].total++;
      if (t.status === "completed") {
        sellerMap[t.seller_id].completed++;
        sellerMap[t.seller_id].revenue += t.price || 0;
      }
    });
    const topSellers = Object.entries(sellerMap)
      .map(([id, v]) => ({
        id,
        score: v.total > 0 ? Math.round((v.completed / v.total) * 10) : 0,
        sales: v.completed,
        revenue: v.revenue,
        isMe: id === user?.id,
      }))
      .filter(s => s.sales > 0)
      .sort((a, b) => b.sales - a.sales)
      .slice(0, 5);

    return { convRate, totalRevenue, avgPrice, categoryStats, topSellers, totalSales: completed.length, totalListed };
  }, [leads, transactions, user]);

  const maxCatCount = Math.max(...stats.categoryStats.map(c => c.count), 1);

  return (
    <div className="space-y-4 px-4 pt-2 pb-4">
      {/* KPI row */}
      <div className="grid grid-cols-2 gap-2.5">
        <StatCard icon={ShoppingCart} label="Total Sales" value={stats.totalSales} sub={`of ${stats.totalListed} listed`} color="text-primary" />
        <StatCard icon={TrendingUp} label="Conversion Rate" value={`${stats.convRate}%`} sub="leads sold" color="text-green-600" />
        <StatCard icon={DollarSign} label="Avg Sale Price" value={`$${stats.avgPrice}`} sub="per lead" color="text-yellow-600" />
        <StatCard icon={BarChart2} label="Total Volume" value={`$${stats.totalRevenue.toFixed(0)}`} sub="all time" color="text-blue-600" />
      </div>

      {/* Category breakdown */}
      <div className="bg-card border border-border rounded-2xl p-4">
        <div className="flex items-center gap-2 mb-3">
          <BarChart2 className="w-4 h-4 text-primary" />
          <p className="text-sm font-bold text-foreground">Avg Price by Category</p>
        </div>
        {stats.categoryStats.length === 0 ? (
          <p className="text-xs text-muted-foreground text-center py-4">No listed leads yet.</p>
        ) : (
          <div className="space-y-2.5">
            {stats.categoryStats.map(c => {
              const cat = CATEGORIES.find(x => x.id === c.id);
              const barW = Math.round((c.count / maxCatCount) * 100);
              return (
                <div key={c.id}>
                  <div className="flex items-center justify-between mb-1">
                    <span className="text-xs font-semibold text-foreground truncate max-w-[55%]">
                      {cat?.emoji} {cat?.label || c.id}
                    </span>
                    <div className="flex items-center gap-2 text-xs text-muted-foreground">
                      <span className="font-bold text-foreground">${c.avg}</span>
                      <span>{c.convRate}% conv</span>
                    </div>
                  </div>
                  <div className="w-full h-1.5 bg-muted rounded-full overflow-hidden">
                    <div className="h-full bg-primary rounded-full transition-all" style={{ width: `${barW}%` }} />
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* Seller leaderboard */}
      <div className="bg-card border border-border rounded-2xl p-4">
        <div className="flex items-center gap-2 mb-3">
          <Award className="w-4 h-4 text-yellow-500" />
          <p className="text-sm font-bold text-foreground">Top Sellers</p>
          <span className="text-xs text-muted-foreground ml-auto">by completed sales</span>
        </div>
        {stats.topSellers.length === 0 ? (
          <p className="text-xs text-muted-foreground text-center py-4">No completed transactions yet.</p>
        ) : (
          <div className="space-y-2">
            {stats.topSellers.map((s, i) => (
              <div key={s.id} className={`flex items-center gap-3 p-2.5 rounded-xl ${s.isMe ? "bg-primary/10 border border-primary/30" : "bg-muted/40"}`}>
                <div className="w-7 h-7 rounded-full bg-muted flex items-center justify-center text-sm font-black text-muted-foreground flex-shrink-0">
                  {i === 0 ? "🥇" : i === 1 ? "🥈" : i === 2 ? "🥉" : `#${i + 1}`}
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-xs font-bold text-foreground truncate">
                    {s.isMe ? "You" : `Seller #${s.id.slice(-4)}`}
                    {s.isMe && <span className="ml-1 text-primary">✓</span>}
                  </p>
                  <p className="text-xs text-muted-foreground">{s.sales} sales · ${s.revenue.toFixed(0)} revenue</p>
                </div>
                <div className="flex items-center gap-0.5 flex-shrink-0">
                  {[...Array(5)].map((_, j) => (
                    <Star key={j} className={`w-3 h-3 ${j < Math.round(s.score / 2) ? "text-yellow-500 fill-yellow-500" : "text-muted"}`} />
                  ))}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}