import { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { CheckCircle, AlertCircle, ExternalLink, Loader2, DollarSign, Zap } from "lucide-react";
import { Button } from "@/components/ui/button";

const PLATFORM_FEE_PCT = 15;

export default function StripeConnectBanner() {
  const [status, setStatus] = useState(null); // null | loading | { connected, onboarded, ... }
  const [connecting, setConnecting] = useState(false);

  const checkStatus = async () => {
    setStatus("loading");
    const res = await base44.functions.invoke("stripeConnectStatus", {});
    setStatus(res.data || { connected: false, onboarded: false });
  };

  useEffect(() => {
    checkStatus();
    // Auto-refresh after returning from Stripe onboarding
    const params = new URLSearchParams(window.location.search);
    if (params.get("connect_return") || params.get("connect_refresh")) {
      window.history.replaceState(null, "", "/marketplace");
      checkStatus();
    }
  }, []);

  const handleConnect = async () => {
    if (window.self !== window.top) {
      alert("Stripe Connect setup only works from the published app.");
      return;
    }
    setConnecting(true);
    const returnUrl = window.location.origin + "/marketplace";
    const res = await base44.functions.invoke("stripeConnectOnboard", { returnUrl });
    if (res.data?.alreadyOnboarded) {
      checkStatus();
    } else if (res.data?.url) {
      window.location.href = res.data.url;
    } else {
      alert(res.data?.error || "Could not start onboarding");
    }
    setConnecting(false);
  };

  if (status === null || status === "loading") {
    return (
      <div className="mx-0 mb-3 bg-muted/40 rounded-xl p-3 flex items-center gap-2">
        <Loader2 className="w-4 h-4 animate-spin text-muted-foreground" />
        <p className="text-xs text-muted-foreground">Checking payout status...</p>
      </div>
    );
  }

  if (status.onboarded) {
    return (
      <div className="mb-3 bg-green-50 border border-green-200 rounded-xl p-3">
        <div className="flex items-center gap-2 mb-1">
          <CheckCircle className="w-4 h-4 text-green-600 flex-shrink-0" />
          <p className="text-sm font-bold text-green-700">Stripe Payouts Active</p>
        </div>
        <p className="text-xs text-green-600">
          You receive <strong>{100 - PLATFORM_FEE_PCT}%</strong> of each sale — {PLATFORM_FEE_PCT}% platform fee. Payouts go directly to your bank.
        </p>
      </div>
    );
  }

  return (
    <div className="mb-3 bg-amber-50 border border-amber-200 rounded-xl p-3">
      <div className="flex items-start gap-2 mb-2">
        <AlertCircle className="w-4 h-4 text-amber-600 flex-shrink-0 mt-0.5" />
        <div>
          <p className="text-sm font-bold text-amber-700">Connect Stripe to Receive Payouts</p>
          <p className="text-xs text-amber-600 mt-0.5">
            Without Stripe Connect, the platform collects the full sale amount. Connect now to automatically receive <strong>{100 - PLATFORM_FEE_PCT}%</strong> of every sale.
          </p>
        </div>
      </div>
      <div className="grid grid-cols-3 gap-1.5 mb-3">
        {[
          { icon: DollarSign, label: `${100 - PLATFORM_FEE_PCT}% to you`, sub: "of every sale" },
          { icon: Zap, label: "Auto payouts", sub: "direct to bank" },
          { icon: CheckCircle, label: "Verified", sub: "secure & fast" },
        ].map(({ icon: Icon, label, sub }) => (
          <div key={label} className="bg-white rounded-lg p-2 text-center border border-amber-100">
            <Icon className="w-3.5 h-3.5 text-amber-600 mx-auto mb-0.5" />
            <p className="text-xs font-bold text-amber-700">{label}</p>
            <p className="text-xs text-amber-500">{sub}</p>
          </div>
        ))}
      </div>
      <Button onClick={handleConnect} disabled={connecting}
        className="w-full h-10 text-sm font-bold gap-2 bg-amber-500 hover:bg-amber-600 text-white border-0">
        {connecting
          ? <><Loader2 className="w-4 h-4 animate-spin" />Redirecting to Stripe...</>
          : <><ExternalLink className="w-4 h-4" />Connect Stripe Account</>}
      </Button>
    </div>
  );
}