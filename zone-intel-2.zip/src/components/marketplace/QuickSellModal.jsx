import { useState, useRef } from "react";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { X, Zap, Plus, CheckCircle, Trash2 } from "lucide-react";
import { CATEGORIES } from "./SellLeadModal";

export default function QuickSellModal({ onClose, onDone }) {
  const [rows, setRows] = useState([{ name: "", phone: "" }]);
  const [category, setCategory] = useState("life_insurance");
  const [price, setPrice] = useState("25");
  const [saving, setSaving] = useState(false);
  const [savedCount, setSavedCount] = useState(0);
  const lastPhoneRef = useRef(null);

  const updateRow = (i, field, val) => {
    setRows(prev => prev.map((r, idx) => idx === i ? { ...r, [field]: val } : r));
  };

  const addRow = () => {
    setRows(prev => [...prev, { name: "", phone: "" }]);
    setTimeout(() => lastPhoneRef.current?.focus(), 50);
  };

  const removeRow = (i) => {
    setRows(prev => prev.length === 1 ? [{ name: "", phone: "" }] : prev.filter((_, idx) => idx !== i));
  };

  const handlePhoneKeyDown = (e, i) => {
    if (e.key === "Enter") {
      e.preventDefault();
      if (i === rows.length - 1) addRow();
    }
  };

  const submit = async () => {
    const valid = rows.filter(r => r.phone.trim() || r.name.trim());
    if (!valid.length) return;
    setSaving(true);
    const user = await base44.auth.me();
    let count = 0;
    for (const row of valid) {
      await base44.entities.Lead.create({
        owner_name: row.name.trim(),
        phone: row.phone.trim(),
        address: row.name.trim() || row.phone.trim(),
        category,
        status: "not_visited",
        is_for_sale: true,
        price: parseFloat(price) || 25,
        seller_id: user?.id || "",
        assigned_rep: user?.email,
        tags: ["quick_sell"],
      });
      count++;
    }
    setSavedCount(count);
    setSaving(false);
    onDone?.();
    setTimeout(onClose, 1200);
  };

  const cat = CATEGORIES.find(c => c.id === category);

  return (
    <div className="fixed inset-0 z-50 flex items-end">
      <div className="absolute inset-0 bg-black/50" onClick={onClose} />
      <div className="relative w-full max-w-lg mx-auto bg-card rounded-t-2xl shadow-2xl max-h-[92vh] flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between px-5 pt-5 pb-4 border-b border-border flex-shrink-0">
          <div className="flex items-center gap-2">
            <Zap className="w-5 h-5 text-yellow-500" />
            <h2 className="font-bold text-foreground text-base">Quick Sell Numbers</h2>
          </div>
          <button onClick={onClose} className="min-w-[44px] min-h-[44px] rounded-xl bg-muted flex items-center justify-center">
            <X className="w-4 h-4 text-muted-foreground" />
          </button>
        </div>

        {/* Settings row */}
        <div className="px-5 pt-3 pb-3 flex gap-2 flex-shrink-0 border-b border-border">
          <div className="flex-1">
            <label className="text-xs font-bold text-muted-foreground mb-1 block">Category</label>
            <select value={category} onChange={e => setCategory(e.target.value)}
              className="w-full h-9 text-xs border border-border rounded-lg px-2 bg-background text-foreground focus:outline-none focus:ring-1 focus:ring-ring">
              {CATEGORIES.map(c => <option key={c.id} value={c.id}>{c.emoji} {c.label}</option>)}
            </select>
          </div>
          <div className="w-20 flex-shrink-0">
            <label className="text-xs font-bold text-muted-foreground mb-1 block">Price ($)</label>
            <input type="number" min="1" value={price} onChange={e => setPrice(e.target.value)}
              className="w-full h-9 text-sm text-center font-bold border border-border rounded-lg px-2 bg-background text-foreground focus:outline-none focus:ring-1 focus:ring-ring" />
          </div>
        </div>

        {/* Column headers */}
        <div className="px-5 pt-2 pb-1 flex gap-2 flex-shrink-0">
          <p className="flex-1 text-xs font-bold text-muted-foreground">Name</p>
          <p className="flex-1 text-xs font-bold text-muted-foreground">Phone Number</p>
          <div className="w-8" />
        </div>

        {/* Rows */}
        <div className="flex-1 overflow-y-auto px-5 pb-2 space-y-2">
          {rows.map((row, i) => (
            <div key={i} className="flex gap-2 items-center">
              <input
                placeholder={`Name ${i + 1}`}
                value={row.name}
                onChange={e => updateRow(i, "name", e.target.value)}
                className="flex-1 h-11 text-sm border border-border rounded-xl px-3 bg-background text-foreground focus:outline-none focus:ring-1 focus:ring-ring placeholder:text-muted-foreground"
              />
              <input
                ref={i === rows.length - 1 ? lastPhoneRef : null}
                placeholder="(555) 000-0000"
                value={row.phone}
                type="tel"
                onChange={e => updateRow(i, "phone", e.target.value)}
                onKeyDown={e => handlePhoneKeyDown(e, i)}
                className="flex-1 h-11 text-sm border border-border rounded-xl px-3 bg-background text-foreground focus:outline-none focus:ring-1 focus:ring-ring placeholder:text-muted-foreground"
              />
              <button onClick={() => removeRow(i)}
                className="w-8 h-8 rounded-lg flex items-center justify-center text-muted-foreground hover:text-red-500 flex-shrink-0">
                <Trash2 className="w-3.5 h-3.5" />
              </button>
            </div>
          ))}

          <button onClick={addRow}
            className="w-full h-10 flex items-center justify-center gap-2 border-2 border-dashed border-border rounded-xl text-sm font-semibold text-muted-foreground hover:border-primary hover:text-primary transition-colors">
            <Plus className="w-4 h-4" /> Add Row
          </button>
        </div>

        {/* Footer */}
        <div className="px-5 pb-6 pt-3 border-t border-border flex-shrink-0 space-y-2">
          {savedCount > 0 && (
            <div className="flex items-center gap-2 bg-green-50 border border-green-200 rounded-xl px-3 py-2">
              <CheckCircle className="w-4 h-4 text-green-600" />
              <p className="text-sm font-bold text-green-700">✅ {savedCount} leads listed for sale!</p>
            </div>
          )}
          <div className="flex items-center justify-between mb-2">
            <p className="text-xs text-muted-foreground">
              <span className="font-bold text-foreground">{rows.filter(r => r.phone || r.name).length}</span> leads ready · {cat?.emoji} {cat?.label} · <span className="font-bold">${price} each</span>
            </p>
          </div>
          <Button onClick={submit} disabled={saving || !rows.some(r => r.phone || r.name)} className="w-full h-12 font-bold text-base gap-2">
            {saving ? "Listing..." : `List ${rows.filter(r => r.phone || r.name).length} Lead${rows.filter(r => r.phone || r.name).length !== 1 ? "s" : ""} for Sale`}
          </Button>
        </div>
      </div>
    </div>
  );
}