import { ShieldCheck, Star, BadgeCheck, Phone } from "lucide-react";

export function TrustBadges({ lead }) {
  const badges = [];

  if (lead.is_phone_verified || lead.verification_status === "verified") {
    badges.push(
      <span key="phone" className="inline-flex items-center gap-0.5 text-xs font-bold text-emerald-700 bg-emerald-50 border border-emerald-200 px-1.5 py-0.5 rounded-md">
        <Phone className="w-2.5 h-2.5" /> Verified
      </span>
    );
  }

  if (lead.consent_given) {
    badges.push(
      <span key="consent" className="inline-flex items-center gap-0.5 text-xs font-bold text-blue-700 bg-blue-50 border border-blue-200 px-1.5 py-0.5 rounded-md">
        <BadgeCheck className="w-2.5 h-2.5" /> Consent
      </span>
    );
  }

  if (lead.trust_score >= 80) {
    badges.push(
      <span key="hq" className="inline-flex items-center gap-0.5 text-xs font-bold text-yellow-700 bg-yellow-50 border border-yellow-200 px-1.5 py-0.5 rounded-md">
        <Star className="w-2.5 h-2.5" /> High Quality
      </span>
    );
  }

  if (lead.quality_score >= 8) {
    badges.push(
      <span key="qs" className="inline-flex items-center gap-0.5 text-xs font-bold text-purple-700 bg-purple-50 border border-purple-200 px-1.5 py-0.5 rounded-md">
        ⭐{lead.quality_score}
      </span>
    );
  }

  if (!badges.length) return null;

  return (
    <div className="flex flex-wrap gap-1 mt-1">
      {badges}
    </div>
  );
}

export function SellerBadge({ user }) {
  if (!user) return null;
  const level = user.verification_level;
  const sales = user.successful_sales || 0;

  return (
    <div className="flex items-center gap-1 flex-wrap">
      {(level === "phone" || level === "identity") && (
        <span className="inline-flex items-center gap-0.5 text-xs font-bold text-emerald-700 bg-emerald-50 border border-emerald-200 px-1.5 py-0.5 rounded-md">
          <ShieldCheck className="w-2.5 h-2.5" /> Verified Seller
        </span>
      )}
      {sales >= 10 && (
        <span className="inline-flex items-center gap-0.5 text-xs font-bold text-yellow-700 bg-yellow-50 border border-yellow-200 px-1.5 py-0.5 rounded-md">
          <Star className="w-2.5 h-2.5" /> Trusted Seller
        </span>
      )}
    </div>
  );
}