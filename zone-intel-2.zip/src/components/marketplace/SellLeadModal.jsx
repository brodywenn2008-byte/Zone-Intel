import { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { X, DollarSign, Tag, FileText, Search, Star } from "lucide-react";

export const CATEGORIES = [
  { id: "life_insurance", label: "Life Insurance", emoji: "❤️" },
  { id: "health_insurance", label: "Health Insurance", emoji: "🏥" },
  { id: "auto_insurance", label: "Auto Insurance", emoji: "🚗" },
  { id: "homeowners_insurance", label: "Homeowners Insurance", emoji: "🏠" },
  { id: "business_insurance", label: "Business Insurance", emoji: "🏢" },
  { id: "medicare", label: "Medicare Health Plans", emoji: "💊" },
  { id: "real_estate", label: "Real Estate", emoji: "🏡" },
  { id: "mortgage_refinance", label: "Mortgage Refinance", emoji: "🏦" },
  { id: "personal_loans", label: "Personal Loans / Debt / Credit", emoji: "💳" },
  { id: "business_loans", label: "Business Loans / MCA", emoji: "💼" },
  { id: "legal", label: "Legal Leads", emoji: "⚖️" },
  { id: "solar_home_services", label: "Solar / Home Services", emoji: "☀️" },
  { id: "b2b_saas", label: "B2B SaaS / Services", emoji: "💻" },
  { id: "telecom_utilities", label: "Telecom / Utilities", emoji: "📡" },
  { id: "education_career", label: "Education / Career Programs", emoji: "🎓" },
];

export default function SellLeadModal({ lead: initialLead, onClose, onListed }) {
  const [price, setPrice] = useState(initialLead?.price?.toString() || "25");
  const [category, setCategory] = useState(initialLead?.category || "");
  const [description, setDescription] = useState(initialLead?.listing_description || "");
  const [qualityScore, setQualityScore] = useState(initialLead?.quality_score?.toString() || "7");
  const [consentGiven, setConsentGiven] = useState(initialLead?.consent_given || false);
  const [saving, setSaving] = useState(false);
  const [user, setUser] = useState(null);
  const [leads, setLeads] = useState([]);
  const [selectedLead, setSelectedLead] = useState(initialLead || null);
  const [leadsSearch, setLeadsSearch] = useState("");
  const [loadingLeads, setLoadingLeads] = useState(!initialLead);

  useEffect(() => {
    base44.auth.me().then(setUser);
    if (!initialLead) {
      base44.entities.Lead.list("-created_date", 200)
        .then(all => setLeads(all.filter(l => !l.is_for_sale)))
        .finally(() => setLoadingLeads(false));
    }
  }, []);

  const filteredLeads = leads.filter(l => {
    const q = leadsSearch.toLowerCase();
    return !q || l.address?.toLowerCase().includes(q) || l.owner_name?.toLowerCase().includes(q);
  });

  const submit = async () => {
    const lead = selectedLead;
    if (!lead || !category || !price) return;
    setSaving(true);
    const updated = await base44.entities.Lead.update(lead.id, {
      is_for_sale: true,
      price: parseFloat(price),
      category,
      listing_description: description,
      quality_score: parseInt(qualityScore) || 7,
      consent_given: consentGiven,
      seller_id: user?.id || "",
    });
    setSaving(false);
    onListed?.(updated);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-end">
      <div className="absolute inset-0 bg-black/50" onClick={onClose} />
      <div className="relative w-full max-w-lg mx-auto bg-card rounded-t-2xl shadow-2xl max-h-[90vh] overflow-y-auto">
        <div className="flex items-center justify-between px-5 pt-5 pb-4 border-b border-border">
          <div className="flex items-center gap-2">
            <Tag className="w-5 h-5 text-primary" />
            <h2 className="font-bold text-foreground text-base">List Lead for Sale</h2>
          </div>
          <button onClick={onClose} className="min-w-[44px] min-h-[44px] rounded-xl bg-muted flex items-center justify-center">
            <X className="w-4 h-4 text-muted-foreground" />
          </button>
        </div>

        <div className="px-5 py-4 space-y-4">
          {!initialLead && (
            <div>
              <label className="text-xs font-bold text-muted-foreground mb-1.5 block">Select a Lead from Your CRM</label>
              <div className="relative mb-2">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-muted-foreground" />
                <Input placeholder="Search by address or name..." value={leadsSearch}
                  onChange={e => setLeadsSearch(e.target.value)} className="pl-9 h-9 text-sm" />
              </div>
              {loadingLeads ? <p className="text-xs text-muted-foreground text-center py-3">Loading leads...</p> : (
                <div className="max-h-40 overflow-y-auto space-y-1.5 border border-border rounded-xl p-2">
                  {filteredLeads.slice(0, 30).map(l => (
                    <button key={l.id} onClick={() => setSelectedLead(l)}
                      className={`w-full text-left p-2.5 rounded-lg text-xs transition-colors ${selectedLead?.id === l.id ? "bg-primary/10 border border-primary text-primary font-semibold" : "bg-muted/30 hover:bg-muted text-foreground"}`}>
                      <p className="font-semibold truncate">{l.address}</p>
                      {l.owner_name && <p className="text-muted-foreground">{l.owner_name}</p>}
                    </button>
                  ))}
                  {filteredLeads.length === 0 && <p className="text-xs text-muted-foreground text-center py-2">No eligible leads</p>}
                </div>
              )}
            </div>
          )}

          {initialLead && (
            <div className="bg-muted/40 rounded-xl p-3">
              <p className="text-xs font-bold text-muted-foreground mb-0.5">Listing Lead</p>
              <p className="text-sm font-semibold text-foreground">{initialLead.address}</p>
              {initialLead.owner_name && <p className="text-xs text-muted-foreground">{initialLead.owner_name}</p>}
            </div>
          )}

          {/* Category */}
          <div>
            <label className="text-xs font-bold text-muted-foreground mb-1.5 block">Category *</label>
            <div className="grid grid-cols-2 gap-1.5 max-h-48 overflow-y-auto">
              {CATEGORIES.map(c => (
                <button key={c.id} onClick={() => setCategory(c.id)}
                  className={`text-xs py-2 px-2.5 rounded-lg border-2 font-semibold text-left flex items-center gap-1.5 transition-all ${category === c.id ? "border-primary bg-primary/10 text-primary" : "border-border bg-muted/30 text-muted-foreground"}`}>
                  <span>{c.emoji}</span>{c.label}
                </button>
              ))}
            </div>
          </div>

          {/* Price + Quality Score */}
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="text-xs font-bold text-muted-foreground mb-1.5 block">Price ($) *</label>
              <div className="relative">
                <DollarSign className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                <Input type="number" min="1" placeholder="25" value={price}
                  onChange={e => setPrice(e.target.value)} className="pl-9 h-10 text-sm" />
              </div>
            </div>
            <div>
              <label className="text-xs font-bold text-muted-foreground mb-1.5 flex items-center gap-1">
                <Star className="w-3 h-3" /> Quality (1-10)
              </label>
              <Input type="number" min="1" max="10" placeholder="7" value={qualityScore}
                onChange={e => setQualityScore(e.target.value)} className="h-10 text-sm" />
            </div>
          </div>

          {/* Description */}
          <div>
            <label className="text-xs font-bold text-muted-foreground mb-1.5 flex items-center gap-1.5">
              <FileText className="w-3 h-3" /> Listing Description
            </label>
            <textarea placeholder="e.g. Homeowner, expressed interest, good income area..."
              value={description} onChange={e => setDescription(e.target.value)} rows={3}
              className="w-full text-sm border border-border rounded-xl px-3 py-2.5 bg-background text-foreground resize-none focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring placeholder:text-muted-foreground" />
          </div>

          {/* Consent */}
          <button onClick={() => setConsentGiven(v => !v)}
            className="w-full flex items-center gap-3 p-3 bg-muted/40 rounded-xl text-left">
            <div className={`w-5 h-5 rounded border-2 flex items-center justify-center flex-shrink-0 transition-colors ${consentGiven ? "bg-primary border-primary" : "border-border bg-background"}`}>
              {consentGiven && <span className="text-white text-xs font-black">✓</span>}
            </div>
            <div>
              <p className="text-xs font-semibold text-foreground">Contact consented to be contacted</p>
              <p className="text-xs text-muted-foreground">Leads with consent sell faster</p>
            </div>
          </button>

          <div className="bg-amber-50 border border-amber-200 rounded-xl p-3">
            <p className="text-xs text-amber-700">⚠️ Full contact info (name, phone, email, address) is hidden until purchase.</p>
          </div>

          <Button onClick={submit} disabled={saving || !selectedLead || !category || !price} className="w-full h-11 font-bold text-sm">
            {saving ? "Publishing..." : "Publish to Marketplace"}
          </Button>
        </div>
      </div>
    </div>
  );
}