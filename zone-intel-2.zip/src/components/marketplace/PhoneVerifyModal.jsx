import { useState } from "react";
import { base44 } from "@/api/base44Client";
import { X, Phone, ShieldCheck, Loader2, CheckCircle } from "lucide-react";
import { Button } from "@/components/ui/button";

export default function PhoneVerifyModal({ lead, onClose, onVerified }) {
  const [step, setStep] = useState("phone"); // phone | code | done
  const [phone, setPhone] = useState(lead?.phone || "");
  const [code, setCode] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [isDemo, setIsDemo] = useState(false);

  const sendCode = async () => {
    setError("");
    setLoading(true);
    const res = await base44.functions.invoke("verifyPhone", { phone, leadId: lead?.id });
    setLoading(false);
    if (res.data?.success) {
      setIsDemo(!!res.data?.demo);
      setStep("code");
    } else {
      setError(res.data?.error || "Failed to send code");
    }
  };

  const checkCode = async () => {
    setError("");
    setLoading(true);
    const res = await base44.functions.invoke("checkVerifyCode", { phone, code, leadId: lead?.id });
    setLoading(false);
    if (res.data?.verified) {
      setStep("done");
      setTimeout(() => { onVerified?.(); onClose(); }, 1200);
    } else {
      setError(res.data?.error || "Incorrect code. Try again.");
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-end">
      <div className="absolute inset-0 bg-black/50" onClick={onClose} />
      <div className="relative w-full max-w-lg mx-auto bg-card rounded-t-2xl shadow-2xl p-6 pb-10">
        <button onClick={onClose} className="absolute top-4 right-4 w-8 h-8 rounded-lg bg-muted flex items-center justify-center">
          <X className="w-4 h-4 text-muted-foreground" />
        </button>

        <div className="flex items-center gap-3 mb-5">
          <div className="w-10 h-10 rounded-xl bg-primary/10 flex items-center justify-center">
            <ShieldCheck className="w-5 h-5 text-primary" />
          </div>
          <div>
            <p className="font-bold text-foreground">Verify Phone Number</p>
            <p className="text-xs text-muted-foreground">Only verified leads can be listed for sale</p>
          </div>
        </div>

        {step === "phone" && (
          <>
            <label className="text-xs font-bold text-muted-foreground block mb-1.5">Phone Number</label>
            <div className="relative mb-3">
              <Phone className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
              <input
                value={phone}
                onChange={e => setPhone(e.target.value)}
                placeholder="+1 (555) 000-0000"
                type="tel"
                className="w-full h-11 pl-10 pr-4 rounded-xl border border-border bg-muted/40 text-sm text-foreground focus:outline-none focus:ring-1 focus:ring-ring"
              />
            </div>
            {error && <p className="text-xs text-destructive mb-3">{error}</p>}
            <Button onClick={sendCode} disabled={loading || !phone.trim()} className="w-full h-11">
              {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : "Send Verification Code"}
            </Button>
          </>
        )}

        {step === "code" && (
          <>
            <p className="text-sm text-muted-foreground mb-4">
              {isDemo
                ? "Demo mode: enter <strong>000000</strong> to verify"
                : `Enter the 6-digit code sent to ${phone}`}
            </p>
            {isDemo && (
              <div className="mb-3 px-3 py-2 bg-yellow-50 border border-yellow-200 rounded-xl text-xs text-yellow-700 font-semibold">
                📱 Demo mode active — use code <strong>000000</strong>. Add Twilio secrets to enable real SMS.
              </div>
            )}
            <input
              value={code}
              onChange={e => setCode(e.target.value.replace(/\D/g, "").slice(0, 6))}
              placeholder="000000"
              maxLength={6}
              className="w-full h-14 text-center text-2xl font-bold tracking-widest rounded-xl border border-border bg-muted/40 text-foreground focus:outline-none focus:ring-1 focus:ring-ring mb-3"
            />
            {error && <p className="text-xs text-destructive mb-3">{error}</p>}
            <Button onClick={checkCode} disabled={loading || code.length < 6} className="w-full h-11 mb-2">
              {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : "Verify Code"}
            </Button>
            <button onClick={() => { setStep("phone"); setCode(""); setError(""); }}
              className="w-full text-xs text-muted-foreground text-center hover:text-foreground">
              ← Change phone number
            </button>
          </>
        )}

        {step === "done" && (
          <div className="flex flex-col items-center gap-3 py-4">
            <CheckCircle className="w-12 h-12 text-green-500" />
            <p className="font-bold text-foreground">Phone Verified!</p>
            <p className="text-sm text-muted-foreground">This lead is now verified and can be listed for sale.</p>
          </div>
        )}
      </div>
    </div>
  );
}