import { useState } from "react";
import { Heart, Car, Building2, Shield, Stethoscope, Map } from "lucide-react";
import { Link } from "react-router-dom";
import InsuranceLeadTab from "./insurance/InsuranceLeadTab";
import PullToRefresh from "./PullToRefresh";

const TABS = [
  {
    id: "life",
    label: "Life",
    icon: Heart,
    color: { bg: "bg-red-50", icon: "text-red-500", tab: "text-red-600", activeBg: "bg-red-500" },
    description: "Find homeowners, families, and high-income residents aged 30–60 who need life insurance coverage.",
  },
  {
    id: "health",
    label: "Health",
    icon: Stethoscope,
    color: { bg: "bg-emerald-50", icon: "text-emerald-600", tab: "text-emerald-600", activeBg: "bg-emerald-500" },
    description: "Target self-employed workers, freelancers, and small biz owners without employer-sponsored health plans.",
  },
  {
    id: "auto",
    label: "Auto",
    icon: Car,
    color: { bg: "bg-blue-50", icon: "text-blue-600", tab: "text-blue-600", activeBg: "bg-blue-500" },
    description: "Find new movers, young drivers, multi-vehicle households, and luxury car owners in your area.",
  },
  {
    id: "business",
    label: "Business",
    icon: Building2,
    color: { bg: "bg-purple-50", icon: "text-purple-600", tab: "text-purple-600", activeBg: "bg-purple-500" },
    description: "Locate local businesses that need general liability, workers comp, or commercial auto insurance.",
  },
  {
    id: "pc",
    label: "P&C",
    icon: Shield,
    color: { bg: "bg-amber-50", icon: "text-amber-600", tab: "text-amber-600", activeBg: "bg-amber-500" },
    description: "Property & Casualty leads: homeowners, landlords, commercial properties, and recent buyers.",
  },
];

export default function OpportunityFinderTab() {
  const [activeTab, setActiveTab] = useState("life");
  const activeConfig = TABS.find(t => t.id === activeTab);

  return (
    <PullToRefresh onRefresh={() => {}}>
      <div className="min-h-screen bg-background">
        {/* Header */}
        <div className="px-5 pt-5 pb-3">
          <Link to="/" className="mb-4 flex items-center gap-2 p-3 bg-primary/10 rounded-xl hover:bg-primary/20 transition-colors">
            <Map className="w-4 h-4 text-primary" />
            <span className="text-sm font-semibold text-primary">Back to D2D Sales Map</span>
          </Link>
          <h1 className="text-xl font-bold text-foreground mb-0.5">Insurance Lead Finder</h1>
          <p className="text-sm text-muted-foreground">Cold call leads by insurance type — powered by AI + public data</p>
        </div>

        {/* Tab bar */}
        <div className="px-4 pb-3">
          <div className="flex gap-1.5 overflow-x-auto pb-1">
            {TABS.map(({ id, label, icon: Icon, color }) => (
              <button
                key={id}
                onClick={() => setActiveTab(id)}
                className={`flex-shrink-0 flex flex-col items-center gap-1 px-4 py-2.5 rounded-xl transition-all ${
                  activeTab === id
                    ? `${color.activeBg} text-white shadow-md`
                    : "bg-card border border-border text-muted-foreground hover:bg-muted"
                }`}
              >
                <Icon className="w-4 h-4" />
                <span className="text-xs font-bold">{label}</span>
              </button>
            ))}
          </div>
        </div>

        {/* Active tab content */}
        {activeConfig && (
          <InsuranceLeadTab
            key={activeTab}
            type={activeConfig.id}
            label={activeConfig.label}
            icon={activeConfig.icon}
            color={activeConfig.color}
            description={activeConfig.description}
          />
        )}
      </div>
    </PullToRefresh>
  );
}