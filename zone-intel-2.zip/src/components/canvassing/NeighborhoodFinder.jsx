import { useState } from "react";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  MapPin, Loader2, Sparkles, ChevronDown, ChevronUp, Home,
  DollarSign, Users, TrendingUp, Shield, Clock, Star, Building2
} from "lucide-react";

const TYPE_CONFIG = {
  homeowners:       { label: "Homeowners",       color: "bg-blue-50 text-blue-700 border-blue-200" },
  seniors:          { label: "Seniors",           color: "bg-purple-50 text-purple-700 border-purple-200" },
  families:         { label: "Families",          color: "bg-green-50 text-green-700 border-green-200" },
  high_income:      { label: "High Income",       color: "bg-amber-50 text-amber-700 border-amber-200" },
  new_construction: { label: "New Construction",  color: "bg-cyan-50 text-cyan-700 border-cyan-200" },
  renters:          { label: "Renters",           color: "bg-slate-100 text-slate-600 border-slate-200" },
};

function ScoreBar({ score }) {
  const pct = Math.round((score / 10) * 100);
  const color = score >= 8 ? "bg-green-500" : score >= 6 ? "bg-amber-400" : "bg-red-400";
  return (
    <div className="flex items-center gap-2">
      <div className="flex-1 h-1.5 bg-muted rounded-full overflow-hidden">
        <div className={`h-full rounded-full transition-all ${color}`} style={{ width: `${pct}%` }} />
      </div>
      <span className="text-xs font-bold w-5 text-right"
        style={{ color: score >= 8 ? "#22c55e" : score >= 6 ? "#f59e0b" : "#ef4444" }}>
        {score}
      </span>
    </div>
  );
}

function StatPill({ label, value, icon: Icon, color = "text-foreground" }) {
  if (!value && value !== 0) return null;
  return (
    <div className="bg-muted/60 rounded-lg p-2.5 flex flex-col gap-0.5">
      <div className="flex items-center gap-1">
        {Icon && <Icon className={`w-3 h-3 ${color}`} />}
        <p className="text-xs text-muted-foreground font-medium">{label}</p>
      </div>
      <p className={`text-xs font-bold ${color}`}>{value}</p>
    </div>
  );
}

export default function NeighborhoodFinder() {
  const [zip, setZip] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [loadingStage, setLoadingStage] = useState("");
  const [result, setResult] = useState(null);
  const [expandedId, setExpandedId] = useState(null);
  const [sortBy, setSortBy] = useState("score");
  const [filterType, setFilterType] = useState("all");

  const findNeighborhoods = async () => {
    if (!zip || zip.length < 5) return;
    setIsLoading(true);
    setResult(null);
    setExpandedId(null);

    setLoadingStage("Looking up ZIP code location...");
    await new Promise(r => setTimeout(r, 400));
    setLoadingStage("Fetching Census demographic data...");
    await new Promise(r => setTimeout(r, 600));
    setLoadingStage("Querying neighborhood boundaries...");

    const res = await base44.functions.invoke("neighborhoodIntel", { zip: zip.trim() });
    setLoadingStage("Scoring every neighborhood...");
    await new Promise(r => setTimeout(r, 300));

    setResult(res.data);
    setIsLoading(false);
    setLoadingStage("");
  };

  const typeColor = (t) => TYPE_CONFIG[t]?.color || "bg-slate-100 text-slate-600 border-slate-200";
  const typeLabel = (t) => TYPE_CONFIG[t]?.label || t;

  const neighborhoods = result?.neighborhoods || [];
  const filtered = neighborhoods
    .filter(n => filterType === "all" || n.primary_type === filterType)
    .sort((a, b) => {
      if (sortBy === "score") return (b.score || 0) - (a.score || 0);
      if (sortBy === "income") return (b.median_income || 0) - (a.median_income || 0);
      if (sortBy === "homes") return (b.estimated_homes || 0) - (a.estimated_homes || 0);
      if (sortBy === "ownership") return (b.ownership_rate || 0) - (a.ownership_rate || 0);
      return (b.score || 0) - (a.score || 0);
    });

  const overview = result?.area_overview;

  return (
    <div className="flex-1 overflow-y-auto">
      {/* Search bar */}
      <div className="px-4 pt-4 pb-3 bg-card border-b border-border sticky top-0 z-10">
        <div className="flex gap-2">
          <div className="relative flex-1">
            <MapPin className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <Input
              placeholder="Enter ZIP code (e.g. 48201)"
              value={zip}
              onChange={(e) => setZip(e.target.value.replace(/\D/g, "").slice(0, 5))}
              onKeyDown={(e) => e.key === "Enter" && findNeighborhoods()}
              className="pl-10 h-10 text-sm"
            />
          </div>
          <Button onClick={findNeighborhoods} disabled={isLoading || zip.length < 5} className="h-10 px-4 gap-1.5">
            {isLoading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Sparkles className="w-4 h-4" />}
            {isLoading ? "Loading..." : "Analyze"}
          </Button>
        </div>
      </div>

      {/* Loading state */}
      {isLoading && (
        <div className="flex flex-col items-center justify-center py-16 gap-4 px-6">
          <div className="w-14 h-14 rounded-2xl bg-primary/10 flex items-center justify-center">
            <Loader2 className="w-7 h-7 text-primary animate-spin" />
          </div>
          <div className="text-center">
            <p className="text-sm font-bold text-foreground mb-1">Analyzing ZIP {zip}</p>
            <p className="text-xs text-muted-foreground">{loadingStage}</p>
          </div>
          <div className="w-full max-w-xs space-y-2">
            {[
              "📡 OpenStreetMap neighborhood data",
              "📊 US Census Bureau demographics",
              "🏠 Home values & ownership rates",
              "🤖 AI canvassing scores",
            ].map((step, i) => (
              <div key={i} className="flex items-center gap-2">
                <div className="w-4 h-4 rounded-full bg-primary/20 flex items-center justify-center">
                  <div className="w-1.5 h-1.5 rounded-full bg-primary animate-pulse" />
                </div>
                <p className="text-xs text-muted-foreground">{step}</p>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Empty state */}
      {!isLoading && !result && (
        <div className="flex flex-col items-center justify-center py-16 px-6 text-center">
          <div className="w-16 h-16 rounded-2xl bg-primary/10 flex items-center justify-center mb-4">
            <Building2 className="w-8 h-8 text-primary" />
          </div>
          <h3 className="font-bold text-foreground text-base mb-2">Real Neighborhood Intelligence</h3>
          <p className="text-sm text-muted-foreground max-w-xs leading-relaxed">
            Enter a ZIP code to get <strong>every neighborhood</strong> with real Census demographics — income, ownership rates, home values, age, and canvassing scores.
          </p>
          <div className="mt-5 grid grid-cols-2 gap-2 w-full max-w-xs text-left">
            {[
              { icon: "📊", label: "Census demographics" },
              { icon: "🗺️", label: "OSM neighborhood names" },
              { icon: "🏠", label: "Home values & ownership" },
              { icon: "📍", label: "Every neighborhood listed" },
            ].map(({ icon, label }) => (
              <div key={label} className="flex items-center gap-2 bg-muted/50 rounded-lg px-3 py-2">
                <span className="text-base">{icon}</span>
                <p className="text-xs font-medium text-foreground">{label}</p>
              </div>
            ))}
          </div>
          <div className="mt-5 flex flex-wrap justify-center gap-2">
            {["48201", "90210", "78701", "30301"].map((s) => (
              <button key={s} onClick={() => setZip(s)}
                className="text-xs font-medium text-primary bg-primary/10 px-3 py-1.5 rounded-full hover:bg-primary/20 transition-colors">
                {s}
              </button>
            ))}
          </div>
        </div>
      )}

      {/* Results */}
      {!isLoading && result && (
        <div>
          {/* Area overview card */}
          <div className="mx-4 mt-4 mb-3 bg-card rounded-xl border border-border p-4">
            <div className="flex items-start justify-between mb-2">
              <div>
                <p className="text-xs font-bold text-muted-foreground uppercase tracking-wider mb-0.5">ZIP {result.zip}</p>
                <p className="font-bold text-foreground text-sm">{result.city}</p>
              </div>
              <div className="text-right">
                <p className="text-2xl font-black text-primary">{neighborhoods.length}</p>
                <p className="text-xs text-muted-foreground">neighborhoods</p>
              </div>
            </div>
            {result.city_summary && (
              <p className="text-xs text-muted-foreground leading-relaxed mb-3">{result.city_summary}</p>
            )}
            {overview && (
              <div className="grid grid-cols-2 gap-2">
                {overview.median_income > 0 && (
                  <StatPill label="Median Income" value={`$${overview.median_income?.toLocaleString()}`} icon={DollarSign} color="text-green-600" />
                )}
                {overview.avg_home_value > 0 && (
                  <StatPill label="Avg Home Value" value={`$${overview.avg_home_value?.toLocaleString()}`} icon={Home} color="text-blue-600" />
                )}
                {overview.avg_ownership_rate > 0 && (
                  <StatPill label="Ownership Rate" value={`${overview.avg_ownership_rate}%`} icon={Star} color="text-amber-600" />
                )}
                {overview.total_households > 0 && (
                  <StatPill label="Total Households" value={overview.total_households?.toLocaleString()} icon={Users} color="text-purple-600" />
                )}
              </div>
            )}
            {overview?.best_products?.length > 0 && (
              <div className="mt-3">
                <p className="text-xs font-bold text-muted-foreground mb-1.5">Best Products for This Area</p>
                <div className="flex flex-wrap gap-1.5">
                  {overview.best_products.map((p, i) => (
                    <span key={i} className="text-xs font-semibold bg-primary/10 text-primary px-2.5 py-1 rounded-full">{p}</span>
                  ))}
                </div>
              </div>
            )}
            {/* Data sources badge */}
            <div className="mt-3 flex gap-1.5 flex-wrap">
              <span className="text-xs bg-green-100 text-green-700 px-2 py-0.5 rounded-full font-medium">
                📊 {result.tract_count} Census tracts
              </span>
              <span className="text-xs bg-blue-100 text-blue-700 px-2 py-0.5 rounded-full font-medium">
                🗺️ {result.osm_count} OSM areas
              </span>
              <span className="text-xs bg-purple-100 text-purple-700 px-2 py-0.5 rounded-full font-medium">
                🏛️ US Census ACS 2022
              </span>
            </div>
          </div>

          {/* Sort + filter controls */}
          <div className="px-4 mb-3 space-y-2">
            {/* Filter by type */}
            <div className="flex gap-1.5 overflow-x-auto pb-0.5">
              {[{ id: "all", label: "All" }, ...Object.entries(TYPE_CONFIG).map(([id, { label }]) => ({ id, label }))].map(({ id, label }) => (
                <button key={id} onClick={() => setFilterType(id)}
                  className={`flex-shrink-0 text-xs font-semibold px-3 py-1.5 rounded-full transition-colors ${
                    filterType === id ? "bg-primary text-white" : "bg-muted text-muted-foreground"
                  }`}>
                  {label}
                </button>
              ))}
            </div>
            {/* Sort */}
            <div className="flex items-center gap-2">
              <p className="text-xs text-muted-foreground font-medium flex-shrink-0">Sort by:</p>
              <div className="flex gap-1.5 overflow-x-auto">
                {[
                  { id: "score", label: "Score" },
                  { id: "income", label: "Income" },
                  { id: "ownership", label: "Ownership" },
                  { id: "homes", label: "Homes" },
                ].map(({ id, label }) => (
                  <button key={id} onClick={() => setSortBy(id)}
                    className={`flex-shrink-0 text-xs font-semibold px-3 py-1.5 rounded-full border transition-colors ${
                      sortBy === id ? "bg-foreground text-background border-foreground" : "border-border text-muted-foreground bg-card"
                    }`}>
                    {label}
                  </button>
                ))}
              </div>
            </div>
            <p className="text-xs text-muted-foreground font-medium">
              {filtered.length} of {neighborhoods.length} neighborhoods
            </p>
          </div>

          {/* Neighborhood list */}
          <div className="px-4 pb-6 space-y-2.5">
            {filtered.map((n, i) => {
              const isOpen = expandedId === i;
              const globalRank = neighborhoods.indexOf(n);
              return (
                <div key={i} className="bg-card rounded-xl border border-border overflow-hidden shadow-sm">
                  <button
                    className="w-full text-left p-3.5 flex items-start gap-3"
                    onClick={() => setExpandedId(isOpen ? null : i)}
                  >
                    {/* Rank badge */}
                    <div className={`w-8 h-8 rounded-lg flex items-center justify-center flex-shrink-0 font-black text-xs ${
                      globalRank === 0 ? "bg-amber-100 text-amber-700" :
                      globalRank <= 2 ? "bg-primary/10 text-primary" :
                      "bg-muted text-muted-foreground"
                    }`}>
                      {globalRank === 0 ? "⭐" : `#${globalRank + 1}`}
                    </div>

                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 mb-1 flex-wrap">
                        <p className="font-bold text-foreground text-sm">{n.name}</p>
                        <span className={`text-xs font-bold px-2 py-0.5 rounded-full border ${typeColor(n.primary_type)}`}>
                          {typeLabel(n.primary_type)}
                        </span>
                      </div>
                      <ScoreBar score={n.score} />
                      <div className="flex items-center gap-3 mt-1.5">
                        {n.median_income > 0 && (
                          <span className="text-xs text-muted-foreground">
                            💰 ${Math.round(n.median_income / 1000)}k
                          </span>
                        )}
                        {n.ownership_rate > 0 && (
                          <span className="text-xs text-muted-foreground">
                            🏠 {n.ownership_rate}% owned
                          </span>
                        )}
                        {n.median_age > 0 && (
                          <span className="text-xs text-muted-foreground">
                            👤 Avg {n.median_age}y
                          </span>
                        )}
                      </div>
                    </div>
                    {isOpen ? <ChevronUp className="w-4 h-4 text-muted-foreground flex-shrink-0 mt-1" /> : <ChevronDown className="w-4 h-4 text-muted-foreground flex-shrink-0 mt-1" />}
                  </button>

                  {isOpen && (
                    <div className="px-3.5 pb-4 border-t border-border pt-3 space-y-3">
                      {n.why_good && (
                        <p className="text-xs text-foreground leading-relaxed">{n.why_good}</p>
                      )}

                      {/* Real demographic grid */}
                      <div className="grid grid-cols-3 gap-2">
                        {n.median_income > 0 && (
                          <StatPill label="Med. Income" value={`$${Math.round(n.median_income / 1000)}k`} icon={DollarSign} color="text-green-600" />
                        )}
                        {n.median_home_value > 0 && (
                          <StatPill label="Home Value" value={n.home_value_range || `$${Math.round(n.median_home_value / 1000)}k`} icon={Home} color="text-blue-600" />
                        )}
                        {n.ownership_rate > 0 && (
                          <StatPill label="Ownership" value={`${n.ownership_rate}%`} icon={TrendingUp} color="text-amber-600" />
                        )}
                        {n.population > 0 && (
                          <StatPill label="Population" value={n.population?.toLocaleString()} icon={Users} color="text-purple-600" />
                        )}
                        {n.median_age > 0 && (
                          <StatPill label="Median Age" value={`${n.median_age} yrs`} icon={Users} color="text-foreground" />
                        )}
                        {n.poverty_rate > 0 && (
                          <StatPill label="Poverty Rate" value={`${n.poverty_rate}%`} icon={Shield} color={n.poverty_rate > 20 ? "text-red-500" : "text-muted-foreground"} />
                        )}
                        {n.estimated_homes > 0 && (
                          <StatPill label="Est. Homes" value={n.estimated_homes?.toLocaleString()} icon={Home} color="text-foreground" />
                        )}
                        {n.best_time && (
                          <div className="col-span-2 bg-muted/60 rounded-lg p-2.5">
                            <div className="flex items-center gap-1 mb-0.5">
                              <Clock className="w-3 h-3 text-muted-foreground" />
                              <p className="text-xs text-muted-foreground font-medium">Best Time</p>
                            </div>
                            <p className="text-xs font-bold text-foreground">{n.best_time}</p>
                          </div>
                        )}
                      </div>

                      {n.best_products?.length > 0 && (
                        <div>
                          <p className="text-xs font-bold text-muted-foreground mb-1.5">Best Products</p>
                          <div className="flex flex-wrap gap-1.5">
                            {n.best_products.map((p, pi) => (
                              <span key={pi} className="text-xs font-semibold bg-primary/10 text-primary px-2.5 py-1 rounded-full">{p}</span>
                            ))}
                          </div>
                        </div>
                      )}

                      {n.safety_note && (
                        <div className="bg-amber-50 border border-amber-200 rounded-lg p-2.5">
                          <p className="text-xs font-bold text-amber-700 mb-0.5">⚠️ Area Note</p>
                          <p className="text-xs text-amber-700">{n.safety_note}</p>
                        </div>
                      )}

                      {n.tips?.length > 0 && (
                        <div>
                          <p className="text-xs font-bold text-muted-foreground mb-1.5">Canvassing Tips</p>
                          <div className="space-y-1">
                            {n.tips.map((tip, ti) => (
                              <p key={ti} className="text-xs text-foreground flex gap-2">
                                <span className="text-primary font-bold flex-shrink-0">→</span> {tip}
                              </p>
                            ))}
                          </div>
                        </div>
                      )}

                      {n.data_source && (
                        <p className="text-xs text-muted-foreground/60">Source: {n.data_source}</p>
                      )}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
}