import { useState } from "react";
import { base44 } from "@/api/base44Client";
import { Sparkles, Copy, Check, ChevronDown, ChevronUp, Loader2, Zap } from "lucide-react";

const FOLLOW_UP_PROMPTS = {
  knocked: "knocked but no answer",
  interested: "showed interest but hasn't committed",
  follow_up: "requested a follow-up",
  appointment_set: "has an appointment scheduled",
  no_answer: "didn't answer after multiple attempts",
  not_interested: "initially said not interested",
  sold: "recently converted to a sale",
  not_visited: "hasn't been contacted yet",
};

export default function AIProspectPanel({ lead }) {
  const [open, setOpen] = useState(false);
  const [outreach, setOutreach] = useState(null);
  const [followUps, setFollowUps] = useState(null);
  const [loadingOutreach, setLoadingOutreach] = useState(false);
  const [loadingFollowUps, setLoadingFollowUps] = useState(false);
  const [copied, setCopied] = useState(false);

  const generateOutreach = async () => {
    setLoadingOutreach(true);
    setOutreach(null);
    const res = await base44.integrations.Core.InvokeLLM({
      prompt: `Write a short, personalized door-to-door or cold call outreach message for this prospect:
Name: ${lead.owner_name || "Homeowner"}
Address: ${lead.address}
${lead.is_homeowner ? "Status: Homeowner" : ""}
${lead.home_value ? `Est. Home Value: $${lead.home_value.toLocaleString()}` : ""}
${lead.notes ? `Agent Notes: ${lead.notes}` : ""}
${lead.status ? `Current Status: ${FOLLOW_UP_PROMPTS[lead.status] || lead.status}` : ""}

Write a warm, professional 2-3 sentence message. Make it conversational, reference their home/situation, and include a clear value proposition. Do NOT be pushy. Return ONLY the message text.`,
      response_json_schema: {
        type: "object",
        properties: { message: { type: "string" } },
      },
    });
    setOutreach(res?.message || null);
    setLoadingOutreach(false);
  };

  const generateFollowUps = async () => {
    setLoadingFollowUps(true);
    setFollowUps(null);
    const res = await base44.integrations.Core.InvokeLLM({
      prompt: `Suggest 3-4 specific follow-up actions for a door-to-door sales rep with this prospect:
Name: ${lead.owner_name || "Homeowner"}
Address: ${lead.address}
Current Status: ${FOLLOW_UP_PROMPTS[lead.status] || lead.status || "unknown"}
Visit Count: ${lead.visit_count || 0}
${lead.notes ? `Notes: ${lead.notes}` : ""}
${lead.follow_up_date ? `Scheduled Follow-up: ${new Date(lead.follow_up_date).toLocaleDateString()}` : ""}

Return actionable, specific suggestions tailored to their current status. Each action should be brief (1 sentence) and practical.`,
      response_json_schema: {
        type: "object",
        properties: {
          actions: {
            type: "array",
            items: {
              type: "object",
              properties: {
                action: { type: "string" },
                priority: { type: "string", enum: ["high", "medium", "low"] },
                timing: { type: "string" },
              },
            },
          },
        },
      },
    });
    setFollowUps(res?.actions || []);
    setLoadingFollowUps(false);
  };

  const copyOutreach = () => {
    navigator.clipboard.writeText(outreach);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="border-t border-border">
      <button
        onClick={() => setOpen(v => !v)}
        className="w-full flex items-center gap-2 px-5 py-3 hover:bg-muted/30 transition-colors"
      >
        <div className="w-6 h-6 rounded-lg bg-gradient-to-br from-purple-500 to-blue-500 flex items-center justify-center flex-shrink-0">
          <Sparkles className="w-3.5 h-3.5 text-white" />
        </div>
        <span className="text-sm font-bold text-foreground flex-1 text-left">AI Prospect Tools</span>
        {open ? <ChevronUp className="w-4 h-4 text-muted-foreground" /> : <ChevronDown className="w-4 h-4 text-muted-foreground" />}
      </button>

      {open && (
        <div className="px-5 pb-5 space-y-4">

          {/* Personalized Outreach */}
          <div className="bg-muted/30 rounded-xl p-4 space-y-3">
            <div className="flex items-center justify-between">
              <p className="text-xs font-bold text-foreground uppercase tracking-wider">Personalized Outreach</p>
              <button
                onClick={generateOutreach}
                disabled={loadingOutreach}
                className="flex items-center gap-1.5 text-xs font-bold text-white bg-gradient-to-r from-purple-500 to-blue-500 px-3 py-1.5 rounded-lg hover:opacity-90 disabled:opacity-60 transition-opacity"
              >
                {loadingOutreach ? <Loader2 className="w-3 h-3 animate-spin" /> : <Sparkles className="w-3 h-3" />}
                {outreach ? "Regenerate" : "Generate"}
              </button>
            </div>

            {loadingOutreach && (
              <div className="flex items-center gap-2 py-2">
                <Loader2 className="w-4 h-4 animate-spin text-purple-500" />
                <p className="text-xs text-muted-foreground">Crafting personalized message...</p>
              </div>
            )}

            {outreach && !loadingOutreach && (
              <div className="bg-card border border-border rounded-xl p-3">
                <p className="text-sm text-foreground leading-relaxed italic">"{outreach}"</p>
                <button
                  onClick={copyOutreach}
                  className="mt-2 flex items-center gap-1.5 text-xs font-semibold text-primary hover:text-primary/80 transition-colors"
                >
                  {copied ? <><Check className="w-3.5 h-3.5 text-green-500" /><span className="text-green-600">Copied!</span></> : <><Copy className="w-3.5 h-3.5" /> Copy Message</>}
                </button>
              </div>
            )}

            {!outreach && !loadingOutreach && (
              <p className="text-xs text-muted-foreground leading-relaxed">
                Generate a tailored message based on this lead's profile, home value, and current status.
              </p>
            )}
          </div>

          {/* Follow-up Suggestions */}
          <div className="bg-muted/30 rounded-xl p-4 space-y-3">
            <div className="flex items-center justify-between">
              <p className="text-xs font-bold text-foreground uppercase tracking-wider">Follow-up Actions</p>
              <button
                onClick={generateFollowUps}
                disabled={loadingFollowUps}
                className="flex items-center gap-1.5 text-xs font-bold text-white bg-gradient-to-r from-amber-500 to-orange-500 px-3 py-1.5 rounded-lg hover:opacity-90 disabled:opacity-60 transition-opacity"
              >
                {loadingFollowUps ? <Loader2 className="w-3 h-3 animate-spin" /> : <Zap className="w-3 h-3" />}
                {followUps ? "Refresh" : "Suggest"}
              </button>
            </div>

            {loadingFollowUps && (
              <div className="flex items-center gap-2 py-2">
                <Loader2 className="w-4 h-4 animate-spin text-amber-500" />
                <p className="text-xs text-muted-foreground">Analyzing prospect situation...</p>
              </div>
            )}

            {followUps && !loadingFollowUps && (
              <div className="space-y-2">
                {followUps.map((item, i) => (
                  <div key={i} className="flex items-start gap-2.5 bg-card border border-border rounded-xl p-3">
                    <span className={`flex-shrink-0 text-xs font-black px-1.5 py-0.5 rounded-full mt-0.5 ${
                      item.priority === "high" ? "bg-red-100 text-red-600" :
                      item.priority === "medium" ? "bg-amber-100 text-amber-600" :
                      "bg-slate-100 text-slate-500"
                    }`}>{item.priority?.toUpperCase() || "—"}</span>
                    <div className="flex-1 min-w-0">
                      <p className="text-xs text-foreground leading-relaxed">{item.action}</p>
                      {item.timing && <p className="text-xs text-muted-foreground mt-0.5">⏱ {item.timing}</p>}
                    </div>
                  </div>
                ))}
              </div>
            )}

            {!followUps && !loadingFollowUps && (
              <p className="text-xs text-muted-foreground leading-relaxed">
                Get AI-recommended next steps based on visit history and current status.
              </p>
            )}
          </div>
        </div>
      )}
    </div>
  );
}