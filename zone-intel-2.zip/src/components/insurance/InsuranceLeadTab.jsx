import { useState } from "react";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { MapPin, Loader2, Search } from "lucide-react";
import LeadCard from "./LeadCard";

// Tab-specific prompts for each insurance type
const TAB_PROMPTS = {
  life: (location) => `You are an exhaustive insurance lead researcher. Search EVERY public data source simultaneously for life insurance prospects in "${location}":
- WhitePages.com, TruePeopleSearch.com, FastPeopleSearch.com, Spokeo.com, BeenVerified.com, Intelius.com, PeopleFinder.com, ZabaSearch.com, AnyWho.com, USPhoneBook.com, 411.com, Radaris.com
- Public property records and county assessor databases
- Facebook, LinkedIn, local community groups
- Local news obituaries and birth announcements (new parents = life insurance need)
- Church/community directories
- Local business listings for self-employed people with families

Target profiles: homeowners aged 28-65, married couples, parents with children under 18, self-employed workers, high-income earners, recent home buyers, new parents.

Return EVERY person you can find. Aim for 50+ unique individuals. For each: full name, publicly listed phone, full address, age/age range if available, homeowner status, family status, reason they're a strong life insurance prospect, and priority (High/Medium/Low).`,

  health: (location) => `You are an exhaustive insurance lead researcher. Find EVERY possible health insurance prospect in "${location}" by searching all public sources simultaneously:
- Yelp, Google Maps, Facebook Business, Nextdoor, local Chambers of Commerce
- State business registry / Secretary of State filings for sole proprietors, LLCs, partnerships
- LinkedIn for freelancers, consultants, contractors, gig workers
- Craigslist gig section, TaskRabbit, local contractor directories
- Thumbtack, Angi, HomeAdvisor — find every local contractor/freelancer
- Etsy shops, local artist studios, personal trainers, tutors, dog walkers — all self-employed
- Recently laid-off workers (check LinkedIn)
- WhitePages for residents who appear to be self-employed or in gig work

Health insurance need is highest for: self-employed, freelancers, gig workers, part-time workers, small biz owners with < 5 employees, recent college grads, early retirees under 65.

Return 50+ leads with name, phone, occupation/business, address, and specific health insurance gap. Include both individuals AND small businesses.`,

  auto: (location) => `You are an exhaustive insurance lead researcher. Find EVERY auto insurance prospect in "${location}" by searching:
- WhitePages, TruePeopleSearch, FastPeopleSearch — every resident household
- Craigslist auto section for recent car buyers
- Zillow/Redfin/Realtor.com for recent home buyers (they just moved = new auto policy needed)
- Facebook Marketplace — people buying/selling cars
- Local dealership reviews — people who just bought a car
- New resident lists — people who just moved in (USPS change of address)
- Apartment complexes and new housing developments (young renters who drive)
- College campuses nearby — young drivers
- High-income neighborhoods — multi-car households, luxury vehicles, classic cars
- Senior communities — insurance review opportunities

Return 50+ leads. For each: name, phone, address, vehicle type/situation if determinable (new car, multiple cars, luxury, young driver), and why they need auto insurance now. Prioritize leads who recently moved, bought a car, or are young drivers.`,

  business: (location) => `You are an exhaustive commercial insurance lead researcher. Find EVERY business in "${location}" that needs insurance by searching:
- Google Maps: search for contractors, restaurants, bars, retail shops, salons, auto repair, construction, medical offices, childcare centers, gyms, daycares, cleaning services, landscapers, electricians, plumbers, HVAC companies, roofers, painters, movers, delivery services
- Yelp, Facebook Business Pages, Yellow Pages, Manta, Thumbtack, Angi, HomeAdvisor
- State Secretary of State business registry — ALL active LLCs and corporations
- Local Chamber of Commerce member directories
- BBB (Better Business Bureau) listings
- NAICS/SIC code lookup for all businesses in the area
- LinkedIn Companies filter by location
- Craigslist services section — local businesses advertising

Return 50+ businesses. Each needs: business name, owner name if findable, phone, address, number of employees (estimate), industry/type, specific insurance products they need (general liability, workers comp, commercial auto, professional liability, BOP, umbrella), and a cold call reason. Prioritize businesses with employees, physical locations, vehicles, and high-liability industries.`,

  pc: (location) => `You are an exhaustive Property & Casualty insurance lead researcher. Find EVERY P&C lead in "${location}" by searching:
- Zillow, Redfin, Realtor.com, Trulia — ALL recent home sales (last 6 months) = new buyers need new policies
- County assessor / tax records for all residential and commercial properties
- FSBO (For Sale By Owner) listings — sellers who will need new coverage at destination
- New construction permits filed with the city/county
- Apartment-to-condo conversions — new owners
- Rental property listings on Airbnb, VRBO, Zillow — landlords need landlord insurance
- Older homes (30+ years) — need policy review, often underinsured
- High-value neighborhoods — expensive homes often have gaps in coverage
- Commercial properties: strip malls, office buildings, warehouses, industrial
- WhitePages for all homeowners in the ZIP
- HOA directories for condo/townhome owners
- Flood zone maps — properties in flood zones need separate flood insurance

Return 50+ P&C leads. Each needs: name, phone, property address, property type (single-family, rental, commercial, condo), estimated value, specific P&C opportunity (new buyer, rental property, underinsured, flood zone, commercial), and priority.`,
};

const LEAD_SCHEMA = {
  type: "object",
  properties: {
    leads: {
      type: "array",
      items: {
        type: "object",
        properties: {
          name: { type: "string" },
          phone: { type: "string" },
          address: { type: "string" },
          business_type: { type: "string" },
          priority: { type: "string", enum: ["High", "Medium", "Low"] },
          why: { type: "string" },
          profile: { type: "string" },
        },
      },
    },
    area_insight: { type: "string" },
    total_found: { type: "number" },
  },
};

const SAMPLE_ZIPS = ["48201", "77001", "90210", "30301", "60614"];

export default function InsuranceLeadTab({ type, label, icon: Icon, color, description }) {
  const [location, setLocation] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [result, setResult] = useState(null);
  const [searched, setSearched] = useState(false);

  const search = async () => {
    if (!location.trim()) return;
    setIsLoading(true);
    setResult(null);
    setSearched(false);

    const res = await base44.integrations.Core.InvokeLLM({
      prompt: TAB_PROMPTS[type](location),
      add_context_from_internet: true,
      model: "gemini_3_1_pro",
      response_json_schema: LEAD_SCHEMA,
    });

    setResult(res);
    setSearched(true);
    setIsLoading(false);
  };

  const leads = result?.leads || [];

  return (
    <div className="flex-1 overflow-y-auto pb-8">
      {/* Header */}
      <div className="px-5 pt-5 pb-4">
        <div className={`w-12 h-12 rounded-2xl flex items-center justify-center mb-3 ${color.bg}`}>
          <Icon className={`w-6 h-6 ${color.icon}`} />
        </div>
        <h2 className="text-base font-bold text-foreground">{label} Leads</h2>
        <p className="text-xs text-muted-foreground mt-0.5">{description}</p>
      </div>

      {/* Compliance notice */}
      <div className="mx-5 mb-4 p-3 bg-green-50 border border-green-200 rounded-xl">
        <p className="text-xs text-green-700 leading-relaxed font-medium">
          ✅ Uses publicly available data only. Always check DNC registry before calling. Comply with TCPA and applicable state telemarketing laws.
        </p>
      </div>

      {/* Search bar */}
      <div className="px-5 mb-4">
        <div className="flex gap-2">
          <div className="relative flex-1">
            <MapPin className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <Input
              placeholder="City, state or ZIP code"
              value={location}
              onChange={(e) => setLocation(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && search()}
              className="pl-10 h-11 rounded-xl text-sm"
            />
          </div>
          <Button onClick={search} disabled={isLoading || !location.trim()} className="h-11 px-5 rounded-xl">
            {isLoading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Search className="w-4 h-4" />}
          </Button>
        </div>
        {!searched && (
          <div className="flex flex-wrap gap-1.5 mt-2">
            {SAMPLE_ZIPS.map((z) => (
              <button key={z} onClick={() => setLocation(z)}
                className="text-xs font-medium text-primary bg-primary/10 px-2.5 py-1 rounded-full hover:bg-primary/20 transition-colors">
                {z}
              </button>
            ))}
          </div>
        )}
      </div>

      {/* Loading */}
      {isLoading && (
        <div className="mx-5 bg-card rounded-xl border border-border p-8 flex flex-col items-center gap-3">
          <Loader2 className="w-7 h-7 text-primary animate-spin" />
          <p className="text-sm font-semibold text-foreground">Finding every {label} lead in {location}...</p>
          <p className="text-xs text-muted-foreground text-center">Searching 15+ public sources — WhitePages, county records, Yelp, state registries &amp; more</p>
        </div>
      )}

      {/* Results */}
      {!isLoading && searched && leads.length === 0 && (
        <div className="mx-5 text-center py-10">
          <p className="font-semibold text-foreground">No leads found</p>
          <p className="text-sm text-muted-foreground mt-1">Try a different location or ZIP code.</p>
        </div>
      )}

      {!isLoading && leads.length > 0 && (
        <div className="px-5 space-y-3">
          {result?.area_insight && (
            <div className={`p-3 rounded-xl border ${color.bg.replace("50", "50")} border-opacity-50`} style={{ borderColor: "transparent" }}>
              <div className={`p-3 rounded-xl bg-muted/40 border border-border`}>
                <p className="text-xs font-bold text-foreground mb-0.5">📊 Area Insight</p>
                <p className="text-xs text-muted-foreground leading-relaxed">{result.area_insight}</p>
              </div>
            </div>
          )}
          <div className="flex items-center justify-between">
            <p className="text-xs font-bold text-muted-foreground">{leads.length} LEADS FOUND — {location.toUpperCase()}</p>
            <p className="text-xs text-muted-foreground">Tap a card for AI cold call script</p>
          </div>
          {leads.map((lead, i) => (
            <LeadCard key={i} lead={lead} insuranceType={label} />
          ))}
        </div>
      )}

      {/* Empty state */}
      {!isLoading && !searched && (
        <div className="mx-5 bg-card rounded-xl border border-border p-8 flex flex-col items-center text-center">
          <div className={`w-14 h-14 rounded-2xl ${color.bg} flex items-center justify-center mb-4`}>
            <Icon className={`w-7 h-7 ${color.icon}`} />
          </div>
          <h3 className="font-semibold text-foreground mb-2">Find {label} Leads</h3>
          <p className="text-sm text-muted-foreground max-w-xs leading-relaxed">{description}</p>
        </div>
      )}
    </div>
  );
}