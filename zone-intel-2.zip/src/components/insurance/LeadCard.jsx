import { Phone, MapPin, User, Copy, Check, Sparkles, ChevronDown, ChevronUp, Lock, Unlock, Loader2, ShoppingCart } from "lucide-react";
import { useState } from "react";
import { base44 } from "@/api/base44Client";

// Persist purchased phones across the session
const getPurchased = () => { try { return JSON.parse(localStorage.getItem("unlocked_leads") || "[]"); } catch { return []; } };
const addPurchased = (phone) => { const p = getPurchased(); if (!p.includes(phone)) localStorage.setItem("unlocked_leads", JSON.stringify([...p, phone])); };

export default function LeadCard({ lead, insuranceType }) {
  const [expanded, setExpanded] = useState(false);
  const [outreach, setOutreach] = useState("");
  const [loadingOutreach, setLoadingOutreach] = useState(false);
  const [copied, setCopied] = useState(false);
  const [buying, setBuying] = useState(false);
  const [unlocked, setUnlocked] = useState(() => lead.phone && getPurchased().includes(lead.phone));

  const generateScript = async () => {
    setLoadingOutreach(true);
    const res = await base44.integrations.Core.InvokeLLM({
      prompt: `Write a BRIEF cold call opening for an insurance salesperson. Lead info: Name: ${lead.name}, ${lead.address ? `Address: ${lead.address},` : ""} ${lead.business_type || lead.profile || ""}. Insurance type: ${insuranceType}. Write 2-3 sentences MAX. Sound natural, not salesy. Start with a greeting.`,
      response_json_schema: { type: "object", properties: { script: { type: "string" } } },
    });
    setOutreach(res?.script || "");
    setLoadingOutreach(false);
  };

  const copy = () => {
    navigator.clipboard.writeText(outreach);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleUnlock = async () => {
    if (window.self !== window.top) { alert("Checkout only works from the published app."); return; }
    setBuying(true);
    const user = await base44.auth.me();
    // Create the lead in DB as a $1 marketplace listing
    const created = await base44.entities.Lead.create({
      owner_name: lead.name || "Unknown",
      phone: lead.phone || "",
      address: lead.address || "",
      category: "life_insurance",
      status: "not_visited",
      is_for_sale: true,
      price: 1,
      seller_id: user?.id || "",
      assigned_rep: user?.email || "",
      listing_description: lead.why || lead.profile || "",
      tags: ["cold_call", insuranceType?.toLowerCase() || ""],
    });
    const base = window.location.origin + "/marketplace";
    const res = await base44.functions.invoke("buyLead", {
      leadId: created.id,
      successUrl: `${base}?purchased=true&lead_id=${created.id}`,
      cancelUrl: base,
    });
    if (res.data?.url) {
      if (lead.phone) addPurchased(lead.phone);
      window.location.href = res.data.url;
    } else {
      alert(res.data?.error || "Checkout failed");
      setBuying(false);
    }
  };

  // Mask name — show only the first 3 chars as a teaser
  const maskedName = lead.name
    ? lead.name.slice(0, 3) + "*".repeat(Math.max(0, lead.name.length - 3))
    : "Unknown";
  const maskedPhone = lead.phone
    ? "(***) ***-" + lead.phone.replace(/\D/g, "").slice(-4)
    : null;

  return (
    <div className={`bg-card rounded-xl border overflow-hidden shadow-sm transition-all ${
      unlocked ? "border-emerald-300 ring-1 ring-emerald-200" : "border-border"
    }`}>
      <div className="p-4">
        <div className="flex items-start justify-between gap-3">
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2 mb-1">
              <p className="font-bold text-foreground text-sm truncate">
                {unlocked ? lead.name : maskedName}
              </p>
              {lead.priority && (
                <span className={`text-xs font-bold px-2 py-0.5 rounded-full border flex-shrink-0 ${
                  lead.priority === "High" ? "bg-green-50 text-green-700 border-green-200" :
                  lead.priority === "Medium" ? "bg-amber-50 text-amber-700 border-amber-200" :
                  "bg-slate-100 text-slate-500 border-slate-200"
                }`}>{lead.priority}</span>
              )}
            </div>
            {lead.address && (
              <p className="text-xs text-muted-foreground flex items-center gap-1 mb-0.5">
                <MapPin className="w-3 h-3 flex-shrink-0" /> {lead.address}
              </p>
            )}
            {!unlocked && (
              <p className="text-xs text-muted-foreground flex items-center gap-1 mt-1">
                <Lock className="w-3 h-3 flex-shrink-0 text-amber-500" />
                <span className="text-amber-600 font-medium">Unlock full name + phone for $1</span>
              </p>
            )}
            {lead.business_type && (
              <p className="text-xs text-muted-foreground flex items-center gap-1">
                <User className="w-3 h-3 flex-shrink-0" /> {lead.business_type}
              </p>
            )}
          </div>
          {unlocked ? (
            lead.phone ? (
              <a href={`tel:${lead.phone}`}
                className="flex items-center gap-1.5 text-xs font-bold text-white bg-emerald-500 px-3 py-2 rounded-xl hover:bg-emerald-600 flex-shrink-0">
                <Phone className="w-3.5 h-3.5" /> {lead.phone}
              </a>
            ) : (
              <span className="text-xs text-muted-foreground flex-shrink-0">No phone</span>
            )
          ) : (
            <div className="flex flex-col items-end gap-1.5 flex-shrink-0">
              {maskedPhone && (
                <span className="text-xs font-mono text-muted-foreground bg-muted px-2 py-1 rounded-lg blur-[3px] select-none">
                  {maskedPhone}
                </span>
              )}
              <button onClick={handleUnlock} disabled={buying}
                className="flex items-center gap-1.5 text-xs font-bold text-white bg-amber-500 px-3 py-2 rounded-xl hover:bg-amber-600 active:scale-95 transition-all flex-shrink-0">
                {buying ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <ShoppingCart className="w-3.5 h-3.5" />}
                $1 Unlock
              </button>
            </div>
          )}
        </div>

        {lead.why && (
          <p className="text-xs text-muted-foreground mt-2 leading-relaxed italic">"{lead.why}"</p>
        )}
      </div>

      {/* Script section */}
      <div className="border-t border-border px-4 py-2.5">
        <button onClick={() => { setExpanded(!expanded); if (!expanded && !outreach) generateScript(); }}
          className="w-full flex items-center justify-between">
          <div className="flex items-center gap-1.5">
            <Sparkles className="w-3.5 h-3.5 text-purple-500" />
            <span className="text-xs font-bold text-purple-600">AI Cold Call Script</span>
          </div>
          {expanded ? <ChevronUp className="w-3.5 h-3.5 text-muted-foreground" /> : <ChevronDown className="w-3.5 h-3.5 text-muted-foreground" />}
        </button>

        {expanded && (
          <div className="mt-2.5">
            {loadingOutreach ? (
              <p className="text-xs text-muted-foreground animate-pulse">Generating script...</p>
            ) : outreach ? (
              <div className="bg-purple-50 border border-purple-100 rounded-lg p-3">
                <p className="text-xs text-foreground leading-relaxed">"{outreach}"</p>
                <div className="flex items-center justify-between mt-2">
                  <button onClick={copy} className="flex items-center gap-1 text-xs text-purple-600 font-semibold">
                    {copied ? <><Check className="w-3 h-3 text-green-500" /> Copied</> : <><Copy className="w-3 h-3" /> Copy</>}
                  </button>
                  <button onClick={generateScript} className="text-xs text-purple-600 font-semibold">Regenerate</button>
                </div>
              </div>
            ) : null}
          </div>
        )}
      </div>
    </div>
  );
}