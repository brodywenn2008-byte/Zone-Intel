import { Toaster } from "@/components/ui/toaster"
import { QueryClientProvider } from '@tanstack/react-query'
import { queryClientInstance } from '@/lib/query-client'
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import PageNotFound from './lib/PageNotFound';
import { AuthProvider, useAuth } from '@/lib/AuthContext';
import UserNotRegisteredError from '@/components/UserNotRegisteredError';
// Add page imports here
import ValueMapTab from './components/ValueMapTab';
import OpportunityFinderTab from './components/OpportunityFinderTab';
import Settings from './pages/Settings';
import AppLayout from './components/AppLayout';
import CanvassingApp from './pages/CanvassingApp';
import PeopleMet from './pages/PeopleMet';
import CRMDashboard from './pages/CRMDashboard';
import PaymentGate from './components/PaymentGate';
import AnalyticsDashboard from './pages/AnalyticsDashboard';
import Marketplace from './pages/Marketplace';
import SalesDashboard from './pages/SalesDashboard';

const AuthenticatedApp = () => {
  const { isLoadingAuth, isLoadingPublicSettings, authError, navigateToLogin } = useAuth();

  // Show loading spinner while checking app public settings or auth
  if (isLoadingPublicSettings || isLoadingAuth) {
    return (
      <div className="fixed inset-0 flex items-center justify-center">
        <div className="w-8 h-8 border-4 border-slate-200 border-t-slate-800 rounded-full animate-spin"></div>
      </div>
    );
  }

  // Handle authentication errors
  if (authError) {
    if (authError.type === 'user_not_registered') {
      return <UserNotRegisteredError />;
    } else if (authError.type === 'auth_required') {
      // Redirect to login automatically
      navigateToLogin();
      return null;
    }
  }

  // Render the main app
  return (
    <Routes>
      <Route element={<AppLayout />}>
        <Route path="/" element={<ValueMapTab />} />
        <Route path="/finder" element={<PaymentGate><OpportunityFinderTab /></PaymentGate>} />
      </Route>
      <Route path="/canvas" element={<CanvassingApp />} />
      <Route path="/people" element={<PeopleMet />} />
      <Route path="/crm" element={<CRMDashboard />} />
      <Route path="/analytics" element={<AnalyticsDashboard />} />
      <Route path="/marketplace" element={<Marketplace />} />
      <Route path="/sales-dashboard" element={<SalesDashboard />} />
      <Route path="/settings" element={<Settings />} />
      <Route path="*" element={<PageNotFound />} />
    </Routes>
  );
};


function App() {

  return (
    <AuthProvider>
      <QueryClientProvider client={queryClientInstance}>
        <Router>
          <AuthenticatedApp />
        </Router>
        <Toaster />
      </QueryClientProvider>
    </AuthProvider>
  )
}

export default App