import { useState } from "react";
import BottomTabs from "../components/BottomTabs";
import ValueMapTab from "../components/ValueMapTab";
import OpportunityFinderTab from "../components/OpportunityFinderTab";

export default function Dashboard() {
  const [activeTab, setActiveTab] = useState("map");

  return (
    <div className="min-h-screen bg-background max-w-lg mx-auto relative">
      {/* Content */}
      <div className="overflow-y-auto">
        {activeTab === "map" && <ValueMapTab />}
        {activeTab === "finder" && <OpportunityFinderTab />}
      </div>

      {/* Bottom Navigation */}
      <BottomTabs activeTab={activeTab} onTabChange={setActiveTab} />
    </div>
  );
}