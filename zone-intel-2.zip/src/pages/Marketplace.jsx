import { useState, useEffect, useCallback, useRef } from "react";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import {
  Search, ShoppingCart, CheckCircle, Loader2, Plus,
  MapPin, X, Upload, Zap, ChevronDown, DollarSign, MessageCircle, Flag, ShieldCheck, SlidersHorizontal
} from "lucide-react";
import { useNavigate } from "react-router-dom";
import BottomTabs from "../components/BottomTabs";
import StripeConnectBanner from "../components/marketplace/StripeConnectBanner";
import MarketplaceDashboard from "../components/marketplace/MarketplaceDashboard";
import ChatPanel from "../components/messaging/ChatPanel";
import CSVUploadModal from "../components/marketplace/CSVUploadModal";
import PhoneVerifyModal from "../components/marketplace/PhoneVerifyModal";
import ReportLeadModal from "../components/marketplace/ReportLeadModal";
import { TrustBadges } from "../components/marketplace/TrustBadges";

// ─── Constants ───────────────────────────────────────────────
const PLATFORM_FEE = 0.15;

const CATEGORIES = [
  { id: "life_insurance",        emoji: "❤️",  label: "Life Insurance",           price: 45 },
  { id: "health_insurance",      emoji: "🏥",  label: "Health Insurance",         price: 35 },
  { id: "auto_insurance",        emoji: "🚗",  label: "Auto Insurance",           price: 25 },
  { id: "homeowners_insurance",  emoji: "🏠",  label: "Homeowners Insurance",     price: 40 },
  { id: "business_insurance",    emoji: "🏢",  label: "Business Insurance",       price: 50 },
  { id: "medicare",              emoji: "💊",  label: "Medicare Plans",           price: 55 },
  { id: "real_estate",           emoji: "🏡",  label: "Real Estate",              price: 75 },
  { id: "mortgage_refinance",    emoji: "🏦",  label: "Mortgage Refinance",       price: 60 },
  { id: "personal_loans",        emoji: "💳",  label: "Personal Loans / Credit",  price: 30 },
  { id: "business_loans",        emoji: "💼",  label: "Business Loans / MCA",     price: 65 },
  { id: "legal",                 emoji: "⚖️",  label: "Legal Leads",              price: 80 },
  { id: "solar_home_services",   emoji: "☀️",  label: "Solar / Home Services",    price: 45 },
  { id: "b2b_saas",              emoji: "💻",  label: "B2B Services",             price: 55 },
  { id: "telecom_utilities",     emoji: "📡",  label: "Telecom / Utilities",      price: 20 },
  { id: "education_career",      emoji: "🎓",  label: "Education / Career",       price: 25 },
];
const CAT = Object.fromEntries(CATEGORIES.map(c => [c.id, c]));

// ─── QuickSell Drawer ────────────────────────────────────────
function QuickSellDrawer({ onClose, onDone }) {
  const [rows, setRows] = useState([{ name: "", phone: "" }]);
  const [category, setCategory] = useState("life_insurance");
  const [showCatPicker, setShowCatPicker] = useState(false);
  const [price, setPrice] = useState(String(CAT["life_insurance"].price));
  const [saving, setSaving] = useState(false);
  const [done, setDone] = useState(false);

  const cat = CAT[category];
  const validRows = rows.filter(r => r.phone.trim() || r.name.trim());

  const setCategory_ = (id) => {
    setCategory(id);
    setPrice(String(CAT[id].price));
    setShowCatPicker(false);
  };

  const updateRow = (i, field, val) => setRows(p => p.map((r, idx) => idx === i ? { ...r, [field]: val } : r));

  const addRow = () => setRows(p => [...p, { name: "", phone: "" }]);

  const submit = async () => {
    if (!validRows.length) return;
    setSaving(true);
    const user = await base44.auth.me();
    for (const row of validRows) {
      await base44.entities.Lead.create({
        owner_name: row.name.trim(),
        phone: row.phone.trim(),
        address: row.name.trim() || row.phone.trim() || "Unknown",
        category,
        status: "not_visited",
        is_for_sale: true,
        price: parseFloat(price) || cat.price,
        seller_id: user?.id || "",
        assigned_rep: user?.email,
        tags: ["quick_sell"],
      });
    }
    setSaving(false);
    setDone(true);
    setTimeout(() => { onDone?.(); onClose(); }, 900);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-stretch">
      <div className="absolute inset-0 bg-black/60" onClick={onClose} />
      <div className="relative w-full max-w-lg mx-auto bg-card shadow-2xl flex flex-col overflow-y-auto">
        {/* Handle */}
        <div className="flex justify-center pt-12 pb-1"><div className="w-10 h-1 rounded-full bg-border" /></div>

        <div className="px-4 pb-2 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Zap className="w-4 h-4 text-yellow-500" />
            <span className="font-bold text-sm text-foreground">Quick Sell</span>
          </div>
          <button onClick={onClose} className="p-2 rounded-lg hover:bg-muted">
            <X className="w-4 h-4 text-muted-foreground" />
          </button>
        </div>

        {/* Category + Price row */}
        <div className="px-4 pb-3 flex gap-2">
          <button onClick={() => setShowCatPicker(v => !v)}
            className="flex-1 flex items-center justify-between h-10 px-3 rounded-xl border border-border bg-muted/40 text-sm font-semibold text-foreground">
            <span>{cat.emoji} {cat.label}</span>
            <ChevronDown className="w-3.5 h-3.5 text-muted-foreground" />
          </button>
          <div className="relative w-24 flex-shrink-0">
            <DollarSign className="absolute left-2 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-muted-foreground" />
            <input type="number" value={price} onChange={e => setPrice(e.target.value)} min="1"
              className="w-full h-10 pl-7 pr-2 text-sm font-bold border border-border rounded-xl bg-background text-foreground text-center focus:outline-none focus:ring-1 focus:ring-ring" />
          </div>
        </div>

        {/* Category picker */}
        {showCatPicker && (
          <div className="mx-4 mb-3 max-h-44 overflow-y-auto rounded-xl border border-border bg-card shadow-lg">
            {CATEGORIES.map(c => (
              <button key={c.id} onClick={() => setCategory_(c.id)}
                className={`w-full text-left px-3 py-2.5 text-sm flex items-center gap-2 hover:bg-muted transition-colors ${category === c.id ? "bg-primary/10 font-bold text-primary" : "text-foreground"}`}>
                <span>{c.emoji}</span>{c.label}<span className="ml-auto text-xs text-muted-foreground">${c.price}</span>
              </button>
            ))}
          </div>
        )}

        {/* Name + Phone rows */}
        <div className="px-4 space-y-2">
          <div className="grid grid-cols-2 gap-2 mb-1">
            <p className="text-xs font-bold text-muted-foreground">Name</p>
            <p className="text-xs font-bold text-muted-foreground">Phone</p>
          </div>
          {rows.map((row, i) => (
            <div key={i} className="grid grid-cols-2 gap-2">
              <input placeholder={`Name ${i + 1}`} value={row.name} onChange={e => updateRow(i, "name", e.target.value)}
                className="h-10 text-sm border border-border rounded-xl px-3 bg-background text-foreground focus:outline-none focus:ring-1 focus:ring-ring placeholder:text-muted-foreground" />
              <input placeholder="(555) 000-0000" type="tel" value={row.phone}
                onChange={e => updateRow(i, "phone", e.target.value)}
                onKeyDown={e => e.key === "Enter" && addRow()}
                className="h-10 text-sm border border-border rounded-xl px-3 bg-background text-foreground focus:outline-none focus:ring-1 focus:ring-ring placeholder:text-muted-foreground" />
            </div>
          ))}
          <button onClick={addRow} className="w-full h-9 flex items-center justify-center gap-1.5 border border-dashed border-border rounded-xl text-xs font-semibold text-muted-foreground hover:border-primary hover:text-primary transition-colors">
            <Plus className="w-3.5 h-3.5" /> Add row
          </button>
        </div>

        <div className="px-4 pt-3 pb-10">
          {done ? (
            <div className="flex items-center justify-center gap-2 h-12 bg-green-50 border border-green-200 rounded-xl">
              <CheckCircle className="w-4 h-4 text-green-600" />
              <p className="text-sm font-bold text-green-700">{validRows.length} lead{validRows.length !== 1 ? "s" : ""} listed!</p>
            </div>
          ) : (
            <Button onClick={submit} disabled={saving || !validRows.length} className="w-full h-12 font-bold text-base">
              {saving ? <Loader2 className="w-4 h-4 animate-spin" /> : `List ${validRows.length || ""} Lead${validRows.length !== 1 ? "s" : ""} · $${price} each`}
            </Button>
          )}
        </div>
      </div>
    </div>
  );
}

// ─── Lead Card ───────────────────────────────────────────────
function LeadCard({ lead, isPurchased, onBuy, buying, onMessage, onReport, onVerify }) {
  const cat = CAT[lead.category] || { emoji: "📋", label: lead.category };
  const loc = [lead.city, lead.state, lead.zip_code].filter(Boolean).join(", ")
    || (lead.address?.split(",").slice(-2).join(",").trim()) || "Unknown area";

  if (isPurchased) {
    return (
      <div className="bg-green-50 border border-green-200 rounded-2xl p-4">
        <div className="flex items-center justify-between mb-2">
          <span className="text-xs font-bold text-green-700 flex items-center gap-1"><CheckCircle className="w-3.5 h-3.5" /> Purchased</span>
          <span className="text-xs font-semibold text-green-600">{cat.emoji} {cat.label}</span>
        </div>
        <p className="text-sm font-bold text-foreground">{lead.owner_name || "—"}</p>
        {lead.phone && <a href={`tel:${lead.phone}`} className="text-sm text-primary font-semibold">{lead.phone}</a>}
        {lead.email && <p className="text-xs text-muted-foreground">{lead.email}</p>}
        <p className="text-xs text-muted-foreground mt-1">{loc}</p>
      </div>
    );
  }

  return (
    <div className="bg-card border border-border rounded-2xl p-4 flex items-center gap-3 active:scale-[0.98] transition-transform">
      <div className="w-10 h-10 rounded-xl bg-muted flex items-center justify-center text-xl flex-shrink-0">
        {cat.emoji}
      </div>
      <div className="flex-1 min-w-0">
        <div className="flex items-center gap-1.5 mb-0.5">
          <p className="text-xs font-bold text-foreground truncate">{cat.label}</p>
          {lead.is_phone_verified && <ShieldCheck className="w-3 h-3 text-emerald-500 flex-shrink-0" />}
        </div>
        <TrustBadges lead={lead} />
        <div className="flex items-center gap-1 mt-1">
            <MapPin className="w-3 h-3 text-muted-foreground flex-shrink-0" />
            <p className="text-xs text-muted-foreground truncate">{loc}</p>
          </div>
          {lead.listing_description && (
            <p className="text-xs text-muted-foreground truncate mt-0.5">{lead.listing_description}</p>
          )}
        </div>
      <div className="flex-shrink-0 text-right">
        <p className="text-base font-black text-foreground mb-1.5">${lead.price}</p>
        <div className="flex gap-1.5 justify-end">
          <button onClick={() => onReport(lead)}
            className="h-8 w-8 rounded-lg border border-border bg-muted/40 flex items-center justify-center hover:bg-muted transition-colors">
            <Flag className="w-3 h-3 text-muted-foreground" />
          </button>
          <button onClick={() => onMessage(lead)}
            className="h-8 w-8 rounded-lg border border-border bg-muted/40 flex items-center justify-center hover:bg-muted transition-colors">
            <MessageCircle className="w-3.5 h-3.5 text-muted-foreground" />
          </button>
          <Button size="sm" onClick={() => onBuy(lead)} disabled={buying === lead.id}
            className="h-8 px-3 text-xs font-bold gap-1">
            {buying === lead.id ? <Loader2 className="w-3 h-3 animate-spin" /> : <><ShoppingCart className="w-3 h-3" />Buy</>}
          </Button>
        </div>
      </div>
    </div>
  );
}

// ─── My Listing Item ─────────────────────────────────────────
function MyListingItem({ lead, onDelist, loading, onVerify }) {
  const cat = CAT[lead.category] || { emoji: "📋", label: lead.category };
  const loc = [lead.city, lead.state, lead.zip_code].filter(Boolean).join(", ") || lead.address || "—";
  return (
    <div className="bg-card border border-border rounded-2xl p-4 flex items-center gap-3">
      <div className="w-9 h-9 rounded-xl bg-muted flex items-center justify-center text-lg flex-shrink-0">{cat.emoji}</div>
      <div className="flex-1 min-w-0">
        <p className="text-xs font-bold text-foreground truncate">{lead.owner_name || lead.phone || "No contact"}</p>
        <p className="text-xs text-muted-foreground truncate">{cat.label} · {loc}</p>
      </div>
      <div className="flex items-center gap-2 flex-shrink-0">
        {!lead.is_phone_verified && (
          <button onClick={() => onVerify(lead)}
            className="h-7 px-2 rounded-lg bg-yellow-50 border border-yellow-300 text-xs font-bold text-yellow-700 flex items-center gap-1">
            <ShieldCheck className="w-3 h-3" /> Verify
          </button>
        )}
        {lead.is_phone_verified && (
          <span className="h-7 px-2 rounded-lg bg-emerald-50 border border-emerald-200 text-xs font-bold text-emerald-700 flex items-center gap-1">
            <ShieldCheck className="w-3 h-3" /> Verified
          </span>
        )}
        <span className="text-sm font-black text-foreground">${lead.price}</span>
        <button onClick={() => onDelist(lead.id)} disabled={loading}
          className="h-8 px-2.5 rounded-lg border border-destructive/40 text-xs font-bold text-destructive hover:bg-destructive/10 transition-colors">
          Delist
        </button>
      </div>
    </div>
  );
}

// ─── Main Page ───────────────────────────────────────────────
export default function Marketplace() {
  const navigate = useNavigate();
  const [leads, setLeads] = useState([]);
  const [myLeads, setMyLeads] = useState([]);
  const [transactions, setTransactions] = useState([]);
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);
  const [buying, setBuying] = useState(null);
  const [delistingId, setDelistingId] = useState(null);
  const [verifying, setVerifying] = useState(false);
  const [verifyMsg, setVerifyMsg] = useState(null);
  const [showQuickSell, setShowQuickSell] = useState(false);
  const [showCSV, setShowCSV] = useState(false);
  const [tab, setTab] = useState("browse"); // browse | selling | bought
  const [search, setSearch] = useState("");
  const [catFilter, setCatFilter] = useState("all");
  const [showStripeInfo, setShowStripeInfo] = useState(false);
  const [chatLead, setChatLead] = useState(null);
  const [reportLead, setReportLead] = useState(null);
  const [verifyLead, setVerifyLead] = useState(null);
  const [trustFilter, setTrustFilter] = useState("all"); // all | verified | unverified

  const loadData = useCallback(async () => {
    const [u, forSale, mine, txns] = await Promise.all([
      base44.auth.me(),
      base44.entities.Lead.filter({ is_for_sale: true }),
      base44.entities.Lead.list("-created_date", 500),
      base44.entities.Transaction.list("-created_date", 500),
    ]);
    setUser(u);
    setLeads(forSale.filter(l => l.seller_id !== u?.id));
    setMyLeads(mine.filter(l => l.is_for_sale && l.seller_id === u?.id));
    setTransactions(txns);
    setLoading(false);
  }, []);

  useEffect(() => { loadData(); }, [loadData]);

  // Handle Stripe redirect
  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    if (params.get("session_id") && params.get("purchased")) {
      setVerifying(true);
      window.history.replaceState(null, "", "/marketplace");
      base44.functions.invoke("verifyLeadPurchase", { sessionId: params.get("session_id") })
        .then(res => {
          if (res.data?.success) { setVerifyMsg("success"); loadData(); setTab("bought"); }
          else setVerifyMsg("error");
        })
        .catch(() => setVerifyMsg("error"))
        .finally(() => setVerifying(false));
    }
  }, []);

  const purchasedIds = new Set(
    transactions.filter(t => t.status === "completed" && t.buyer_id === user?.id).map(t => t.lead_id)
  );
  const purchasedLeads = leads.filter(l => purchasedIds.has(l.id));

  const browseLeads = leads.filter(l => {
    if (catFilter !== "all" && l.category !== catFilter) return false;
    if (trustFilter === "verified" && !l.is_phone_verified) return false;
    if (l.is_flagged) return false;
    if (!search) return true;
    const q = search.toLowerCase();
    return [l.city, l.state, l.zip_code, l.address, l.category, l.listing_description]
      .filter(Boolean).join(" ").toLowerCase().includes(q);
  });

  const handleBuy = async (lead) => {
    if (window.self !== window.top) { alert("Checkout only works from the published app."); return; }
    setBuying(lead.id);
    const base = window.location.origin + "/marketplace";
    const res = await base44.functions.invoke("buyLead", {
      leadId: lead.id,
      successUrl: `${base}?purchased=true&lead_id=${lead.id}`,
      cancelUrl: base,
    });
    if (res.data?.url) window.location.href = res.data.url;
    else { alert(res.data?.error || "Checkout failed"); setBuying(null); }
  };

  const handleDelist = async (leadId) => {
    setDelistingId(leadId);
    await base44.entities.Lead.update(leadId, { is_for_sale: false });
    setDelistingId(null);
    loadData();
  };

  return (
    <div className="min-h-screen bg-background flex flex-col max-w-lg mx-auto pb-20">
      {/* ── Header ── */}
      <div className="sticky top-0 z-20 bg-card/95 backdrop-blur border-b border-border">
        <div className="px-4 pt-3 pb-2 flex items-center gap-2">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <input value={search} onChange={e => setSearch(e.target.value)}
              placeholder="Search city, ZIP, category..."
              className="w-full h-10 pl-9 pr-3 text-sm rounded-xl border border-border bg-muted/40 text-foreground focus:outline-none focus:ring-1 focus:ring-ring placeholder:text-muted-foreground" />
            {search && (
              <button onClick={() => setSearch("")} className="absolute right-2.5 top-1/2 -translate-y-1/2">
                <X className="w-3.5 h-3.5 text-muted-foreground" />
              </button>
            )}
          </div>
          <button onClick={() => setShowCSV(true)}
            className="w-10 h-10 rounded-xl border border-border bg-card flex items-center justify-center hover:bg-muted flex-shrink-0">
            <Upload className="w-4 h-4 text-muted-foreground" />
          </button>
        </div>

        {/* ── Tabs ── */}
        <div className="px-4 pb-2 flex gap-1">
          {[
            { id: "browse", label: `Browse (${leads.length})` },
            { id: "selling", label: `Selling (${myLeads.length})` },
            { id: "bought", label: `Bought (${purchasedIds.size})` },
            { id: "stats", label: "📊 Stats" },
          ].map(t => (
            <button key={t.id} onClick={() => setTab(t.id)}
              className={`flex-1 py-1.5 rounded-lg text-xs font-bold transition-all ${tab === t.id ? "bg-primary text-white" : "text-muted-foreground hover:bg-muted"}`}>
              {t.label}
            </button>
          ))}
        </div>

        {/* ── Trust filters (browse only) ── */}
        {tab === "browse" && (
          <div className="px-4 pb-1.5 flex gap-1.5">
            {[
              { id: "all", label: "All Leads" },
              { id: "verified", label: "✅ Verified Only" },
            ].map(f => (
              <button key={f.id} onClick={() => setTrustFilter(f.id)}
                className={`flex-shrink-0 text-xs font-bold px-3 py-1.5 rounded-full transition-colors ${trustFilter === f.id ? "bg-emerald-500 text-white" : "bg-muted text-muted-foreground"}`}>
                {f.label}
              </button>
            ))}
          </div>
        )}
        {/* ── Category chips (browse only) ── */}
        {tab === "browse" && (
          <div className="px-4 pb-2 flex gap-1.5 overflow-x-auto scrollbar-none">
            <button onClick={() => setCatFilter("all")}
              className={`flex-shrink-0 text-xs font-bold px-3 py-1.5 rounded-full transition-colors ${catFilter === "all" ? "bg-primary text-white" : "bg-muted text-muted-foreground"}`}>
              All
            </button>
            {CATEGORIES.map(c => (
              <button key={c.id} onClick={() => setCatFilter(c.id)}
                className={`flex-shrink-0 text-xs font-semibold px-3 py-1.5 rounded-full transition-colors whitespace-nowrap ${catFilter === c.id ? "bg-primary text-white" : "bg-muted text-muted-foreground"}`}>
                {c.emoji} {c.label}
              </button>
            ))}
          </div>
        )}
      </div>

      {/* ── Status banners ── */}
      {verifying && (
        <div className="mx-4 mt-3 flex items-center gap-2 bg-blue-50 border border-blue-200 rounded-xl px-3 py-2.5">
          <Loader2 className="w-4 h-4 text-blue-600 animate-spin" />
          <p className="text-sm font-semibold text-blue-700">Verifying payment…</p>
        </div>
      )}
      {verifyMsg === "success" && (
        <div className="mx-4 mt-3 flex items-center gap-2 bg-green-50 border border-green-200 rounded-xl px-3 py-2.5">
          <CheckCircle className="w-4 h-4 text-green-600" />
          <p className="text-sm font-bold text-green-700">Purchase complete! Lead added to your CRM.</p>
          <button onClick={() => setVerifyMsg(null)} className="ml-auto"><X className="w-3.5 h-3.5 text-green-600" /></button>
        </div>
      )}
      {verifyMsg === "error" && (
        <div className="mx-4 mt-3 flex items-center gap-2 bg-red-50 border border-red-200 rounded-xl px-3 py-2.5">
          <X className="w-4 h-4 text-red-500" />
          <p className="text-sm font-bold text-red-700">Payment verification failed. Contact support.</p>
          <button onClick={() => setVerifyMsg(null)} className="ml-auto"><X className="w-3.5 h-3.5 text-red-500" /></button>
        </div>
      )}

      {/* ── Feed ── */}
      <div className="flex-1 px-4 pt-3 space-y-2.5">
        {loading ? (
          <div className="flex items-center justify-center py-20">
            <Loader2 className="w-6 h-6 text-primary animate-spin" />
          </div>
        ) : tab === "browse" ? (
          browseLeads.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-16 text-center">
              <p className="text-3xl mb-3">🔍</p>
              <p className="font-bold text-foreground">No leads found</p>
              <p className="text-sm text-muted-foreground mt-1">Be the first to sell leads in this category.</p>
              <Button onClick={() => setShowQuickSell(true)} className="mt-4 gap-2">
                <Zap className="w-4 h-4" /> Quick Sell
              </Button>
            </div>
          ) : (
            browseLeads.map(lead => (
              <LeadCard key={lead.id} lead={lead}
                isPurchased={purchasedIds.has(lead.id)}
                onBuy={handleBuy} buying={buying} onMessage={setChatLead}
                onReport={setReportLead} onVerify={setVerifyLead} />
            ))
          )
        ) : tab === "stats" ? (
          <MarketplaceDashboard leads={[...leads, ...myLeads]} transactions={transactions} user={user} />
        ) : tab === "selling" ? (
          <>
            <StripeConnectBanner />
            {myLeads.length === 0 ? (
              <div className="flex flex-col items-center justify-center py-12 text-center">
                <p className="text-3xl mb-3">💸</p>
                <p className="font-bold text-foreground">No active listings</p>
                <p className="text-sm text-muted-foreground mt-1">Tap + to start selling leads instantly.</p>
              </div>
            ) : (
              myLeads.map(lead => (
                <MyListingItem key={lead.id} lead={lead}
                  onDelist={handleDelist} loading={delistingId === lead.id} onVerify={setVerifyLead} />
              ))
            )}
          </>
        ) : (
          purchasedLeads.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-16 text-center">
              <p className="text-3xl mb-3">🛒</p>
              <p className="font-bold text-foreground">No purchased leads yet</p>
              <p className="text-sm text-muted-foreground mt-1">Browse and buy leads to see them here.</p>
            </div>
          ) : (
            purchasedLeads.map(lead => (
              <LeadCard key={lead.id} lead={lead} isPurchased={true} onBuy={handleBuy} buying={buying} />
            ))
          )
        )}
      </div>

      {/* ── Floating Quick Sell ── */}
      <button onClick={() => setShowQuickSell(true)}
        className="fixed bottom-32 right-4 z-30 w-14 h-14 rounded-full bg-primary shadow-lg flex items-center justify-center hover:bg-primary/90 active:scale-95 transition-all">
        <Plus className="w-6 h-6 text-white" />
      </button>

      {/* ── Modals ── */}
      {showQuickSell && (
        <QuickSellDrawer onClose={() => setShowQuickSell(false)} onDone={() => { loadData(); setTab("selling"); }} />
      )}
      {showCSV && (
        <CSVUploadModal onClose={() => setShowCSV(false)} onUploaded={() => { loadData(); setTab("selling"); }} />
      )}
      {chatLead && user && (
        <ChatPanel lead={chatLead} currentUser={user} onClose={() => setChatLead(null)} />
      )}
      {reportLead && (
        <ReportLeadModal lead={reportLead} onClose={() => setReportLead(null)} />
      )}
      {verifyLead && (
        <PhoneVerifyModal lead={verifyLead} onClose={() => setVerifyLead(null)} onVerified={() => { loadData(); setVerifyLead(null); }} />
      )}

      <BottomTabs activeTab="marketplace" onTabChange={(t) => {
        if (t === "map") navigate("/");
        else if (t === "finder") navigate("/finder");
      }} />
    </div>
  );
}