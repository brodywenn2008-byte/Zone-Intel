import { useState, useEffect, useRef, useCallback } from "react";
import { MapContainer, TileLayer, GeoJSON, CircleMarker, Polygon, useMap, useMapEvents } from "react-leaflet";
import "leaflet/dist/leaflet.css";
import { base44 } from "@/api/base44Client";
import { Loader2, Zap } from "lucide-react";
import MapControls from "@/components/zoneintel/MapControls";
import NeighborhoodPopup from "@/components/zoneintel/NeighborhoodPopup";
import ContactSheet from "@/components/zoneintel/ContactSheet";

// ─── Helpers ────────────────────────────────────────────────────────────────

const scoreToColor = (score, alpha = 1) => {
  if (score >= 70) return `rgba(16, 185, 129, ${alpha})`;
  if (score >= 45) return `rgba(245, 158, 11, ${alpha})`;
  return `rgba(239, 68, 68, ${alpha})`;
};

function RecenterMap({ trigger, position }) {
  const map = useMap();
  useEffect(() => {
    if (position && trigger) map.setView(position, 16, { animate: true });
  }, [trigger]);
  return null;
}

function MapMoveListener({ onMoveEnd }) {
  useMapEvents({ moveend: onMoveEnd, zoomend: onMoveEnd });
  return null;
}

// ─── Main Page ───────────────────────────────────────────────────────────────

export default function ZoneIntel() {
  const [regridToken, setRegridToken] = useState(null);
  const [userPos, setUserPos] = useState(null);
  const [centerTrigger, setCenterTrigger] = useState(0);
  const [centerPos, setCenterPos] = useState([37.7749, -122.4194]);
  const [parcels, setParcels] = useState([]);
  const [visited, setVisited] = useState(() => {
    try { return JSON.parse(localStorage.getItem("zi_visited") || "{}"); } catch { return {}; }
  });
  const [contacts, setContacts] = useState(() => {
    try { return JSON.parse(localStorage.getItem("zi_contacts") || "{}"); } catch { return {}; }
  });
  const [selectedParcel, setSelectedParcel] = useState(null);
  const [neighborhoods, setNeighborhoods] = useState([]);
  const [selectedNeighborhood, setSelectedNeighborhood] = useState(null);
  const [loadingParcels, setLoadingParcels] = useState(false);
  const [loadingNeighborhoods, setLoadingNeighborhoods] = useState(false);
  const [showUnvisitedOnly, setShowUnvisitedOnly] = useState(false);
  const [highlightTop, setHighlightTop] = useState(true);
  const [parcelError, setParcelError] = useState(null);
  const [currentZoom, setCurrentZoom] = useState(16);
  const [showHeatmap, setShowHeatmap] = useState(false);
  const [savedLeads, setSavedLeads] = useState([]);
  const mapRef = useRef(null);
  const fetchedAreaRef = useRef(null);

  // Fetch saved leads for density layer
  useEffect(() => {
    base44.entities.Lead.filter({ status: ["interested", "sold", "appointment_set", "follow_up"] })
      .then(setSavedLeads)
      .catch(() => {});
  }, []);

  // Fetch Regrid token for tile layers
  useEffect(() => {
    base44.functions.invoke("regridParcels", { action: "token" })
      .then(res => { if (res?.data?.token) setRegridToken(res.data.token); })
      .catch(() => {});
  }, []);

  // GPS
  useEffect(() => {
    if (!navigator.geolocation) return;
    navigator.geolocation.getCurrentPosition(
      pos => {
        const p = [pos.coords.latitude, pos.coords.longitude];
        setUserPos(p);
        setCenterPos(p);
        setCenterTrigger(1);
      },
      () => {},
      { enableHighAccuracy: true, timeout: 10000 }
    );
  }, []);

  // Persist
  useEffect(() => { localStorage.setItem("zi_visited", JSON.stringify(visited)); }, [visited]);
  useEffect(() => { localStorage.setItem("zi_contacts", JSON.stringify(contacts)); }, [contacts]);

  const fetchParcels = useCallback(async (lat, lng) => {
    setLoadingParcels(true);
    setParcelError(null);
    try {
      const res = await base44.functions.invoke("regridParcels", { lat, lng, radius_km: 0.35 });
      const features = res?.data?.parcels?.features || res?.data?.features || [];
      setParcels(features);
    } catch (err) {
      setParcelError(err?.response?.data?.error || "Parcel data unavailable");
      setParcels([]);
    } finally {
      setLoadingParcels(false);
    }
  }, []);

  const fetchNeighborhoods = useCallback(async (lat, lng) => {
    setLoadingNeighborhoods(true);
    try {
      const result = await base44.integrations.Core.InvokeLLM({
        prompt: `You are a real estate intelligence AI. For GPS (${lat.toFixed(4)}, ${lng.toFixed(4)}), identify 4-6 real nearby neighborhoods.

For EACH provide:
- name, city (city, state), score (0-100 opportunity), avg_home_value (USD), ownership_rate (%), market_trend ("Rising"|"Stable"|"Declining"), total_homes (estimated), summary (1 sentence), reasoning (2-3 sentences for/against sales outreach), pros (array of 2), cons (array of 1-2), polygon (array of 6-10 [lat,lng] boundary pairs), center_lat, center_lng`,
        add_context_from_internet: true,
        model: "gemini_3_flash",
        response_json_schema: {
          type: "object",
          properties: {
            neighborhoods: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  name: { type: "string" }, city: { type: "string" }, score: { type: "number" },
                  avg_home_value: { type: "number" }, ownership_rate: { type: "number" },
                  market_trend: { type: "string" }, total_homes: { type: "number" },
                  summary: { type: "string" }, reasoning: { type: "string" },
                  pros: { type: "array", items: { type: "string" } },
                  cons: { type: "array", items: { type: "string" } },
                  polygon: { type: "array", items: { type: "array", items: { type: "number" } } },
                  center_lat: { type: "number" }, center_lng: { type: "number" },
                },
              },
            },
          },
        },
      });
      if (result?.neighborhoods) setNeighborhoods(result.neighborhoods);
    } catch {}
    setLoadingNeighborhoods(false);
  }, []);

  useEffect(() => {
    if (!userPos) return;
    fetchParcels(userPos[0], userPos[1]);
    fetchNeighborhoods(userPos[0], userPos[1]);
  }, [userPos]);

  const handleMapMoveEnd = useCallback(() => {
    if (!mapRef.current) return;
    const map = mapRef.current;
    const zoom = map.getZoom();
    const center = map.getCenter();
    setCurrentZoom(zoom);
    if (zoom < 14) return;
    const key = `${center.lat.toFixed(3)},${center.lng.toFixed(3)}`;
    if (fetchedAreaRef.current === key) return;
    fetchedAreaRef.current = key;
    fetchParcels(center.lat, center.lng);
  }, [fetchParcels]);

  const handleRefresh = () => {
    if (!mapRef.current) return;
    const c = mapRef.current.getCenter();
    fetchedAreaRef.current = null;
    fetchParcels(c.lat, c.lng);
    fetchNeighborhoods(c.lat, c.lng);
  };

  // Parcel helpers
  const getParcelId = (feature) =>
    feature?.properties?.ll_uuid || feature?.properties?.objectid || feature?.id || JSON.stringify(feature?.geometry?.coordinates?.[0]?.[0]);

  const getParcelCentroid = (feature) => {
    try {
      const coords = feature?.geometry?.coordinates;
      if (!coords) return null;
      const ring = feature.geometry.type === "MultiPolygon" ? coords[0][0] : coords[0];
      if (!ring?.length) return null;
      const lat = ring.reduce((s, c) => s + c[1], 0) / ring.length;
      const lng = ring.reduce((s, c) => s + c[0], 0) / ring.length;
      return [lat, lng];
    } catch { return null; }
  };

  const getDotColor = (id) => {
    const c = contacts[id];
    if (c?.interest === "yes") return "#10b981";
    if (c?.interest === "maybe") return "#f59e0b";
    if (c?.interest === "no") return "#ef4444";
    if (c?.answered === false) return "#6b7280";
    if (visited[id]) return "#22d3ee";
    return "#3b82f6";
  };

  const getParcelStyle = (feature) => {
    const id = getParcelId(feature);
    const isContacted = !!contacts[id];
    const isVisited = !!visited[id];
    if (showUnvisitedOnly && (isContacted || isVisited)) return { opacity: 0, fillOpacity: 0 };
    const color = getDotColor(id);
    return {
      color,
      weight: isContacted ? 2 : 1.5,
      fillColor: color,
      fillOpacity: isContacted ? 0.25 : 0.08,
      opacity: 0.85,
    };
  };

  const onEachParcelFeature = (feature, layer) => {
    const addr = feature?.properties?.address || feature?.properties?.siteaddr || feature?.properties?.ll_address;
    if (addr) layer.bindTooltip(addr, { sticky: true, opacity: 0.9 });
  };

  const saveContact = (parcelId, data) => {
    setContacts(prev => {
      const next = { ...prev };
      if (!data) { delete next[parcelId]; return next; }
      next[parcelId] = data;
      return next;
    });
    if (data) setVisited(prev => ({ ...prev, [parcelId]: true }));
  };

  const contactedCount = Object.keys(contacts).length;
  const visitedCount = Object.keys(visited).length;

  // Dot color legend
  const DOT_LEGEND = [
    { color: "#10b981", label: "Interested" },
    { color: "#f59e0b", label: "Maybe" },
    { color: "#ef4444", label: "Not Interested" },
    { color: "#6b7280", label: "No Answer" },
    { color: "#22d3ee", label: "Visited" },
    { color: "#3b82f6", label: "Not Visited" },
  ];

  return (
    <div className="fixed inset-0 flex flex-col bg-gray-950 overflow-hidden">
      {/* Top bar */}
      <div className="absolute top-0 left-0 right-0 z-30 flex items-center justify-between px-4 pt-4 pb-2 pointer-events-none">
        <div className="bg-gray-900/90 backdrop-blur-md rounded-2xl px-4 py-2.5 shadow-xl border border-white/10 pointer-events-auto">
          <div className="flex items-center gap-2">
            <div className="w-6 h-6 rounded-lg bg-blue-500 flex items-center justify-center">
              <Zap className="w-3.5 h-3.5 text-white" />
            </div>
            <p className="text-sm font-black text-white tracking-tight">ZoneIntel</p>
          </div>
        </div>

        <div className="bg-gray-900/90 backdrop-blur-md rounded-2xl px-3 py-2 shadow-xl border border-white/10 flex items-center gap-3 pointer-events-auto">
          {loadingParcels && <Loader2 className="w-3.5 h-3.5 text-blue-400 animate-spin" />}
          <div className="text-center">
            <p className="text-xs font-black text-white leading-none">{parcels.length}</p>
            <p className="text-xs text-gray-400 leading-none mt-0.5">parcels</p>
          </div>
          <div className="w-px h-6 bg-white/10" />
          <div className="text-center">
            <p className="text-xs font-black text-emerald-400 leading-none">{contactedCount}</p>
            <p className="text-xs text-gray-400 leading-none mt-0.5">contacts</p>
          </div>
          <div className="w-px h-6 bg-white/10" />
          <div className="text-center">
            <p className="text-xs font-black text-cyan-400 leading-none">{visitedCount}</p>
            <p className="text-xs text-gray-400 leading-none mt-0.5">visited</p>
          </div>
        </div>
      </div>

      {/* Map */}
      <div className="flex-1 relative">
        <MapContainer
          center={centerPos}
          zoom={16}
          style={{ width: "100%", height: "100%" }}
          zoomControl={false}
          attributionControl={false}
          ref={mapRef}
        >
          {/* Base map — satellite so every house is visible */}
          <TileLayer
            url="https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}"
            maxZoom={20}
            attribution="Tiles &copy; Esri"
          />
          {/* Street label overlay */}
          <TileLayer
            url="https://{s}.basemaps.cartocdn.com/dark_only_labels/{z}/{x}/{y}{r}.png"
            maxZoom={20}
            opacity={0.7}
          />
          {/* Regrid parcel tile overlay */}
          {regridToken && (
            <TileLayer
              url={`https://tiles.regrid.com/api/v1/parcels/{z}/{x}/{y}.png?token=${regridToken}&stroke=%233b82f6&stroke-width=1&fill=%233b82f6&fill-opacity=0.1`}
              maxZoom={20}
              opacity={0.9}
              zIndex={5}
            />
          )}

          <RecenterMap trigger={centerTrigger} position={centerPos} />
          <MapMoveListener onMoveEnd={handleMapMoveEnd} />

          {/* Neighborhood polygons */}
          {neighborhoods.map((nb, i) => {
            if (!nb.polygon?.length) return null;
            const isTop = highlightTop && nb.score >= 70;
            const color = scoreToColor(nb.score);
            return (
              <Polygon
                key={i}
                positions={nb.polygon.map(p => [p[0], p[1]])}
                pathOptions={{
                  color, weight: isTop ? 3 : 2,
                  fillColor: color, fillOpacity: isTop ? 0.15 : 0.08,
                  dashArray: nb.score < 45 ? "6 4" : undefined,
                }}
                eventHandlers={{ click: () => setSelectedNeighborhood(nb) }}
              />
            );
          })}

          {/* Parcel fill polygons */}
          {parcels.length > 0 && (
            <GeoJSON
              key={`parcels-${contactedCount}-${visitedCount}-${parcels.length}`}
              data={{ type: "FeatureCollection", features: parcels }}
              style={getParcelStyle}
              onEachFeature={onEachParcelFeature}
            />
          )}

          {/* Clickable dot on each parcel centroid */}
          {parcels.map((feature, i) => {
            const centroid = getParcelCentroid(feature);
            if (!centroid) return null;
            const id = getParcelId(feature);
            const isContacted = !!contacts[id];
            const isVisited = !!visited[id];
            if (showUnvisitedOnly && (isContacted || isVisited)) return null;
            const color = getDotColor(id);
            return (
              <CircleMarker
                key={`dot-${id}-${i}`}
                center={centroid}
                radius={isContacted ? 7 : 5}
                pathOptions={{
                  color: "#fff",
                  weight: isContacted ? 2 : 1,
                  fillColor: color,
                  fillOpacity: 1,
                }}
                eventHandlers={{
                  click: (e) => {
                    e.originalEvent?.stopPropagation();
                    setSelectedParcel(feature);
                  }
                }}
              />
            );
          })}

          {/* Heat density layer */}
          {showHeatmap && (() => {
            // Build density points from both localStorage contacts and saved leads
            const points = [];

            // From localStorage contacts on current parcels
            parcels.forEach(feature => {
              const id = getParcelId(feature);
              const contact = contacts[id];
              if (!contact) return;
              const centroid = getParcelCentroid(feature);
              if (!centroid) return;
              const interest = contact.interest;
              const color = interest === "yes" ? "#10b981"
                : interest === "maybe" ? "#f59e0b"
                : interest === "no" ? "#ef4444"
                : "#6b7280";
              const weight = interest === "yes" ? 3 : interest === "maybe" ? 2 : 1;
              points.push({ centroid, color, weight, id: `local-${id}` });
            });

            // From saved Lead entity records
            savedLeads.forEach(lead => {
              if (!lead.lat || !lead.lng) return;
              const color = (lead.status === "interested" || lead.status === "sold") ? "#10b981"
                : lead.status === "appointment_set" ? "#8b5cf6"
                : lead.status === "follow_up" ? "#f59e0b"
                : "#6b7280";
              const weight = (lead.status === "sold" || lead.status === "appointment_set") ? 3
                : lead.status === "interested" ? 2.5 : 1.5;
              points.push({ centroid: [lead.lat, lead.lng], color, weight, id: `lead-${lead.id}` });
            });

            return points.map(({ centroid, color, weight, id }) => (
              <CircleMarker
                key={`heat-${id}`}
                center={centroid}
                radius={28}
                pathOptions={{ color, weight: 0, fillColor: color, fillOpacity: 0.18 }}
              />
            ));
          })()}

          {/* User location */}
          {userPos && (
            <CircleMarker
              center={userPos}
              radius={8}
              pathOptions={{ color: "#fff", weight: 3, fillColor: "#3b82f6", fillOpacity: 1 }}
            />
          )}
        </MapContainer>

        {/* Map controls */}
        <div className="absolute right-4 top-20 z-20 flex flex-col gap-2">
          <MapControls
            onRecenter={() => {
              if (userPos) {
                setCenterPos([...userPos]);
                setCenterTrigger(t => t + 1);
              }
            }}
            showUnvisitedOnly={showUnvisitedOnly}
            onToggleUnvisited={() => setShowUnvisitedOnly(v => !v)}
            showHeatmap={showHeatmap}
            onToggleHeatmap={() => setShowHeatmap(v => !v)}
            highlightTop={highlightTop}
            onToggleHighlight={() => setHighlightTop(v => !v)}
            onRefresh={handleRefresh}
            loading={loadingParcels || loadingNeighborhoods}
          />
        </div>

        {/* Dot legend */}
        <div className="absolute bottom-36 left-3 z-20">
          <div className="bg-gray-900/90 backdrop-blur-sm rounded-2xl border border-white/10 px-3 py-2.5 shadow-xl">
            <p className="text-xs font-bold text-gray-400 uppercase tracking-wider mb-2">Dot Status</p>
            <div className="space-y-1.5">
              {DOT_LEGEND.map(({ color, label }) => (
                <div key={label} className="flex items-center gap-2">
                  <div className="w-3 h-3 rounded-full border border-white/30 flex-shrink-0" style={{ background: color }} />
                  <span className="text-xs text-gray-300">{label}</span>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Notices */}
        {parcelError && (
          <div className="absolute top-20 left-4 right-20 z-20 bg-amber-900/90 backdrop-blur-sm text-amber-200 text-xs font-medium px-4 py-2.5 rounded-2xl border border-amber-700/50 text-center">
            ⚠️ {parcelError}
          </div>
        )}
        {currentZoom < 14 && !loadingParcels && (
          <div className="absolute top-20 left-1/2 -translate-x-1/2 z-20 bg-gray-900/90 backdrop-blur-sm text-gray-300 text-xs font-medium px-4 py-2 rounded-full border border-white/10 whitespace-nowrap">
            Zoom in to see property parcels
          </div>
        )}
        {loadingParcels && (
          <div className="absolute top-20 left-1/2 -translate-x-1/2 z-20 bg-gray-900/90 backdrop-blur-sm px-4 py-2 rounded-full border border-white/10 flex items-center gap-2">
            <Loader2 className="w-3.5 h-3.5 text-blue-400 animate-spin" />
            <span className="text-xs text-gray-300 font-medium">Loading parcels...</span>
          </div>
        )}
      </div>

      {/* Neighborhood chips */}
      <div className="absolute bottom-0 left-0 right-0 z-20 pb-6 pointer-events-none">
        {loadingNeighborhoods && (
          <div className="flex justify-center mb-2">
            <div className="bg-gray-900/90 backdrop-blur-sm px-4 py-2 rounded-full border border-white/10 flex items-center gap-2 pointer-events-auto">
              <Loader2 className="w-3.5 h-3.5 text-blue-400 animate-spin" />
              <span className="text-xs text-gray-300">Analyzing neighborhoods...</span>
            </div>
          </div>
        )}
        {neighborhoods.length > 0 && (
          <div className="overflow-x-auto px-4 pointer-events-auto">
            <div className="flex gap-2 pb-1" style={{ width: "max-content" }}>
              {[...neighborhoods].sort((a, b) => b.score - a.score).map((nb, i) => (
                <button
                  key={i}
                  onClick={() => setSelectedNeighborhood(nb)}
                  className="flex items-center gap-2 bg-gray-900/95 backdrop-blur-md rounded-2xl px-3.5 py-2.5 border border-white/10 shadow-xl flex-shrink-0 active:scale-95 transition-transform"
                >
                  <div className="w-2.5 h-2.5 rounded-full flex-shrink-0" style={{ background: scoreToColor(nb.score) }} />
                  <div className="text-left">
                    <p className="text-xs font-bold text-white leading-none">{nb.name}</p>
                    <p className="text-xs font-black leading-none mt-0.5" style={{ color: scoreToColor(nb.score) }}>{nb.score}/100</p>
                  </div>
                </button>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* Modals */}
      {selectedNeighborhood && (
        <NeighborhoodPopup
          neighborhood={selectedNeighborhood}
          visitedCount={Object.keys(visited).length}
          onClose={() => setSelectedNeighborhood(null)}
        />
      )}

      {selectedParcel && (
        <ContactSheet
          parcel={selectedParcel}
          contact={contacts[getParcelId(selectedParcel)]}
          onSave={(data) => saveContact(getParcelId(selectedParcel), data)}
          onClose={() => setSelectedParcel(null)}
        />
      )}
    </div>
  );
}