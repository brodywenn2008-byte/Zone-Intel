import { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Home, Users, BarChart3, Calendar, Search,
  Loader2, ArrowLeft, Plus, Phone, SlidersHorizontal, X, Map, List, Flame
} from "lucide-react";
import NeighborhoodFinder from "@/components/canvassing/NeighborhoodFinder";
import CanvassingMap from "@/components/canvassing/CanvassingMap";
import LeadDetailSheet from "@/components/canvassing/LeadDetailSheet";
import AddContactModal from "@/components/canvassing/AddContactModal";
import TeamDashboard from "@/components/canvassing/TeamDashboard";
import AppointmentsList from "@/components/canvassing/AppointmentsList";
import AppointmentModal from "@/components/canvassing/AppointmentModal";
import StatusBadge, { STATUS_CONFIG } from "@/components/canvassing/StatusBadge";

const TABS = [
  { id: "neighborhoods", label: "Areas", Icon: Home },
  { id: "contacts", label: "Contacts", Icon: Users },
  { id: "stats", label: "Stats", Icon: BarChart3 },
  { id: "appts", label: "Appts", Icon: Calendar },
];

const SORT_OPTIONS = [
  { id: "recent", label: "Recent" },
  { id: "score", label: "AI Score" },
  { id: "status", label: "Status" },
  { id: "address", label: "Address" },
];

export default function CanvassingApp() {
  const [tab, setTab] = useState("neighborhoods");
  const [leads, setLeads] = useState([]);
  const [visits, setVisits] = useState([]);
  const [appointments, setAppointments] = useState([]);
  const [selectedLead, setSelectedLead] = useState(null);
  const [apptLead, setApptLead] = useState(null);
  const [user, setUser] = useState(null);
  const [showAddContact, setShowAddContact] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");
  const [sortBy, setSortBy] = useState("recent");
  const [showFilters, setShowFilters] = useState(false);
  const [showSortDrawer, setShowSortDrawer] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [contactsView, setContactsView] = useState("list"); // list | map
  const [showHeatmap, setShowHeatmap] = useState(true);

  useEffect(() => {
    base44.auth.me().then(setUser).catch(() => {});
    base44.entities.Visit.list("-created_date", 300).then(setVisits).catch(() => {});
    base44.entities.Appointment.list("-date", 150).then(setAppointments).catch(() => {});
    setIsLoading(true);
    base44.entities.Lead.list("-created_date", 500)
      .then(setLeads)
      .finally(() => setIsLoading(false));
  }, []);

  const handleLeadUpdate = (updated, closeSheet = true) => {
    setLeads((prev) => prev.map((l) => l.id === updated.id ? updated : l));
    if (closeSheet) setSelectedLead(null);
    base44.entities.Visit.list("-created_date", 300).then(setVisits).catch(() => {});
  };

  const handleContactCreated = (lead) => {
    setLeads((prev) => [lead, ...prev]);
    setShowAddContact(false);
    setTab("contacts");
  };

  const handleAppointmentCreated = (appt) => {
    setAppointments((prev) => [appt, ...prev]);
    setApptLead(null);
  };

  const handleAppointmentUpdate = (updated) => {
    setAppointments((prev) => prev.map((a) => a.id === updated.id ? updated : a));
  };

  const filteredLeads = leads
    .filter((l) => {
      const matchStatus = statusFilter === "all" || l.status === statusFilter;
      const matchSearch =
        !searchQuery ||
        l.address?.toLowerCase().includes(searchQuery.toLowerCase()) ||
        l.owner_name?.toLowerCase().includes(searchQuery.toLowerCase()) ||
        l.phone?.includes(searchQuery);
      return matchStatus && matchSearch;
    })
    .sort((a, b) => {
      if (sortBy === "recent") return new Date(b.created_date || 0) - new Date(a.created_date || 0);
      if (sortBy === "score") return (b.lead_score || 0) - (a.lead_score || 0);
      if (sortBy === "address") return (a.address || "").localeCompare(b.address || "");
      if (sortBy === "status") return (a.status || "").localeCompare(b.status || "");
      return 0;
    });

  const todayAppts = appointments.filter((a) => {
    const d = new Date(a.date);
    return a.status === "scheduled" && d.toDateString() === new Date().toDateString();
  });

  const highPriorityCount = leads.filter((l) => l.ai_priority === "high" && l.status === "not_visited").length;

  return (
    <div className="fixed inset-0 flex flex-col bg-background overflow-hidden">
      {/* Header */}
      <div className="bg-card border-b border-border px-4 py-3 flex items-center gap-3 flex-shrink-0 z-20">
        <div className="w-8 h-8 rounded-xl bg-primary flex items-center justify-center flex-shrink-0">
          <Home className="w-4 h-4 text-white" />
        </div>
        <div className="flex-1 min-w-0">
          <p className="text-sm font-bold text-foreground leading-snug">Field Canvassing</p>
          <p className="text-xs text-muted-foreground leading-none">
            {isLoading ? "Loading..." : `${leads.length} contacts logged`}
          </p>
        </div>
        <div className="flex items-center gap-2 flex-shrink-0">
          {todayAppts.length > 0 && (
            <button onClick={() => setTab("appts")} className="text-xs font-bold text-white bg-purple-500 px-2 py-1 rounded-lg">
              📅 {todayAppts.length}
            </button>
          )}
          <button
            onClick={() => setShowAddContact(true)}
            className="flex items-center gap-1.5 text-xs font-bold text-white bg-primary px-3 py-1.5 rounded-xl"
          >
            <Plus className="w-3.5 h-3.5" /> Log Person
          </button>
          <a href="/" className="w-8 h-8 rounded-xl hover:bg-muted flex items-center justify-center">
            <ArrowLeft className="w-4 h-4 text-muted-foreground" />
          </a>
        </div>
      </div>

      {/* Content */}
      <div className="flex-1 flex flex-col min-h-0 overflow-hidden">

        {/* NEIGHBORHOODS TAB */}
        {tab === "neighborhoods" && <NeighborhoodFinder />}

        {/* CONTACTS TAB */}
        {tab === "contacts" && (
          <div className="flex-1 flex flex-col min-h-0">
            {/* View toggle bar */}
            <div className="flex items-center gap-2 px-4 py-2 border-b border-border bg-card flex-shrink-0">
              <button onClick={() => setContactsView("list")}
                className={`flex items-center gap-1.5 text-xs font-bold px-3 py-1.5 rounded-lg transition-colors ${contactsView === "list" ? "bg-primary text-white" : "bg-muted text-muted-foreground"}`}>
                <List className="w-3.5 h-3.5" /> List
              </button>
              <button onClick={() => setContactsView("map")}
                className={`flex items-center gap-1.5 text-xs font-bold px-3 py-1.5 rounded-lg transition-colors ${contactsView === "map" ? "bg-primary text-white" : "bg-muted text-muted-foreground"}`}>
                <Map className="w-3.5 h-3.5" /> Map
              </button>
              {contactsView === "map" && (
                <button onClick={() => setShowHeatmap(v => !v)}
                  className={`ml-auto flex items-center gap-1.5 text-xs font-bold px-3 py-1.5 rounded-lg border transition-colors ${
                    showHeatmap ? "bg-orange-500 text-white border-orange-500" : "border-border bg-card text-muted-foreground"
                  }`}>
                  <Flame className="w-3.5 h-3.5" /> Heatmap
                </button>
              )}
            </div>

            {/* Map view */}
            {contactsView === "map" && (
              <div className="flex-1 relative">
                <CanvassingMap
                  leads={filteredLeads.filter(l => l.lat && l.lng)}
                  showHeatmap={showHeatmap}
                  onLeadClick={setSelectedLead}
                  selectedLeadId={selectedLead?.id}
                  userPosition={null}
                />
                {showHeatmap && (
                  <div className="absolute bottom-4 left-3 bg-black/70 backdrop-blur-sm rounded-xl p-3 z-[1000]">
                    <p className="text-xs font-bold text-white mb-2">Heatmap Legend</p>
                    <div className="space-y-1">
                      {[
                        { label: "Sold", color: "#22c55e" },
                        { label: "Interested", color: "#84cc16" },
                        { label: "Appointment", color: "#8b5cf6" },
                        { label: "Follow-up", color: "#f59e0b" },
                        { label: "No Answer", color: "#f97316" },
                        { label: "Not Interested", color: "#ef4444" },
                        { label: "Not Visited", color: "#94a3b8" },
                      ].map(({ label, color }) => (
                        <div key={label} className="flex items-center gap-2">
                          <div className="w-3 h-3 rounded-full flex-shrink-0" style={{ backgroundColor: color }} />
                          <span className="text-xs text-white/80">{label}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            )}

            {/* List view */}
            {contactsView === "list" && (
              <>
                <div className="px-4 py-3 border-b border-border bg-card flex-shrink-0 space-y-2">
                  <div className="flex gap-2">
                    <div className="relative flex-1">
                      <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                      <Input
                        placeholder="Search name, address, phone..."
                        value={searchQuery}
                        onChange={(e) => setSearchQuery(e.target.value)}
                        className="pl-10 h-9 text-sm"
                      />
                    </div>
                    <button
                      onClick={() => setShowFilters(!showFilters)}
                      className={`w-9 h-9 rounded-xl border flex items-center justify-center transition-colors flex-shrink-0 ${
                        showFilters || statusFilter !== "all"
                          ? "bg-primary text-white border-primary"
                          : "border-border bg-card hover:bg-muted"
                      }`}
                    >
                      <SlidersHorizontal className="w-4 h-4" />
                    </button>
                  </div>
                  {showFilters && (
                    <div className="space-y-2">
                      <div className="flex gap-1.5 overflow-x-auto pb-0.5">
                        {["all", ...Object.keys(STATUS_CONFIG)].map((s) => (
                          <button
                            key={s}
                            onClick={() => setStatusFilter(s)}
                            className={`flex-shrink-0 text-xs font-semibold px-3 py-1.5 rounded-full transition-colors ${
                              statusFilter === s ? "bg-primary text-white" : "bg-muted text-muted-foreground hover:bg-muted/80"
                            }`}
                          >
                            {s === "all" ? "All" : STATUS_CONFIG[s].label}
                          </button>
                        ))}
                      </div>
                      <div className="flex justify-end">
                        <button
                          onClick={() => setShowSortDrawer(true)}
                          className="min-h-[44px] px-3 flex items-center gap-1.5 text-xs font-semibold border border-border rounded-xl bg-background text-foreground hover:bg-muted transition-colors"
                        >
                          Sort: {SORT_OPTIONS.find(o => o.id === sortBy)?.label}
                        </button>
                      </div>
                    </div>
                  )}
                </div>

                <div className="flex items-center justify-between px-4 py-1.5 bg-muted/30 border-b border-border flex-shrink-0">
                  <p className="text-xs text-muted-foreground font-medium">
                    {filteredLeads.length} of {leads.length} contacts
                  </p>
                  {(statusFilter !== "all" || searchQuery) && (
                    <button onClick={() => { setStatusFilter("all"); setSearchQuery(""); }} className="text-xs text-primary font-bold">
                      Clear
                    </button>
                  )}
                </div>

                <div className="flex-1 overflow-y-auto">
                  {filteredLeads.length === 0 ? (
                    <div className="flex flex-col items-center justify-center h-48 text-center px-6">
                      <Users className="w-10 h-10 text-muted-foreground mb-3" />
                      <p className="font-semibold text-foreground">
                        {leads.length === 0 ? "No contacts yet" : "No results"}
                      </p>
                      <p className="text-sm text-muted-foreground mt-1">
                        {leads.length === 0
                          ? 'Tap "Log Person" to add someone you met.'
                          : "Try adjusting your filters."}
                      </p>
                      {leads.length === 0 && (
                        <Button onClick={() => setShowAddContact(true)} className="mt-4 gap-2">
                          <Plus className="w-4 h-4" /> Log First Contact
                        </Button>
                      )}
                    </div>
                  ) : (
                    filteredLeads.map((lead) => (
                      <button
                        key={lead.id}
                        onClick={() => setSelectedLead(lead)}
                        className="w-full text-left flex items-start gap-3 px-4 py-3 border-b border-border hover:bg-muted/30 transition-colors"
                      >
                        <div
                          className="w-3 h-3 rounded-full flex-shrink-0 mt-1"
                          style={{ backgroundColor: STATUS_CONFIG[lead.status]?.mapColor || "#94a3b8" }}
                        />
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-2 mb-0.5">
                            <p className="font-semibold text-foreground text-sm truncate">
                              {lead.owner_name || "Unknown"}
                            </p>
                            <StatusBadge status={lead.status} size="sm" />
                          </div>
                          <p className="text-xs text-muted-foreground truncate">{lead.address}</p>
                          {lead.phone && (
                            <p className="text-xs text-muted-foreground mt-0.5 flex items-center gap-1">
                              <Phone className="w-3 h-3" /> {lead.phone}
                            </p>
                          )}
                          {lead.notes && (
                            <p className="text-xs text-muted-foreground mt-0.5 italic truncate">"{lead.notes}"</p>
                          )}
                        </div>
                        <p className="text-xs text-muted-foreground flex-shrink-0">
                          {lead.last_contact_date
                            ? new Date(lead.last_contact_date).toLocaleDateString("en-US", { month: "short", day: "numeric" })
                            : new Date(lead.created_date).toLocaleDateString("en-US", { month: "short", day: "numeric" })}
                        </p>
                      </button>
                    ))
                  )}
                </div>
              </>
            )}
          </div>
        )}

        {/* STATS TAB */}
        {tab === "stats" && (
          <div className="flex-1 min-h-0">
            <TeamDashboard leads={leads} visits={visits} />
          </div>
        )}

        {/* APPOINTMENTS TAB */}
        {tab === "appts" && (
          <div className="flex-1 min-h-0">
            <AppointmentsList appointments={appointments} leads={leads} onUpdate={handleAppointmentUpdate} />
          </div>
        )}
      </div>

      {/* Bottom Nav */}
      <div className="flex-shrink-0 bg-card border-t border-border flex z-20" style={{ paddingBottom: "env(safe-area-inset-bottom, 0px)" }}>
        {TABS.map(({ id, label, Icon }) => {
          const badge =
            id === "appts" ? todayAppts.length :
            id === "contacts" ? highPriorityCount : 0;
          return (
            <button
              key={id}
              onClick={() => setTab(id)}
              className={`flex-1 flex flex-col items-center gap-0.5 py-2.5 transition-colors relative ${
                tab === id ? "text-primary" : "text-muted-foreground"
              }`}
            >
              <div className="relative">
                <Icon className="w-5 h-5" />
                {badge > 0 && (
                  <span className="absolute -top-1 -right-2 text-xs bg-red-500 text-white font-bold rounded-full min-w-[16px] h-4 flex items-center justify-center px-0.5 leading-none">
                    {badge}
                  </span>
                )}
              </div>
              <span className="text-xs font-semibold">{label}</span>
            </button>
          );
        })}
      </div>

      {/* Modals */}
      {showAddContact && (
        <AddContactModal
          user={user}
          onClose={() => setShowAddContact(false)}
          onCreated={handleContactCreated}
        />
      )}

      {selectedLead && (
        <LeadDetailSheet
          lead={selectedLead}
          onClose={() => setSelectedLead(null)}
          onUpdate={handleLeadUpdate}
          onScheduleAppt={() => { setApptLead(selectedLead); setSelectedLead(null); }}
        />
      )}

      {apptLead && (
        <AppointmentModal
          lead={apptLead}
          onClose={() => setApptLead(null)}
          onCreated={handleAppointmentCreated}
        />
      )}

      {/* Sort Bottom Sheet */}
      {showSortDrawer && (
        <div className="fixed inset-0 z-50 flex items-end">
          <div className="absolute inset-0 bg-black/40" onClick={() => setShowSortDrawer(false)} />
          <div className="relative w-full bg-card rounded-t-2xl shadow-2xl" style={{ paddingBottom: "env(safe-area-inset-bottom, 16px)" }}>
            <div className="flex justify-center pt-3 pb-2">
              <div className="w-10 h-1 bg-border rounded-full" />
            </div>
            <p className="text-sm font-bold text-foreground px-5 pb-3">Sort By</p>
            <div className="divide-y divide-border">
              {SORT_OPTIONS.map((o) => (
                <button
                  key={o.id}
                  onClick={() => { setSortBy(o.id); setShowSortDrawer(false); }}
                  className={`w-full flex items-center justify-between px-5 min-h-[52px] text-sm font-medium transition-colors ${
                    sortBy === o.id ? "text-primary bg-primary/5" : "text-foreground hover:bg-muted"
                  }`}
                >
                  {o.label}
                  {sortBy === o.id && <span className="text-primary font-bold">✓</span>}
                </button>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}