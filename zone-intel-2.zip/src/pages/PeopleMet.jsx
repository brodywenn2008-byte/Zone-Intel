import { useState, useEffect, useRef } from "react";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { ArrowLeft, Plus, Camera, Phone, User, Loader2, X, CheckCircle, MinusCircle, XCircle } from "lucide-react";
import { Link } from "react-router-dom";

const INTEREST_OPTIONS = [
  { value: "interested", label: "Interested", icon: CheckCircle, color: "text-emerald-600 bg-emerald-50 border-emerald-300" },
  { value: "follow_up", label: "Maybe", icon: MinusCircle, color: "text-amber-600 bg-amber-50 border-amber-300" },
  { value: "not_interested", label: "Not Interested", icon: XCircle, color: "text-red-500 bg-red-50 border-red-200" },
];

const INTEREST_MAP = {
  interested: { label: "Interested", dot: "bg-emerald-500" },
  follow_up: { label: "Maybe", dot: "bg-amber-400" },
  not_interested: { label: "Not Interested", dot: "bg-red-400" },
  knocked: { label: "Knocked", dot: "bg-blue-400" },
};

function AddPersonModal({ onClose, onCreated }) {
  const [name, setName] = useState("");
  const [phone, setPhone] = useState("");
  const [address, setAddress] = useState("");
  const [interest, setInterest] = useState("interested");
  const [photoUrl, setPhotoUrl] = useState(null);
  const [uploading, setUploading] = useState(false);
  const [saving, setSaving] = useState(false);
  const fileRef = useRef();

  const handlePhoto = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setUploading(true);
    const { file_url } = await base44.integrations.Core.UploadFile({ file });
    setPhotoUrl(file_url);
    setUploading(false);
  };

  const handleSave = async () => {
    if (!name.trim()) return;
    setSaving(true);
    const lead = await base44.entities.Lead.create({
      owner_name: name.trim(),
      phone: phone.trim(),
      address: address.trim() || "Unknown",
      status: interest,
      photo_url: photoUrl || null,
      last_contact_date: new Date().toISOString(),
    });
    onCreated(lead);
  };

  return (
    <div className="fixed inset-0 z-50 flex flex-col bg-background" onClick={(e) => e.stopPropagation()}>
      <div className="flex items-center gap-3 px-4 py-3 border-b border-border bg-card flex-shrink-0">
        <button onClick={onClose} className="w-8 h-8 rounded-xl hover:bg-muted flex items-center justify-center">
          <X className="w-4 h-4" />
        </button>
        <p className="font-bold text-foreground flex-1">Add Person</p>
        <Button onClick={handleSave} disabled={saving || !name.trim()} size="sm" className="rounded-xl px-4">
          {saving ? <Loader2 className="w-4 h-4 animate-spin" /> : "Save"}
        </Button>
      </div>

      <div className="flex-1 overflow-y-auto px-5 py-6 space-y-5">
        {/* Photo */}
        <div className="flex flex-col items-center">
          <button
            onClick={() => fileRef.current?.click()}
            className="w-24 h-24 rounded-2xl border-2 border-dashed border-border bg-muted/40 flex flex-col items-center justify-center overflow-hidden hover:bg-muted/70 transition-colors"
          >
            {uploading ? (
              <Loader2 className="w-6 h-6 text-muted-foreground animate-spin" />
            ) : photoUrl ? (
              <img src={photoUrl} alt="photo" className="w-full h-full object-cover" />
            ) : (
              <>
                <Camera className="w-6 h-6 text-muted-foreground mb-1" />
                <span className="text-xs text-muted-foreground">Add Photo</span>
              </>
            )}
          </button>
          <input ref={fileRef} type="file" accept="image/*" capture="environment" className="hidden" onChange={handlePhoto} />
        </div>

        {/* Name */}
        <div>
          <label className="text-xs font-bold text-muted-foreground uppercase tracking-wide mb-1.5 block">Name *</label>
          <Input
            placeholder="Full name"
            value={name}
            onChange={(e) => setName(e.target.value)}
            className="h-11 rounded-xl"
          />
        </div>

        {/* Phone */}
        <div>
          <label className="text-xs font-bold text-muted-foreground uppercase tracking-wide mb-1.5 block">Phone</label>
          <Input
            placeholder="Phone number"
            type="tel"
            value={phone}
            onChange={(e) => setPhone(e.target.value)}
            className="h-11 rounded-xl"
          />
        </div>

        {/* Address */}
        <div>
          <label className="text-xs font-bold text-muted-foreground uppercase tracking-wide mb-1.5 block">Address</label>
          <Input
            placeholder="Street address"
            value={address}
            onChange={(e) => setAddress(e.target.value)}
            className="h-11 rounded-xl"
          />
        </div>

        {/* Interest */}
        <div>
          <label className="text-xs font-bold text-muted-foreground uppercase tracking-wide mb-2 block">Were They Interested?</label>
          <div className="grid grid-cols-3 gap-2">
            {INTEREST_OPTIONS.map(({ value, label, icon: Icon, color }) => (
              <button
                key={value}
                onClick={() => setInterest(value)}
                className={`flex flex-col items-center gap-1.5 py-3 px-2 rounded-xl border-2 transition-all ${
                  interest === value ? color : "bg-muted/40 border-border text-muted-foreground"
                }`}
              >
                <Icon className="w-5 h-5" />
                <span className="text-xs font-bold">{label}</span>
              </button>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

export default function PeopleMet() {
  const [people, setPeople] = useState([]);
  const [showAdd, setShowAdd] = useState(false);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState("all");

  useEffect(() => {
    base44.entities.Lead.list("-created_date", 200)
      .then(setPeople)
      .finally(() => setLoading(false));
  }, []);

  const handleCreated = (lead) => {
    setPeople((prev) => [lead, ...prev]);
    setShowAdd(false);
  };

  const filtered = filter === "all" ? people : people.filter((p) => p.status === filter);

  return (
    <div className="fixed inset-0 flex flex-col bg-background overflow-hidden">
      {/* Header */}
      <div className="bg-card border-b border-border px-4 py-3 flex items-center gap-3 flex-shrink-0 z-10">
        <Link to="/" className="w-8 h-8 rounded-xl hover:bg-muted flex items-center justify-center flex-shrink-0">
          <ArrowLeft className="w-4 h-4 text-muted-foreground" />
        </Link>
        <div className="flex-1 min-w-0">
          <p className="text-sm font-bold text-foreground">People Met</p>
          <p className="text-xs text-muted-foreground">{people.length} contacts logged</p>
        </div>
        <button
          onClick={() => setShowAdd(true)}
          className="flex items-center gap-1.5 text-xs font-bold text-white bg-primary px-3 py-1.5 rounded-xl"
        >
          <Plus className="w-3.5 h-3.5" /> Add Person
        </button>
      </div>

      {/* Filter tabs */}
      <div className="flex gap-1 px-4 py-2.5 border-b border-border bg-card flex-shrink-0 overflow-x-auto">
        {[
          { value: "all", label: "All" },
          { value: "interested", label: "Interested" },
          { value: "follow_up", label: "Maybe" },
          { value: "not_interested", label: "Not Interested" },
        ].map(({ value, label }) => (
          <button
            key={value}
            onClick={() => setFilter(value)}
            className={`flex-shrink-0 text-xs font-semibold px-3 py-1.5 rounded-full transition-colors ${
              filter === value ? "bg-primary text-white" : "bg-muted text-muted-foreground"
            }`}
          >
            {label}
          </button>
        ))}
      </div>

      {/* List */}
      <div className="flex-1 overflow-y-auto">
        {loading ? (
          <div className="flex items-center justify-center h-40">
            <Loader2 className="w-6 h-6 text-primary animate-spin" />
          </div>
        ) : filtered.length === 0 ? (
          <div className="flex flex-col items-center justify-center h-48 text-center px-6">
            <User className="w-10 h-10 text-muted-foreground mb-3" />
            <p className="font-semibold text-foreground">{people.length === 0 ? "No one logged yet" : "No results"}</p>
            <p className="text-sm text-muted-foreground mt-1">Tap "Add Person" to log someone you met.</p>
            {people.length === 0 && (
              <Button onClick={() => setShowAdd(true)} className="mt-4 gap-2">
                <Plus className="w-4 h-4" /> Add First Person
              </Button>
            )}
          </div>
        ) : (
          filtered.map((person) => {
            const interest = INTEREST_MAP[person.status] || { label: person.status, dot: "bg-muted-foreground" };
            return (
              <div key={person.id} className="flex items-center gap-3 px-4 py-3 border-b border-border">
                {/* Photo / avatar */}
                <div className="w-12 h-12 rounded-2xl bg-muted flex-shrink-0 overflow-hidden">
                  {person.photo_url ? (
                    <img src={person.photo_url} alt={person.owner_name} className="w-full h-full object-cover" />
                  ) : (
                    <div className="w-full h-full flex items-center justify-center">
                      <User className="w-5 h-5 text-muted-foreground" />
                    </div>
                  )}
                </div>

                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2">
                    <p className="font-bold text-foreground text-sm truncate">{person.owner_name || "Unknown"}</p>
                    <span className={`w-2 h-2 rounded-full flex-shrink-0 ${interest.dot}`} />
                    <span className="text-xs text-muted-foreground flex-shrink-0">{interest.label}</span>
                  </div>
                  {person.address && person.address !== "Unknown" && (
                    <p className="text-xs text-muted-foreground truncate mt-0.5">{person.address}</p>
                  )}
                  {person.phone && (
                    <p className="text-xs text-muted-foreground mt-0.5">{person.phone}</p>
                  )}
                </div>

                {person.phone && (
                  <a
                    href={`tel:${person.phone}`}
                    className="w-9 h-9 rounded-xl bg-primary/10 flex items-center justify-center flex-shrink-0"
                  >
                    <Phone className="w-4 h-4 text-primary" />
                  </a>
                )}
              </div>
            );
          })
        )}
      </div>

      {showAdd && <AddPersonModal onClose={() => setShowAdd(false)} onCreated={handleCreated} />}
    </div>
  );
}