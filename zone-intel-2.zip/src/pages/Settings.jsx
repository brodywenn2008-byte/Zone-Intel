import { useState, useEffect } from "react";
import { ArrowLeft, LogOut, Trash2, Loader2, User, Mail, Shield, Bell, CreditCard, ChevronRight, CheckCircle } from "lucide-react";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { base44 } from "@/api/base44Client";

export default function Settings() {
  const [user, setUser] = useState(null);
  const [isDeleting, setIsDeleting] = useState(false);
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);
  const [isPaid, setIsPaid] = useState(false);

  useEffect(() => {
    base44.auth.me().then((u) => {
      setUser(u);
      setIsPaid(u?.is_subscribed === true || u?.role === "admin" || u?.role === "pro");
    }).catch(() => {});

    base44.functions.invoke("verifyPayment", {}).then((res) => {
      setIsPaid(res.data?.paid === true);
    }).catch(() => {});
  }, []);

  const handleDeleteAccount = async () => {
    setIsDeleting(true);
    try {
      const u = await base44.auth.me();
      await base44.entities.User.delete(u.id);
      await base44.auth.logout("/");
    } catch (err) {
      console.error("Delete failed:", err);
      setIsDeleting(false);
    }
  };

  const handleLogout = () => {
    base44.auth.logout("/");
  };

  return (
    <div className="min-h-screen bg-background max-w-lg mx-auto flex flex-col pb-10">
      {/* Header */}
      <div className="flex items-center gap-3 px-5 py-4 border-b border-border bg-card">
        <Link to="/" className="flex items-center justify-center w-10 h-10 rounded-lg hover:bg-muted transition-colors">
          <ArrowLeft className="w-5 h-5 text-foreground" />
        </Link>
        <h1 className="text-lg font-bold text-foreground">Settings</h1>
      </div>

      <div className="flex-1 px-5 py-6 space-y-6">

        {/* Profile Section */}
        <div className="bg-card border border-border rounded-2xl overflow-hidden">
          <div className="px-4 py-3 border-b border-border bg-muted/40">
            <p className="text-xs font-bold uppercase tracking-wider text-muted-foreground">Profile</p>
          </div>
          <div className="p-4 flex items-center gap-4">
            <div className="w-14 h-14 rounded-full bg-primary/20 flex items-center justify-center flex-shrink-0">
              <User className="w-7 h-7 text-primary" />
            </div>
            <div className="flex-1 min-w-0">
              <p className="font-bold text-foreground truncate">{user?.full_name || "—"}</p>
              <p className="text-sm text-muted-foreground truncate flex items-center gap-1 mt-0.5">
                <Mail className="w-3.5 h-3.5" /> {user?.email || "—"}
              </p>
              <div className="mt-1.5">
                <span className={`text-xs font-bold px-2 py-0.5 rounded-full ${
                  user?.role === "admin" ? "bg-purple-100 text-purple-700" : "bg-blue-100 text-blue-700"
                }`}>
                  {user?.role === "admin" ? "Admin" : "Member"}
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* Access / Subscription */}
        <div className="bg-card border border-border rounded-2xl overflow-hidden">
          <div className="px-4 py-3 border-b border-border bg-muted/40">
            <p className="text-xs font-bold uppercase tracking-wider text-muted-foreground">Access</p>
          </div>
          <div className="p-4 flex items-center justify-between gap-3">
            <div className="flex items-center gap-3">
              <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${isPaid ? "bg-green-100" : "bg-amber-100"}`}>
                <CreditCard className={`w-5 h-5 ${isPaid ? "text-green-600" : "text-amber-600"}`} />
              </div>
              <div>
                <p className="text-sm font-semibold text-foreground">ZoneIntel Access</p>
                <p className="text-xs text-muted-foreground mt-0.5">
                  {isPaid ? "Full access — one-time purchase" : "No active access"}
                </p>
              </div>
            </div>
            {isPaid ? (
              <div className="flex items-center gap-1 text-xs font-bold text-green-600 bg-green-50 border border-green-200 px-2.5 py-1 rounded-full">
                <CheckCircle className="w-3.5 h-3.5" /> Active
              </div>
            ) : (
              <Link to="/" className="text-xs font-bold text-white bg-primary px-3 py-1.5 rounded-lg hover:bg-primary/90 transition-colors">
                Upgrade
              </Link>
            )}
          </div>
        </div>

        {/* App Info */}
        <div className="bg-card border border-border rounded-2xl overflow-hidden">
          <div className="px-4 py-3 border-b border-border bg-muted/40">
            <p className="text-xs font-bold uppercase tracking-wider text-muted-foreground">App Info</p>
          </div>
          <div className="divide-y divide-border">
            {[
              { label: "App Version", value: "1.0.0" },
              { label: "Platform", value: "ZoneIntel" },
              { label: "Support", value: "support@zoneintel.app" },
            ].map(({ label, value }) => (
              <div key={label} className="flex items-center justify-between px-4 py-3">
                <span className="text-sm text-muted-foreground">{label}</span>
                <span className="text-sm font-medium text-foreground">{value}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Legal */}
        <div className="bg-card border border-border rounded-2xl overflow-hidden">
          <div className="px-4 py-3 border-b border-border bg-muted/40">
            <p className="text-xs font-bold uppercase tracking-wider text-muted-foreground">Legal</p>
          </div>
          <div className="divide-y divide-border">
            {[
              { label: "Privacy Policy" },
              { label: "Terms of Service" },
              { label: "Data Usage & Compliance" },
            ].map(({ label }) => (
              <button key={label} className="w-full flex items-center justify-between px-4 py-3 hover:bg-muted/40 transition-colors">
                <span className="text-sm text-foreground">{label}</span>
                <ChevronRight className="w-4 h-4 text-muted-foreground" />
              </button>
            ))}
          </div>
        </div>

        {/* Account Actions */}
        <div className="bg-card border border-border rounded-2xl overflow-hidden">
          <div className="px-4 py-3 border-b border-border bg-muted/40">
            <p className="text-xs font-bold uppercase tracking-wider text-muted-foreground">Account</p>
          </div>
          <div className="divide-y divide-border">
            <button
              onClick={handleLogout}
              className="w-full flex items-center gap-3 px-4 py-3.5 hover:bg-muted/40 transition-colors"
            >
              <LogOut className="w-5 h-5 text-foreground" />
              <span className="font-semibold text-foreground">Log Out</span>
            </button>
            <button
              onClick={() => setShowDeleteConfirm(true)}
              className="w-full flex items-center gap-3 px-4 py-3.5 hover:bg-destructive/5 transition-colors"
            >
              <Trash2 className="w-5 h-5 text-destructive" />
              <span className="font-semibold text-destructive">Delete Account</span>
            </button>
          </div>
        </div>

      </div>

      {/* Delete Confirmation Modal */}
      {showDeleteConfirm && (
        <div className="fixed inset-0 bg-black/40 flex items-end z-50">
          <div className="w-full bg-card rounded-t-2xl border-t border-border p-6 space-y-4">
            <h2 className="text-lg font-bold text-foreground">Delete Account?</h2>
            <p className="text-sm text-muted-foreground">
              This action cannot be undone. All your data will be permanently deleted.
            </p>
            <div className="flex gap-3">
              <Button variant="outline" className="flex-1" onClick={() => setShowDeleteConfirm(false)} disabled={isDeleting}>
                Cancel
              </Button>
              <Button variant="destructive" className="flex-1" onClick={handleDeleteAccount} disabled={isDeleting}>
                {isDeleting ? <><Loader2 className="w-4 h-4 animate-spin" /> Deleting...</> : "Delete"}
              </Button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}