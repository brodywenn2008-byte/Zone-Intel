import { useState, useEffect, useMemo } from "react";
import { base44 } from "@/api/base44Client";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import {
  Search, Download, ArrowLeft, ArrowUpDown, ArrowUp, ArrowDown,
  Phone, MapPin, Calendar, Filter, BarChart2, Tag, Kanban, List, Zap
} from "lucide-react";
import AutomationTemplates from "../components/crm/AutomationTemplates";
import ExportLeadsModal from "../components/crm/ExportLeadsModal";
import SellLeadModal from "../components/marketplace/SellLeadModal";
import KanbanPipeline from "../components/crm/KanbanPipeline";
import { Link } from "react-router-dom";

const STATUS_STYLES = {
  not_visited:      "bg-gray-100 text-gray-600",
  knocked:          "bg-blue-100 text-blue-700",
  interested:       "bg-green-100 text-green-700",
  follow_up:        "bg-yellow-100 text-yellow-700",
  appointment_set:  "bg-purple-100 text-purple-700",
  sold:             "bg-emerald-100 text-emerald-800 font-bold",
  no_answer:        "bg-gray-100 text-gray-500",
  not_interested:   "bg-red-100 text-red-600",
};

const STATUS_LABELS = {
  not_visited: "Not Visited", knocked: "Knocked", interested: "Interested",
  follow_up: "Follow Up", appointment_set: "Appt Set", sold: "Sold",
  no_answer: "No Answer", not_interested: "Not Interested",
};

const ALL_STATUSES = Object.keys(STATUS_LABELS);



export default function CRMDashboard() {
  const [leads, setLeads] = useState([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");
  const [sortField, setSortField] = useState("created_date");
  const [sortDir, setSortDir] = useState("desc");
  const [showFilters, setShowFilters] = useState(false);
  const [sellLead, setSellLead] = useState(null);
  const [showExport, setShowExport] = useState(false);
  const [view, setView] = useState("list"); // list | kanban | automations

  useEffect(() => {
    base44.entities.Lead.list("-created_date", 500)
      .then(setLeads)
      .finally(() => setLoading(false));
  }, []);

  const toggleSort = (field) => {
    if (sortField === field) setSortDir(d => d === "asc" ? "desc" : "asc");
    else { setSortField(field); setSortDir("desc"); }
  };

  const SortIcon = ({ field }) => {
    if (sortField !== field) return <ArrowUpDown className="w-3 h-3 text-gray-400" />;
    return sortDir === "asc"
      ? <ArrowUp className="w-3 h-3 text-primary" />
      : <ArrowDown className="w-3 h-3 text-primary" />;
  };

  const filtered = useMemo(() => {
    let out = leads.filter(l => {
      const q = search.toLowerCase();
      const matchSearch = !q ||
        l.owner_name?.toLowerCase().includes(q) ||
        l.phone?.includes(q) ||
        l.address?.toLowerCase().includes(q);
      const matchStatus = statusFilter === "all" || l.status === statusFilter;
      return matchSearch && matchStatus;
    });

    out.sort((a, b) => {
      let va = a[sortField] ?? "";
      let vb = b[sortField] ?? "";
      if (sortField === "created_date") { va = new Date(va); vb = new Date(vb); }
      if (typeof va === "string") va = va.toLowerCase();
      if (typeof vb === "string") vb = vb.toLowerCase();
      if (va < vb) return sortDir === "asc" ? -1 : 1;
      if (va > vb) return sortDir === "asc" ? 1 : -1;
      return 0;
    });

    return out;
  }, [leads, search, statusFilter, sortField, sortDir]);

  const statusCounts = useMemo(() => {
    const counts = {};
    leads.forEach(l => { counts[l.status] = (counts[l.status] || 0) + 1; });
    return counts;
  }, [leads]);

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <div className="sticky top-0 z-20 bg-card border-b border-border px-4 py-3 flex items-center gap-3">
        <Link to="/canvas" className="w-8 h-8 rounded-lg hover:bg-muted flex items-center justify-center flex-shrink-0">
          <ArrowLeft className="w-4 h-4 text-muted-foreground" />
        </Link>
        <div className="flex-1 min-w-0">
          <h1 className="text-base font-bold text-foreground leading-none">CRM Dashboard</h1>
          <p className="text-xs text-muted-foreground mt-0.5">{leads.length} total leads</p>
        </div>
        <Link to="/analytics" className="flex items-center gap-1.5 text-xs font-semibold h-8 px-3 rounded-lg border border-border bg-card hover:bg-muted transition-colors text-foreground flex-shrink-0">
          <BarChart2 className="w-3.5 h-3.5" /> Analytics
        </Link>
        <Link to="/marketplace" className="flex items-center gap-1.5 text-xs font-semibold h-8 px-3 rounded-lg border border-border bg-card hover:bg-muted transition-colors text-foreground flex-shrink-0">
          <Tag className="w-3.5 h-3.5" /> Marketplace
        </Link>
        <button onClick={() => setView(v => v === "automations" ? "list" : "automations")}
          className={`flex items-center gap-1.5 text-xs font-semibold h-8 px-3 rounded-lg border transition-colors flex-shrink-0 ${
            view === "automations" ? "bg-primary text-white border-primary" : "border-border bg-card hover:bg-muted text-foreground"
          }`}>
          <Zap className="w-3.5 h-3.5" /> Automations
        </button>
        <div className="flex items-center border border-border rounded-lg overflow-hidden flex-shrink-0">
          <button onClick={() => setView("list")}
            className={`h-8 px-2.5 flex items-center gap-1 text-xs font-semibold transition-colors ${
              view === "list" ? "bg-primary text-white" : "bg-card text-muted-foreground hover:bg-muted"
            }`}>
            <List className="w-3.5 h-3.5" /> List
          </button>
          <button onClick={() => setView("kanban")}
            className={`h-8 px-2.5 flex items-center gap-1 text-xs font-semibold transition-colors border-l border-border ${
              view === "kanban" ? "bg-primary text-white" : "bg-card text-muted-foreground hover:bg-muted"
            }`}>
            <Kanban className="w-3.5 h-3.5" /> Kanban
          </button>
        </div>
        <Button
          size="sm"
          variant="outline"
          onClick={() => setShowExport(true)}
        >
          <Download className="w-3.5 h-3.5" /> Export CSV
        </Button>
      </div>

      {/* Stats bar */}
      <div className="px-4 py-3 flex gap-2 overflow-x-auto border-b border-border bg-card/50">
        {["interested", "appointment_set", "sold", "follow_up"].map(s => (
          <div key={s} className="flex-shrink-0 text-center bg-card rounded-xl border border-border px-3 py-2 min-w-[72px]">
            <p className="text-base font-black text-foreground leading-none">{statusCounts[s] || 0}</p>
            <p className="text-xs text-muted-foreground mt-0.5 leading-none">{STATUS_LABELS[s]}</p>
          </div>
        ))}
      </div>

      {/* Search & filter */}
      <div className="px-4 py-3 space-y-2 border-b border-border">
        <div className="flex gap-2">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <Input
              placeholder="Search name, phone, address..."
              value={search}
              onChange={e => setSearch(e.target.value)}
              className="pl-9 h-9 text-sm"
            />
          </div>
          <button
            onClick={() => setShowFilters(v => !v)}
            className={`w-9 h-9 rounded-lg border flex items-center justify-center flex-shrink-0 transition-colors ${
              showFilters || statusFilter !== "all"
                ? "bg-primary text-white border-primary"
                : "border-border bg-card hover:bg-muted"
            }`}
          >
            <Filter className="w-4 h-4" />
          </button>
        </div>
        {showFilters && (
          <div className="flex gap-1.5 overflow-x-auto pb-0.5">
            {["all", ...ALL_STATUSES].map(s => (
              <button
                key={s}
                onClick={() => setStatusFilter(s)}
                className={`flex-shrink-0 text-xs font-semibold px-3 py-1.5 rounded-full transition-colors ${
                  statusFilter === s ? "bg-primary text-white" : "bg-muted text-muted-foreground"
                }`}
              >
                {s === "all" ? "All" : STATUS_LABELS[s]}
                {s !== "all" && statusCounts[s] ? ` (${statusCounts[s]})` : ""}
              </button>
            ))}
          </div>
        )}
      </div>

      {/* Results count */}
      <div className="px-4 py-2 flex items-center justify-between bg-muted/30 border-b border-border">
        <p className="text-xs text-muted-foreground font-medium">
          {filtered.length} of {leads.length} leads
        </p>
        {(search || statusFilter !== "all") && (
          <button onClick={() => { setSearch(""); setStatusFilter("all"); }}
            className="text-xs text-primary font-bold">Clear</button>
        )}
      </div>

      {/* Automations View */}
      {view === "automations" && <AutomationTemplates />}

      {/* Kanban View */}
      {!loading && view === "kanban" && (
        <KanbanPipeline
          leads={filtered}
          onLeadUpdated={(updated) =>
            setLeads(prev => prev.map(l => l.id === updated.id ? updated : l))
          }
        />
      )}

      {/* Table / List View */}
      {view === "list" && loading ? (
        <div className="flex items-center justify-center h-48">
          <div className="w-6 h-6 border-4 border-primary/30 border-t-primary rounded-full animate-spin" />
        </div>
      ) : filtered.length === 0 ? (
        <div className="flex flex-col items-center justify-center h-48 text-center px-6">
          <Search className="w-8 h-8 text-muted-foreground mb-2" />
          <p className="font-semibold text-foreground">No leads found</p>
          <p className="text-sm text-muted-foreground mt-1">Try adjusting your search or filters.</p>
        </div>
      ) : (
        <>
          {/* Desktop table */}
          <div className="hidden md:block overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="bg-muted/40 border-b border-border">
                <tr>
                  {[
                    { label: "Name", field: "owner_name" },
                    { label: "Phone", field: "phone" },
                    { label: "Address", field: "address" },
                    { label: "Status", field: "status" },
                    { label: "Notes", field: "notes" },
                    { label: "Created", field: "created_date" },
                  ].map(col => (
                    <th key={col.field}
                      className="px-4 py-2.5 text-left text-xs font-bold text-muted-foreground uppercase tracking-wider cursor-pointer hover:text-foreground transition-colors"
                      onClick={() => toggleSort(col.field)}
                    >
                      <span className="flex items-center gap-1.5">
                        {col.label} <SortIcon field={col.field} />
                      </span>
                    </th>
                    ))}
                    <th className="px-4 py-2.5 text-left text-xs font-bold text-muted-foreground uppercase tracking-wider">Actions</th>
                    </tr>
                    </thead>
              <tbody className="divide-y divide-border">
                {filtered.map(lead => (
                  <tr key={lead.id} className="hover:bg-muted/20 transition-colors">
                    <td className="px-4 py-3 font-medium text-foreground">{lead.owner_name || <span className="text-muted-foreground italic">Unknown</span>}</td>
                    <td className="px-4 py-3">
                      {lead.phone
                        ? <a href={`tel:${lead.phone}`} className="text-primary font-medium">{lead.phone}</a>
                        : <span className="text-muted-foreground">—</span>}
                    </td>
                    <td className="px-4 py-3 text-muted-foreground max-w-[200px] truncate">{lead.address}</td>
                    <td className="px-4 py-3">
                      <span className={`text-xs font-semibold px-2 py-1 rounded-full ${STATUS_STYLES[lead.status] || "bg-gray-100 text-gray-600"}`}>
                        {STATUS_LABELS[lead.status] || lead.status}
                      </span>
                    </td>
                    <td className="px-4 py-3 text-muted-foreground max-w-[200px] truncate">{lead.notes || "—"}</td>
                    <td className="px-4 py-3 text-muted-foreground whitespace-nowrap">
                      {lead.created_date ? new Date(lead.created_date).toLocaleDateString() : "—"}
                    </td>
                    <td className="px-4 py-3">
                      {lead.is_for_sale
                        ? <span className="text-xs font-bold text-green-600 bg-green-50 px-2 py-0.5 rounded-full">Listed</span>
                        : <button onClick={() => setSellLead(lead)} className="text-xs font-bold text-primary bg-primary/10 px-2 py-1 rounded-full hover:bg-primary/20 transition-colors">Sell</button>
                      }
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {/* Mobile cards */}
          <div className="md:hidden divide-y divide-border">
            {filtered.map(lead => (
              <div key={lead.id} className="px-4 py-3 bg-card hover:bg-muted/20 transition-colors">
                <div className="flex items-start justify-between gap-2 mb-1.5">
                  <p className="font-semibold text-foreground text-sm">
                    {lead.owner_name || <span className="text-muted-foreground italic font-normal">Unknown owner</span>}
                  </p>
                  <div className="flex items-center gap-1.5 flex-shrink-0">
                    <span className={`text-xs font-semibold px-2 py-0.5 rounded-full ${STATUS_STYLES[lead.status] || "bg-gray-100 text-gray-600"}`}>
                      {STATUS_LABELS[lead.status] || lead.status}
                    </span>
                    {lead.is_for_sale
                      ? <span className="text-xs font-bold text-green-600 bg-green-50 px-2 py-0.5 rounded-full">Listed</span>
                      : <button onClick={() => setSellLead(lead)} className="text-xs font-bold text-primary bg-primary/10 px-2 py-1 rounded-full hover:bg-primary/20 transition-colors">Sell</button>
                    }
                  </div>
                </div>
                <div className="flex items-center gap-1 text-xs text-muted-foreground mb-1">
                  <MapPin className="w-3 h-3 flex-shrink-0" />
                  <span className="truncate">{lead.address}</span>
                </div>
                {lead.phone && (
                  <div className="flex items-center gap-1 text-xs mb-1">
                    <Phone className="w-3 h-3 text-muted-foreground flex-shrink-0" />
                    <a href={`tel:${lead.phone}`} className="text-primary font-medium">{lead.phone}</a>
                  </div>
                )}
                {lead.notes && <p className="text-xs text-muted-foreground line-clamp-2 mt-1">{lead.notes}</p>}
                <div className="flex items-center gap-1 text-xs text-muted-foreground mt-1.5">
                  <Calendar className="w-3 h-3" />
                  {lead.created_date ? new Date(lead.created_date).toLocaleDateString() : "—"}
                </div>
              </div>
            ))}
          </div>
        </>
      )}

      {sellLead && (
        <SellLeadModal
          lead={sellLead}
          onClose={() => setSellLead(null)}
          onListed={(updated) => {
            setLeads(prev => prev.map(l => l.id === updated.id ? updated : l));
            setSellLead(null);
          }}
        />
      )}

      {showExport && (
        <ExportLeadsModal leads={filtered} onClose={() => setShowExport(false)} />
      )}
    </div>
  );
}