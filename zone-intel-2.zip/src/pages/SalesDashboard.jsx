import { useState, useEffect, useCallback } from "react";
import { base44 } from "@/api/base44Client";
import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import {
  Target, Plus, TrendingUp, Users, Phone, CheckCircle,
  Calendar, ArrowLeft, Zap, Flame, Star
} from "lucide-react";
import BottomTabs from "../components/BottomTabs";
import DailyGoals from "../components/crm/DailyGoals";
import ActivityFeed from "../components/crm/ActivityFeed";
import QuickAddLeadModal from "../components/crm/QuickAddLeadModal";
import TeamLeaderboard from "../components/crm/TeamLeaderboard";
import CommissionSettings from "../components/crm/CommissionSettings";
import CommissionSummary from "../components/crm/CommissionSummary";
import ShiftLogPanel from "../components/crm/ShiftLog";
import WeeklyReports from "../components/crm/WeeklyReports";
import LeadNotificationListener from "../components/LeadNotificationListener";

const STAT_STAGES = [
  { key: "interested",      label: "Interested",   icon: Star,         color: "text-green-600",   bg: "bg-green-50" },
  { key: "appointment_set", label: "Appts Set",    icon: Calendar,     color: "text-purple-600",  bg: "bg-purple-50" },
  { key: "sold",            label: "Closed",       icon: CheckCircle,  color: "text-emerald-600", bg: "bg-emerald-50" },
  { key: "follow_up",       label: "Follow Ups",   icon: Phone,        color: "text-amber-600",   bg: "bg-amber-50" },
];

export default function SalesDashboard() {
  const navigate = useNavigate();
  const [leads, setLeads] = useState([]);
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);
  const [showQuickAdd, setShowQuickAdd] = useState(false);
  const [todayLeads, setTodayLeads] = useState([]);
  const [activeTab, setActiveTab] = useState("overview");
  const [commissionSettings, setCommissionSettings] = useState([]);

  const loadData = useCallback(async () => {
    const [u, allLeads, commSettings] = await Promise.all([
      base44.auth.me(),
      base44.entities.Lead.list("-updated_date", 500),
      base44.entities.CommissionSetting.list(),
    ]);
    setUser(u);
    setLeads(allLeads);
    setCommissionSettings(commSettings);

    const todayStart = new Date();
    todayStart.setHours(0, 0, 0, 0);
    setTodayLeads(allLeads.filter(l => new Date(l.updated_date) >= todayStart));
    setLoading(false);
  }, []);

  useEffect(() => { loadData(); }, [loadData]);

  // Real-time updates
  useEffect(() => {
    const unsub = base44.entities.Lead.subscribe((event) => {
      setLeads(prev => {
        if (event.type === "create") return [event.data, ...prev];
        if (event.type === "update") return prev.map(l => l.id === event.id ? event.data : l);
        if (event.type === "delete") return prev.filter(l => l.id !== event.id);
        return prev;
      });
    });
    return unsub;
  }, []);

  const statusCounts = leads.reduce((acc, l) => {
    acc[l.status] = (acc[l.status] || 0) + 1;
    return acc;
  }, {});

  const todaySold = todayLeads.filter(l => l.status === "sold").length;
  const totalLeads = leads.length;
  const conversionRate = totalLeads > 0
    ? Math.round((statusCounts["sold"] || 0) / totalLeads * 100)
    : 0;

  return (
    <div className="min-h-screen bg-background pb-24">
      {/* Header */}
      <div className="sticky top-0 z-20 bg-card border-b border-border px-4 pt-3 pb-3 flex items-center gap-3">
        <button onClick={() => navigate(-1)} className="w-8 h-8 rounded-lg hover:bg-muted flex items-center justify-center">
          <ArrowLeft className="w-4 h-4 text-muted-foreground" />
        </button>
        <div className="flex-1">
          <h1 className="text-base font-bold text-foreground leading-none">Sales Dashboard</h1>
          {user && <p className="text-xs text-muted-foreground mt-0.5">Hey {user.full_name?.split(" ")[0]} 👋</p>}
        </div>
        <Button onClick={() => setShowQuickAdd(true)} size="sm" className="gap-1.5 h-8 px-3 text-xs font-bold">
          <Plus className="w-3.5 h-3.5" /> Add Lead
        </Button>
      </div>

      <div className="px-4 pt-4 space-y-5">
        {/* Tabs */}
        <div className="flex gap-1 bg-muted rounded-xl p-1">
          {[
            { id: "overview",    label: "Overview" },
            { id: "shifts",      label: "🕐 Shifts" },
            { id: "reports",     label: "📊 Reports" },
            { id: "commissions", label: "💰 Earnings" },
            { id: "settings",    label: "⚙️ Setup" },
          ].map(t => (
            <button key={t.id} onClick={() => setActiveTab(t.id)}
              className={`flex-1 py-1.5 rounded-lg text-xs font-bold transition-all ${
                activeTab === t.id ? "bg-card shadow text-foreground" : "text-muted-foreground hover:text-foreground"
              }`}>
              {t.label}
            </button>
          ))}
        </div>

        {/* ── OVERVIEW ── */}
        {activeTab === "overview" && <>
          {/* Hero today stat */}
          <div className="bg-gradient-to-br from-primary to-primary/80 rounded-2xl p-5 text-white">
            <div className="flex items-center gap-2 mb-1">
              <Flame className="w-4 h-4 text-yellow-300" />
              <span className="text-xs font-bold text-white/80 uppercase tracking-wide">Today's Activity</span>
            </div>
            <div className="flex items-end gap-6 mt-3">
              <div>
                <p className="text-4xl font-black leading-none">{todayLeads.length}</p>
                <p className="text-xs text-white/70 mt-1">leads updated today</p>
              </div>
              <div>
                <p className="text-2xl font-black leading-none text-yellow-300">{todaySold}</p>
                <p className="text-xs text-white/70 mt-1">closed today</p>
              </div>
              <div className="ml-auto text-right">
                <p className="text-2xl font-black leading-none">{conversionRate}%</p>
                <p className="text-xs text-white/70 mt-1">all-time close rate</p>
              </div>
            </div>
          </div>

          {/* Quick stats grid */}
          <div className="grid grid-cols-2 gap-2.5">
            {STAT_STAGES.map(({ key, label, icon: Icon, color, bg }) => (
              <button key={key} onClick={() => navigate("/crm")}
                className="bg-card border border-border rounded-2xl p-4 flex items-center gap-3 active:scale-[0.97] transition-transform text-left">
                <div className={`w-10 h-10 rounded-xl ${bg} flex items-center justify-center flex-shrink-0`}>
                  <Icon className={`w-5 h-5 ${color}`} />
                </div>
                <div>
                  <p className="text-2xl font-black text-foreground leading-none">{statusCounts[key] || 0}</p>
                  <p className="text-xs text-muted-foreground mt-0.5">{label}</p>
                </div>
              </button>
            ))}
          </div>

          {/* Pipeline mini-bar */}
          <div className="bg-card border border-border rounded-2xl p-4">
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-2">
                <TrendingUp className="w-4 h-4 text-primary" />
                <p className="text-sm font-bold text-foreground">Pipeline Overview</p>
              </div>
              <span className="text-xs text-muted-foreground">{totalLeads} total</span>
            </div>
            <div className="flex rounded-full overflow-hidden h-3 gap-0.5">
              {[
                { key: "interested",      color: "bg-green-400" },
                { key: "follow_up",       color: "bg-amber-400" },
                { key: "appointment_set", color: "bg-purple-400" },
                { key: "sold",            color: "bg-emerald-500" },
                { key: "knocked",         color: "bg-blue-300" },
                { key: "not_visited",     color: "bg-gray-200" },
              ].map(({ key, color }) => {
                const count = statusCounts[key] || 0;
                const pct = totalLeads > 0 ? (count / totalLeads) * 100 : 0;
                return pct > 0 ? (
                  <div key={key} className={`${color} transition-all`} style={{ width: `${pct}%` }} title={`${key}: ${count}`} />
                ) : null;
              })}
            </div>
            <div className="flex flex-wrap gap-x-3 gap-y-1 mt-2">
              {[
                { key: "sold",            label: "Closed",     color: "bg-emerald-500" },
                { key: "appointment_set", label: "Appt Set",   color: "bg-purple-400" },
                { key: "interested",      label: "Interested", color: "bg-green-400" },
                { key: "follow_up",       label: "Follow Up",  color: "bg-amber-400" },
              ].map(({ key, label, color }) => (
                <div key={key} className="flex items-center gap-1">
                  <div className={`w-2 h-2 rounded-full ${color}`} />
                  <span className="text-xs text-muted-foreground">{label} ({statusCounts[key] || 0})</span>
                </div>
              ))}
            </div>
          </div>

          <DailyGoals leads={leads} todayLeads={todayLeads} />
          <TeamLeaderboard leads={leads} />
          <ActivityFeed leads={leads} loading={loading} />
        </>}

        {/* ── SHIFTS ── */}
        {activeTab === "shifts" && <ShiftLogPanel user={user} />}

        {/* ── REPORTS ── */}
        {activeTab === "reports" && <WeeklyReports leads={leads} />}

        {/* ── EARNINGS ── */}
        {activeTab === "commissions" && (
          <CommissionSummary leads={leads} commissionSettings={commissionSettings} />
        )}

        {/* ── COMMISSION SETUP ── */}
        {activeTab === "settings" && (
          <CommissionSettings />
        )}
      </div>

      {showQuickAdd && (
        <QuickAddLeadModal
          onClose={() => setShowQuickAdd(false)}
          onAdded={(lead) => { setLeads(prev => [lead, ...prev]); setShowQuickAdd(false); }}
        />
      )}

      <LeadNotificationListener currentUserEmail={user?.email} />
      <BottomTabs activeTab="dashboard" />
    </div>
  );
}