import { useState, useEffect, useMemo } from "react";
import { base44 } from "@/api/base44Client";
import { ArrowLeft, BarChart2, TrendingUp, Users, Target, Award, Settings2, Check } from "lucide-react";
import { Link } from "react-router-dom";
import {
  LineChart, Line, BarChart, Bar, PieChart, Pie, Cell,
  XAxis, YAxis, Tooltip, ResponsiveContainer, Legend, FunnelChart, Funnel, LabelList
} from "recharts";
import { subDays, format, isAfter, startOfDay } from "date-fns";

const STATUS_LABELS = {
  not_visited: "Not Visited", knocked: "Knocked", interested: "Interested",
  follow_up: "Follow Up", appointment_set: "Appt Set", sold: "Sold",
  no_answer: "No Answer", not_interested: "Not Interested",
};

const PIPELINE_ORDER = ["knocked", "interested", "follow_up", "appointment_set", "sold"];
const PIPELINE_COLORS = ["#60a5fa", "#34d399", "#fbbf24", "#a78bfa", "#10b981"];
const STATUS_COLORS = {
  not_visited: "#94a3b8", knocked: "#60a5fa", interested: "#34d399",
  follow_up: "#fbbf24", appointment_set: "#a78bfa", sold: "#10b981",
  no_answer: "#9ca3af", not_interested: "#f87171",
};

const ALL_WIDGETS = [
  { id: "trend", label: "7-Day Lead Trend" },
  { id: "pipeline", label: "Pipeline Funnel" },
  { id: "status_pie", label: "Status Breakdown" },
  { id: "territory", label: "Territory Performance" },
  { id: "engagement", label: "Prospect Engagement" },
  { id: "leaderboard", label: "Rep Leaderboard" },
];

const STORAGE_KEY = "zi_dashboard_widgets";

export default function AnalyticsDashboard() {
  const [leads, setLeads] = useState([]);
  const [visits, setVisits] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showCustomize, setShowCustomize] = useState(false);
  const [enabledWidgets, setEnabledWidgets] = useState(() => {
    try {
      const saved = JSON.parse(localStorage.getItem(STORAGE_KEY));
      return saved || ALL_WIDGETS.map(w => w.id);
    } catch { return ALL_WIDGETS.map(w => w.id); }
  });

  useEffect(() => {
    Promise.all([
      base44.entities.Lead.list("-created_date", 500),
      base44.entities.Visit.list("-created_date", 500),
    ]).then(([l, v]) => { setLeads(l); setVisits(v); }).finally(() => setLoading(false));
  }, []);

  const toggleWidget = (id) => {
    setEnabledWidgets(prev => {
      const next = prev.includes(id) ? prev.filter(w => w !== id) : [...prev, id];
      localStorage.setItem(STORAGE_KEY, JSON.stringify(next));
      return next;
    });
  };

  const show = (id) => enabledWidgets.includes(id);

  // 7-day trend
  const trendData = useMemo(() => {
    return Array.from({ length: 7 }, (_, i) => {
      const day = subDays(new Date(), 6 - i);
      const start = startOfDay(day);
      const end = startOfDay(subDays(day, -1));
      return {
        day: format(day, "EEE"),
        leads: leads.filter(l => {
          const d = new Date(l.created_date);
          return isAfter(d, start) && !isAfter(d, end);
        }).length,
        visits: visits.filter(v => {
          const d = new Date(v.created_date);
          return isAfter(d, start) && !isAfter(d, end);
        }).length,
      };
    });
  }, [leads, visits]);

  // Pipeline funnel
  const pipelineData = useMemo(() =>
    PIPELINE_ORDER.map((s, i) => ({
      name: STATUS_LABELS[s],
      value: leads.filter(l => l.status === s).length,
      fill: PIPELINE_COLORS[i],
    })).filter(d => d.value > 0),
  [leads]);

  // Status pie
  const pieData = useMemo(() =>
    Object.entries(STATUS_LABELS).map(([key, label]) => ({
      name: label, value: leads.filter(l => l.status === key).length, fill: STATUS_COLORS[key],
    })).filter(d => d.value > 0),
  [leads]);

  // Territory performance
  const territoryData = useMemo(() => {
    const map = {};
    leads.forEach(l => {
      const key = l.territory_id || "Unassigned";
      if (!map[key]) map[key] = { name: key.slice(0, 12), visited: 0, sold: 0, interested: 0 };
      if (l.status !== "not_visited") map[key].visited++;
      if (l.status === "sold") map[key].sold++;
      if (l.status === "interested") map[key].interested++;
    });
    return Object.values(map).sort((a, b) => b.visited - a.visited).slice(0, 6);
  }, [leads]);

  // Engagement (contact attempts over time)
  const engagementData = useMemo(() => {
    const buckets = { "Not Visited": 0, "1 Visit": 0, "2 Visits": 0, "3+ Visits": 0 };
    leads.forEach(l => {
      const c = l.visit_count || 0;
      if (c === 0) buckets["Not Visited"]++;
      else if (c === 1) buckets["1 Visit"]++;
      else if (c === 2) buckets["2 Visits"]++;
      else buckets["3+ Visits"]++;
    });
    return Object.entries(buckets).map(([name, value]) => ({ name, value }));
  }, [leads]);

  // Leaderboard
  const leaderboard = useMemo(() => {
    const rep = {};
    leads.forEach(l => {
      const e = l.assigned_rep || l.created_by;
      if (!e) return;
      if (!rep[e]) rep[e] = { name: e.split("@")[0], sold: 0, appts: 0, interested: 0, visited: 0 };
      if (l.status !== "not_visited") rep[e].visited++;
      if (l.status === "sold") rep[e].sold++;
      if (l.status === "appointment_set") rep[e].appts++;
      if (l.status === "interested") rep[e].interested++;
    });
    return Object.values(rep).sort((a, b) => (b.sold * 10 + b.appts * 5 + b.interested * 2) - (a.sold * 10 + a.appts * 5 + a.interested * 2)).slice(0, 6);
  }, [leads]);

  const totalLeads = leads.length;
  const sold = leads.filter(l => l.status === "sold").length;
  const convRate = leads.filter(l => l.status !== "not_visited").length > 0
    ? Math.round((sold / leads.filter(l => l.status !== "not_visited").length) * 100) : 0;
  const visitRate = totalLeads > 0 ? Math.round((leads.filter(l => l.status !== "not_visited").length / totalLeads) * 100) : 0;

  return (
    <div className="min-h-screen bg-background pb-10">
      {/* Header */}
      <div className="sticky top-0 z-20 bg-card border-b border-border px-4 py-3 flex items-center gap-3">
        <Link to="/crm" className="w-8 h-8 rounded-lg hover:bg-muted flex items-center justify-center flex-shrink-0">
          <ArrowLeft className="w-4 h-4 text-muted-foreground" />
        </Link>
        <div className="flex-1 min-w-0">
          <h1 className="text-base font-bold text-foreground">Analytics</h1>
          <p className="text-xs text-muted-foreground">{totalLeads} leads · {visits.length} visits</p>
        </div>
        <button
          onClick={() => setShowCustomize(v => !v)}
          className={`flex items-center gap-1.5 text-xs font-semibold px-3 h-8 rounded-lg border transition-colors ${
            showCustomize ? "bg-primary text-white border-primary" : "border-border bg-card hover:bg-muted text-foreground"
          }`}
        >
          <Settings2 className="w-3.5 h-3.5" /> Customize
        </button>
      </div>

      {/* Customize Panel */}
      {showCustomize && (
        <div className="bg-primary/5 border-b border-border px-4 py-3">
          <p className="text-xs font-bold text-muted-foreground uppercase tracking-wider mb-2">Toggle Widgets</p>
          <div className="flex flex-wrap gap-2">
            {ALL_WIDGETS.map(w => (
              <button
                key={w.id}
                onClick={() => toggleWidget(w.id)}
                className={`flex items-center gap-1.5 text-xs font-semibold px-3 py-1.5 rounded-full border transition-colors ${
                  enabledWidgets.includes(w.id)
                    ? "bg-primary text-white border-primary"
                    : "border-border bg-card text-muted-foreground"
                }`}
              >
                {enabledWidgets.includes(w.id) && <Check className="w-3 h-3" />}
                {w.label}
              </button>
            ))}
          </div>
        </div>
      )}

      {loading ? (
        <div className="flex items-center justify-center h-64">
          <div className="w-7 h-7 border-4 border-primary/30 border-t-primary rounded-full animate-spin" />
        </div>
      ) : (
        <div className="px-4 py-4 space-y-4 max-w-2xl mx-auto">

          {/* Summary KPIs */}
          <div className="grid grid-cols-4 gap-2">
            {[
              { label: "Total Leads", value: totalLeads, color: "text-primary" },
              { label: "Coverage", value: `${visitRate}%`, color: "text-blue-600" },
              { label: "Sold", value: sold, color: "text-green-600" },
              { label: "Conv. Rate", value: `${convRate}%`, color: "text-purple-600" },
            ].map(({ label, value, color }) => (
              <div key={label} className="bg-card border border-border rounded-xl p-3 text-center">
                <p className={`text-xl font-black ${color}`}>{value}</p>
                <p className="text-xs text-muted-foreground mt-0.5 leading-tight">{label}</p>
              </div>
            ))}
          </div>

          {/* 7-Day Trend */}
          {show("trend") && (
            <div className="bg-card border border-border rounded-2xl p-4">
              <div className="flex items-center gap-2 mb-3">
                <TrendingUp className="w-4 h-4 text-primary" />
                <p className="text-sm font-bold text-foreground">7-Day Lead Trend</p>
              </div>
              <ResponsiveContainer width="100%" height={180}>
                <LineChart data={trendData} margin={{ top: 5, right: 5, left: -20, bottom: 0 }}>
                  <XAxis dataKey="day" tick={{ fontSize: 11 }} />
                  <YAxis tick={{ fontSize: 11 }} allowDecimals={false} />
                  <Tooltip />
                  <Legend iconType="circle" iconSize={8} wrapperStyle={{ fontSize: 11 }} />
                  <Line type="monotone" dataKey="leads" stroke="#3b82f6" strokeWidth={2.5} dot={{ r: 4 }} name="New Leads" />
                  <Line type="monotone" dataKey="visits" stroke="#10b981" strokeWidth={2.5} dot={{ r: 4 }} strokeDasharray="4 2" name="Visits" />
                </LineChart>
              </ResponsiveContainer>
            </div>
          )}

          {/* Pipeline Funnel */}
          {show("pipeline") && pipelineData.length > 0 && (
            <div className="bg-card border border-border rounded-2xl p-4">
              <div className="flex items-center gap-2 mb-3">
                <Target className="w-4 h-4 text-primary" />
                <p className="text-sm font-bold text-foreground">Pipeline Funnel</p>
              </div>
              <div className="space-y-2">
                {pipelineData.map((item, i) => {
                  const maxVal = pipelineData[0]?.value || 1;
                  const pct = Math.round((item.value / maxVal) * 100);
                  return (
                    <div key={item.name}>
                      <div className="flex items-center justify-between text-xs mb-1">
                        <span className="font-semibold text-foreground">{item.name}</span>
                        <span className="font-black text-foreground">{item.value}</span>
                      </div>
                      <div className="w-full bg-muted rounded-full h-5 overflow-hidden">
                        <div
                          className="h-5 rounded-full flex items-center justify-end pr-2 transition-all duration-500"
                          style={{ width: `${Math.max(pct, 8)}%`, backgroundColor: item.fill }}
                        >
                          {pct > 20 && <span className="text-white text-xs font-bold">{pct}%</span>}
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* Status Breakdown Pie */}
          {show("status_pie") && pieData.length > 0 && (
            <div className="bg-card border border-border rounded-2xl p-4">
              <div className="flex items-center gap-2 mb-3">
                <BarChart2 className="w-4 h-4 text-primary" />
                <p className="text-sm font-bold text-foreground">Status Breakdown</p>
              </div>
              <div className="flex items-center gap-4">
                <ResponsiveContainer width={140} height={140}>
                  <PieChart>
                    <Pie data={pieData} cx="50%" cy="50%" outerRadius={60} dataKey="value" strokeWidth={0}>
                      {pieData.map((entry, i) => <Cell key={i} fill={entry.fill} />)}
                    </Pie>
                    <Tooltip formatter={(v, n) => [v, n]} />
                  </PieChart>
                </ResponsiveContainer>
                <div className="flex-1 space-y-1.5">
                  {pieData.map(d => (
                    <div key={d.name} className="flex items-center gap-2">
                      <div className="w-2.5 h-2.5 rounded-full flex-shrink-0" style={{ backgroundColor: d.fill }} />
                      <span className="text-xs text-muted-foreground flex-1 truncate">{d.name}</span>
                      <span className="text-xs font-bold text-foreground">{d.value}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* Territory Performance */}
          {show("territory") && territoryData.length > 0 && (
            <div className="bg-card border border-border rounded-2xl p-4">
              <div className="flex items-center gap-2 mb-3">
                <BarChart2 className="w-4 h-4 text-primary" />
                <p className="text-sm font-bold text-foreground">Territory Performance</p>
              </div>
              <ResponsiveContainer width="100%" height={160}>
                <BarChart data={territoryData} margin={{ top: 0, right: 0, left: -20, bottom: 0 }}>
                  <XAxis dataKey="name" tick={{ fontSize: 10 }} />
                  <YAxis tick={{ fontSize: 10 }} allowDecimals={false} />
                  <Tooltip />
                  <Legend iconType="square" iconSize={8} wrapperStyle={{ fontSize: 11 }} />
                  <Bar dataKey="visited" fill="#60a5fa" radius={[3, 3, 0, 0]} name="Visited" />
                  <Bar dataKey="interested" fill="#34d399" radius={[3, 3, 0, 0]} name="Interested" />
                  <Bar dataKey="sold" fill="#10b981" radius={[3, 3, 0, 0]} name="Sold" />
                </BarChart>
              </ResponsiveContainer>
            </div>
          )}

          {/* Prospect Engagement */}
          {show("engagement") && (
            <div className="bg-card border border-border rounded-2xl p-4">
              <div className="flex items-center gap-2 mb-3">
                <Users className="w-4 h-4 text-primary" />
                <p className="text-sm font-bold text-foreground">Prospect Engagement</p>
                <span className="text-xs text-muted-foreground ml-auto">Contact attempts per lead</span>
              </div>
              <ResponsiveContainer width="100%" height={140}>
                <BarChart data={engagementData} margin={{ top: 0, right: 0, left: -20, bottom: 0 }}>
                  <XAxis dataKey="name" tick={{ fontSize: 11 }} />
                  <YAxis tick={{ fontSize: 11 }} allowDecimals={false} />
                  <Tooltip />
                  <Bar dataKey="value" radius={[4, 4, 0, 0]} name="Leads">
                    {engagementData.map((_, i) => (
                      <Cell key={i} fill={["#94a3b8", "#60a5fa", "#a78bfa", "#10b981"][i]} />
                    ))}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            </div>
          )}

          {/* Rep Leaderboard Chart */}
          {show("leaderboard") && leaderboard.length > 0 && (
            <div className="bg-card border border-border rounded-2xl p-4">
              <div className="flex items-center gap-2 mb-3">
                <Award className="w-4 h-4 text-yellow-500" />
                <p className="text-sm font-bold text-foreground">Rep Performance</p>
              </div>
              <ResponsiveContainer width="100%" height={160}>
                <BarChart data={leaderboard} layout="vertical" margin={{ top: 0, right: 10, left: 10, bottom: 0 }}>
                  <XAxis type="number" tick={{ fontSize: 10 }} allowDecimals={false} />
                  <YAxis type="category" dataKey="name" tick={{ fontSize: 10 }} width={60} />
                  <Tooltip />
                  <Legend iconType="square" iconSize={8} wrapperStyle={{ fontSize: 11 }} />
                  <Bar dataKey="visited" fill="#60a5fa" name="Knocked" radius={[0, 3, 3, 0]} />
                  <Bar dataKey="interested" fill="#34d399" name="Interested" radius={[0, 3, 3, 0]} />
                  <Bar dataKey="sold" fill="#10b981" name="Sold" radius={[0, 3, 3, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          )}

          {totalLeads === 0 && (
            <div className="flex flex-col items-center justify-center py-16 text-center">
              <TrendingUp className="w-12 h-12 text-muted-foreground mb-3" />
              <p className="font-bold text-foreground mb-1">No data yet</p>
              <p className="text-sm text-muted-foreground">Start canvassing to see your analytics.</p>
            </div>
          )}
        </div>
      )}
    </div>
  );
}