# Base44 App

A Vite + React web app built for Base44. This repository is configured to be easy to upload to GitHub and work with Base44's GitHub integration.

## Overview

- Built with React, Vite, Tailwind CSS, and Base44
- Includes project configuration for local development
- `.gitignore` already excludes `node_modules`, build output, and environment files

## Prerequisites

1. Clone or upload this repository to GitHub
2. Open the project folder
3. Install dependencies:

```bash
npm install
```

## Local development

Create a `.env.local` file in the project root and add your Base44 settings:

```env
VITE_BASE44_APP_ID=your_app_id
VITE_BASE44_APP_BASE_URL=your_backend_url
```

Example:

```env
VITE_BASE44_APP_ID=cbef744a8545c389ef439ea6
VITE_BASE44_APP_BASE_URL=https://my-to-do-list-81bfaad7.base44.app
```

Run the app locally:

```bash
npm run dev
```

## GitHub upload guidance

1. Create a new GitHub repository
2. Add this project files to the repository root
3. Push the repository to GitHub

The repository is already prepared for upload with:

- `.gitignore` to keep local files out of source control
- `package.json` and `package-lock.json` for dependency management
- `README.md` for project setup instructions

## Useful scripts

- `npm run dev` — start the development server
- `npm run build` — build production assets
- `npm run lint` — run ESLint
- `npm run lint:fix` — fix lint issues automatically
- `npm run typecheck` — run TypeScript checks using `jsconfig.json`

## Notes

- Do not commit `.env.local` or other secret files
- `.gitignore` already excludes `.env`, `.env.*`, `node_modules`, and build output

## Documentation

- Base44 GitHub integration: https://docs.base44.com/Integrations/Using-GitHub
- Base44 support: https://app.base44.com/support
